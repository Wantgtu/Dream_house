"use strict";
cc._RF.push(module, 'acc4brLad1BiIixwT7pD7mL', 'OppoHelper');
// Script/sdk/channel-ts/OppoHelper.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseHelper_1 = require("./BaseHelper");
var ChannelEvent_1 = require("./ChannelEvent");
var ChannelUtils_1 = require("./ChannelUtils");
var SDKEvent_1 = require("../sdk/tools/SDKEvent");
var SoundMgr_1 = require("../../logic/sound/model/SoundMgr");
var SDKManager_1 = require("../sdk/SDKManager");
var OVNativeAdC_1 = require("../nativeAd/OVNativeAdC");
var SDKConfig_1 = require("../sdk/SDKConfig");
var InsertAdMgr_1 = require("../comp/InsertAdMgr");
var lc_sdk_1 = require("../lib/lc_sdk");
var OppoHelper = /** @class */ (function (_super) {
    __extends(OppoHelper, _super);
    function OppoHelper() {
        var _this = _super.call(this) || this;
        _this.zsConfig = {
            zs_version: '1.0',
            zs_jump_switch: 1,
            zs_switch: 0,
            zs_banner_city: 0,
            zs_banner_system: '',
            zs_start_turntable: 1,
            // zs_onemin_show_ad_switch: 0,
            zs_native_btn_text: '查看广告',
            zs_native_gap_time: 30,
            zs_banner_native_time: 30,
            zs_native_click_switch: 0,
            zs_banner_native_switch: 0,
            zs_native_touch_switch: 0,
            zs_native_next_limit: 0,
            zs_native_close_num: 0,
            zs_native_show_delay: 0,
            zs_native_limit: 1,
            zs_jump_time: 0,
            zs_native_slide_switch: 0,
            zs_onemin_show_ad_switch: 1 //1 不展示，0 展示
        };
        _this.sdk = new lc_sdk_1.default();
        _this.setVersion('15.0');
        _this.sdk.initSdkByConf({ channel: "oppo", appId: "30738473", secret: "A6aEDBdD3d78dD385a0A159814609b81" });
        _this.login();
        _this.loadConfig();
        // if (this.zsConfig.zs_onemin_show_ad_switch == 1) {
        //     setTimeout(() => {
        //         this.zsConfig.zs_onemin_show_ad_switch = 0;
        //     }, 60000);
        // }
        SDKEvent_1.default.instance().on(SDKEvent_1.default.REWARD_AD_CLOSE, _this.rewardClose, _this);
        SDKEvent_1.default.instance().on(SDKEvent_1.default.REWARD_AD_OPEN, _this.rewardOpen, _this);
        return _this;
    }
    OppoHelper.prototype.rewardOpen = function () {
        console.log('rewardOpen ');
        SoundMgr_1.default.instance().rewardOpen();
    };
    OppoHelper.prototype.rewardClose = function () {
        SoundMgr_1.default.instance().rewardClose();
    };
    OppoHelper.prototype.isSwtichOpen = function () {
        // console.log('this.zsConfig.zs_switch == 1', this.zsConfig)
        // console.log('this.zsConfig.zs_switch == 1', this.zsConfig.zs_switch)
        return this.zsConfig.zs_switch == 1;
    };
    OppoHelper.prototype.login = function (isInit) {
        var _this = this;
        if (isInit === void 0) { isInit = true; }
        // let zsSdk = window['zs'].sdk
        this.sdk.login(function (openid) {
            // console.log(' msg ', openid)
            _this.sdk.init(openid);
        }, function (err) {
            // console.log('login error ', err)
            setTimeout(function () {
                _this.login(isInit);
            }, 3000);
        });
    };
    OppoHelper.prototype.getzs_native_btn_text = function () {
        if (this.zsConfig.zs_native_btn_text) {
            return this.zsConfig.zs_native_btn_text;
        }
        return '';
    };
    OppoHelper.prototype.loadConfig = function () {
        var _this = this;
        // let zsSdk = window['zs'].sdk
        this.sdk.loadCfg(function (result) {
            _this.zsConfig = typeof (result) == 'string' ? JSON.parse(result) : result;
            console.log('result type ', typeof (result));
            console.log(' result === ', _this.zsConfig);
            //test ------------------
            // this.zsConfig.zs_version = '1.0'
            // this.zsConfig.zs_jump_switch = 1;
            // this.zsConfig.zs_switch = 1;
            // this.zsConfig.zs_native_limit = 1;
            // this.zsConfig.zs_jump_time = 3000;
            // this.zsConfig.zs_banner_native_switch = 1;
            // this.zsConfig.zs_native_close_num = 1;
            if (_this.zsConfig.zs_onemin_show_ad_switch == 1) {
                setTimeout(function () {
                    _this.zsConfig.zs_onemin_show_ad_switch = 0;
                }, 60000);
            }
            ChannelEvent_1.default.instance().emit(ChannelEvent_1.default.LOAD_CONFIG);
        }, function (err) {
            console.log(' err === ', err);
            setTimeout(function () {
                _this.loadConfig();
            }, 3000);
        });
    };
    OppoHelper.prototype.hasEmail = function () {
        return false;
    };
    OppoHelper.prototype.getzs_native_gap_time = function () {
        if (this.zsConfig.zs_native_gap_time) {
            return this.zsConfig.zs_native_gap_time;
        }
        return 0;
    };
    OppoHelper.prototype.getBannerWitch = function () {
        if (this.zsConfig.zs_banner_native_switch) {
            return this.zsConfig.zs_banner_native_switch;
        }
        return 0;
    };
    OppoHelper.prototype.hasNativeTouchSwitch = function () {
        return this.zsConfig.zs_native_touch_switch == 1;
    };
    OppoHelper.prototype.getNativeBannerRefreshTime = function () {
        if (this.zsConfig.zs_banner_native_time) {
            return this.zsConfig.zs_banner_native_time;
        }
        return 30;
    };
    OppoHelper.prototype.getNativeCloseNum = function () {
        if (this.zsConfig.zs_native_close_num) {
            return this.zsConfig.zs_native_close_num;
        }
        return 0;
    };
    OppoHelper.prototype.isVersion = function () {
        var version = ChannelUtils_1.default.compareVersion(this.verson, this.zsConfig.zs_version) == 1;
        // console.log(' isVersion ', version)
        return this.isSwtichOpen() && version;
    };
    OppoHelper.prototype.isJumpSwitchOpen = function () {
        return this.isVersion() && this.zsConfig.zs_jump_switch == 1;
    };
    OppoHelper.prototype.hasNativeLimit = function () {
        // console.log(' this.zsConfig.zs_native_limit == 1 ', this.zsConfig.zs_native_limit == 1)
        return this.isVersion() && this.zsConfig.zs_native_limit == 1 && this.noOneMinAdLimit();
    };
    OppoHelper.prototype.noOneMinAdLimit = function () {
        // console.log(' this.zsConfig.zs_onemin_show_ad_switch == 0', this.zsConfig.zs_onemin_show_ad_switch == 0)
        return this.zsConfig.zs_onemin_show_ad_switch == 0;
    };
    OppoHelper.prototype.getJumpTime = function () {
        if (this.zsConfig.zs_jump_time) {
            return this.zsConfig.zs_jump_time;
        }
        return 0;
    };
    OppoHelper.prototype.hasAgreement = function () {
        return true;
    };
    OppoHelper.prototype.isOpenNativeErrorClick = function () {
        return this.isVersion() && this.zsConfig.zs_native_click_switch == 1;
    };
    OppoHelper.prototype.getNativeSlide = function () {
        if (this.zsConfig.zs_native_slide_switch) {
            return this.zsConfig.zs_native_slide_switch == 1;
        }
        return false;
    };
    OppoHelper.prototype.hasMoreGame = function () {
        // SDKManager.getChannel().showBoxPortalAd(0)
        return true;
    };
    OppoHelper.prototype.openMoreGameView = function (index, rx, ry) {
        SDKManager_1.default.getChannel().showAppBoxAd(index);
    };
    OppoHelper.prototype.showFuncInsertAd = function (site) {
        OVNativeAdC_1.default.instance().intoLayer(true);
        InsertAdMgr_1.default.setBannerState(false);
    };
    OppoHelper.prototype.showInsertAd = function (site) {
        OVNativeAdC_1.default.instance().intoLayer(true);
        InsertAdMgr_1.default.setBannerState(false);
    };
    OppoHelper.prototype.hideFuncInsertAd = function () {
        InsertAdMgr_1.default.setBannerState(true);
    };
    OppoHelper.prototype.showBannerAd = function (index) {
        if (!this.noOneMinAdLimit()) {
            return;
        }
        if (this.getBannerWitch() == 0) {
            SDKManager_1.default.getChannel().showBanner(index, SDKConfig_1.SDKDir.BOTTOM_MID);
        }
        else {
            OVNativeAdC_1.default.instance().showBanner();
            SDKManager_1.default.getChannel().hideBanner();
        }
    };
    OppoHelper.prototype.hideBannerAd = function (index) {
        if (!this.noOneMinAdLimit()) {
            return;
        }
        if (this.getBannerWitch() == 0) {
            SDKManager_1.default.getChannel().hideBanner(index);
        }
        else {
            OVNativeAdC_1.default.instance().hideBanner();
        }
    };
    OppoHelper.prototype.hasInstallApp = function () {
        return true;
    };
    OppoHelper.prototype.getzs_native_show_delay = function () {
        if (this.zsConfig.zs_native_show_delay) {
            return this.zsConfig.zs_native_show_delay;
        }
        return 0;
    };
    return OppoHelper;
}(BaseHelper_1.default));
exports.default = OppoHelper;

cc._RF.pop();