"use strict";
cc._RF.push(module, 'ace47ubud5JLbdaPAkyra/W', 'OperateFactory');
// Script/extention/gevent/operate/OperateFactory.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameEventConfig_1 = require("../GameEventConfig");
var GuideMgr_1 = require("../../guide/GuideMgr");
var GameTipMgr_1 = require("../../gameTip/model/GameTipMgr");
var CloseGameTip_1 = require("../../gameTip/model/CloseGameTip");
var DialogMgr_1 = require("../../dialog/model/DialogMgr");
var OperateFactory = /** @class */ (function () {
    function OperateFactory() {
    }
    OperateFactory.build = function (type, event) {
        var ins = this.ins[type];
        if (!ins) {
            switch (type) {
                case GameEventConfig_1.OperateType.OPEN_GUIDE:
                    ins = GuideMgr_1.default.instance();
                    break;
                case GameEventConfig_1.OperateType.OPEN_TIP:
                    ins = GameTipMgr_1.default.instance();
                    break;
                case GameEventConfig_1.OperateType.CLOSE_TIP:
                    ins = CloseGameTip_1.default.instance();
                    break;
                case GameEventConfig_1.OperateType.OPEN_DIALOG:
                    ins = DialogMgr_1.default.instance();
                    break;
            }
            if (ins) {
                this.ins[type] = ins;
                ins.setEvent(event);
                ins.setType(type);
            }
        }
        return ins;
    };
    OperateFactory.ins = {};
    return OperateFactory;
}());
exports.default = OperateFactory;

cc._RF.pop();