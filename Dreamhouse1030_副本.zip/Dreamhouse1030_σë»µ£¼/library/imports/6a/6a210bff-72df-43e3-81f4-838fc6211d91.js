"use strict";
cc._RF.push(module, '6a210v/ct9D44H0g4/GIR2R', 'Singleton');
// Script/cfw/tools/Singleton.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Singleton = /** @class */ (function () {
    function Singleton() {
    }
    Singleton.instance = function () {
        if (!this.ins) {
            this.ins = new this();
        }
        return this.ins;
    };
    return Singleton;
}());
exports.default = Singleton;

cc._RF.pop();