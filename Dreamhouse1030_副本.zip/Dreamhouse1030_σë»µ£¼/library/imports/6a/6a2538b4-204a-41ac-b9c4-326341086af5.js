"use strict";
cc._RF.push(module, '6a253i0IEpBrLnEMmNBCGr1', 'KSRewardAd');
// Script/sdk/sdk/ks/KSRewardAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseRewardAd_1 = require("../base/BaseRewardAd");
var SDKConfig_1 = require("../SDKConfig");
var KSRewardAd = /** @class */ (function (_super) {
    __extends(KSRewardAd, _super);
    function KSRewardAd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    KSRewardAd.prototype.open = function (callback) {
        console.log(' BaseRewardAd open state ', this.state);
        if (callback) {
            this.callback = callback;
        }
        // if (this.state == SDKState.loadSucess) {
        //     this.show()
        // } else {
        this.reload(SDKConfig_1.SDKState.open);
        // }
    };
    KSRewardAd.prototype.reload = function (s) {
        // console.log('预加载视频', s)
        this.logicState = s;
        this.setState(SDKConfig_1.SDKState.loading);
        // this.destroy(); //单例 不需要销毁
        this.create();
        this.show();
    };
    KSRewardAd.prototype.create = function () {
        // let sdkVersion = this.sdk.getSystemInfoSync().SDKVersion;
        if (!this.rewardAd) {
            console.log(' 不支持多例');
            this.rewardAd = this.sdk.createRewardedVideoAd({ adUnitId: this.adUnitID });
            // this.rewardAd.onLoad(this.onLoad.bind(this))
            this.rewardAd.onError(this.onError.bind(this));
            this.rewardAd.onClose(this.onClose.bind(this));
        }
        else {
            //微信会在第一次创建的时候默认load一次。
            // this.rewardAd.load();
        }
    };
    KSRewardAd.prototype.show = function () {
        if (this.rewardAd) {
            var p = this.rewardAd.show();
            p.then(function (result) {
                // 激励视频展示成功
                console.log("show rewarded video ad success, result is " + result);
                this.pause();
            }).catch(function (error) {
                // 激励视频展示失败
                console.log("show rewarded video ad failed, error is " + error);
            });
        }
    };
    return KSRewardAd;
}(BaseRewardAd_1.default));
exports.default = KSRewardAd;

cc._RF.pop();