"use strict";
cc._RF.push(module, '6a325H+fORC0qEIXfiFOuR2', 'ShowBlockAd');
// Script/sdk/comp/ShowBlockAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var SDKManager_1 = require("../sdk/SDKManager");
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ShowBlockAd = /** @class */ (function (_super) {
    __extends(ShowBlockAd, _super);
    function ShowBlockAd() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.adIndex = 0;
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    ShowBlockAd.prototype.start = function () {
        var rx = this.node.x / this.node.parent.width;
        var ry = (this.node.parent.height - this.node.y) / this.node.parent.height;
        SDKManager_1.default.getChannel().showBlockAd(this.adIndex, rx, ry);
    };
    ShowBlockAd.prototype.onDestroy = function () {
        SDKManager_1.default.getChannel().hideBlockAd(this.adIndex);
    };
    __decorate([
        property
    ], ShowBlockAd.prototype, "adIndex", void 0);
    ShowBlockAd = __decorate([
        ccclass
    ], ShowBlockAd);
    return ShowBlockAd;
}(cc.Component));
exports.default = ShowBlockAd;

cc._RF.pop();