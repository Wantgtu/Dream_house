"use strict";
cc._RF.push(module, '61c2cC7ZqtAaLdwDq/uVuBJ', 'CSJChannel');
// Script/sdk/sdk/csj/CSJChannel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseChannel_1 = require("../base/BaseChannel");
var CSJBannerAd_1 = require("./CSJBannerAd");
var CSJInsertAd_1 = require("./CSJInsertAd");
var CSJRewardAd_1 = require("./CSJRewardAd");
var SDKConfig_1 = require("../SDKConfig");
var NativeFileSystem_1 = require("../native/NativeFileSystem");
/**
 * V3.3.0.1
 */
var CSJChannel = /** @class */ (function (_super) {
    __extends(CSJChannel, _super);
    function CSJChannel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CSJChannel.prototype.init = function () {
        var cfg = this.cfg;
        var list = cfg[SDKConfig_1.ADName.reward];
        if (list) {
            for (var index = 0; index < list.length; index++) {
                var adId = list[index];
                this.rewardAd.push(new CSJRewardAd_1.default(this, adId));
            }
        }
        list = cfg[SDKConfig_1.ADName.banner];
        if (list) {
            for (var index = 0; index < list.length; index++) {
                var adId = list[index];
                this.bannerAd.push(new CSJBannerAd_1.default(this, adId));
            }
        }
        list = cfg[SDKConfig_1.ADName.insert];
        if (list) {
            for (var index = 0; index < list.length; index++) {
                var adId = list[index];
                this.insertAd.push(new CSJInsertAd_1.default(this, adId));
            }
        }
        this.fileSystem = new NativeFileSystem_1.default(this);
    };
    return CSJChannel;
}(BaseChannel_1.default));
exports.default = CSJChannel;

cc._RF.pop();