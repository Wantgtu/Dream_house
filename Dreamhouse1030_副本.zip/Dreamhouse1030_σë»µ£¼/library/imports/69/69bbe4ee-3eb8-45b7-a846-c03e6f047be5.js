"use strict";
cc._RF.push(module, '69bbeTuPrhFt6hGwD5vBHvl', 'SoundItemModel');
// Script/logic/sound/model/SoundItemModel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SoundItemModelEnum = void 0;
var cfw_1 = require("../../../cfw/cfw");
var ModuleConfig_1 = require("../../../config/ModuleConfig");
var SoundItemModelEnum;
(function (SoundItemModelEnum) {
    SoundItemModelEnum[SoundItemModelEnum["res"] = 0] = "res";
    SoundItemModelEnum[SoundItemModelEnum["name"] = 1] = "name";
    SoundItemModelEnum[SoundItemModelEnum["playCount"] = 2] = "playCount";
    SoundItemModelEnum[SoundItemModelEnum["type"] = 3] = "type";
    // path,
})(SoundItemModelEnum = exports.SoundItemModelEnum || (exports.SoundItemModelEnum = {}));
/**
* 音频
**/
var SoundItemModel = /** @class */ (function (_super) {
    __extends(SoundItemModel, _super);
    function SoundItemModel() {
        return _super.call(this, SoundItemModel.CLASS_NAME) || this;
    }
    // res
    SoundItemModel.prototype.getRes = function () {
        return this.getValue(SoundItemModelEnum.res);
    };
    // 名称
    SoundItemModel.prototype.getName = function () {
        return this.getValue(SoundItemModelEnum.name);
    };
    SoundItemModel.prototype.getPlayCount = function () {
        return this.getValue(SoundItemModelEnum.playCount);
    };
    SoundItemModel.prototype.getType = function () {
        return this.getValue(SoundItemModelEnum.type);
    };
    SoundItemModel.prototype.getPath = function () {
        return '';
    };
    SoundItemModel.prototype.getModuleID = function () {
        // let path: string = this.getPath();
        // if (path.indexOf('/') >= 0) {
        // 	return path.split('/')[0]
        // }
        return ModuleConfig_1.ModuleID.AUDIO;
    };
    SoundItemModel.CLASS_NAME = 'SoundItemModel';
    return SoundItemModel;
}(cfw_1.DataModel));
exports.default = SoundItemModel;

cc._RF.pop();