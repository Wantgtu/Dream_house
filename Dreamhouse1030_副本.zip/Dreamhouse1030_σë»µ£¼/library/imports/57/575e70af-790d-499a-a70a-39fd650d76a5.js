"use strict";
cc._RF.push(module, '575e7CveQ1JmqcKOf1lDXal', 'WXChannel');
// Script/sdk/sdk/wx/WXChannel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseChannel_1 = require("../base/BaseChannel");
var SDKConfig_1 = require("../SDKConfig");
var WXBannerAd_1 = require("./WXBannerAd");
var WXInsertAd_1 = require("./WXInsertAd");
var WXRewardAd_1 = require("./WXRewardAd");
var WXShare_1 = require("./WXShare");
var WXlogin_1 = require("./WXlogin");
var WXScreenshot_1 = require("./WXScreenshot");
var BaseSubPackage_1 = require("../base/BaseSubPackage");
var WXFileSystem_1 = require("./WXFileSystem");
var WXCustomAd_1 = require("./WXCustomAd");
var SDKHelper_1 = require("../SDKHelper");
var BannerIDMgr_1 = require("../tools/BannerIDMgr");
var UmaEvent_1 = require("../third/uma/UmaEvent");
var WXChannel = /** @class */ (function (_super) {
    __extends(WXChannel, _super);
    function WXChannel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    WXChannel.prototype.hasAd = function (name) {
        var cfg = this.cfg;
        var version = this.sdk.getSystemInfoSync().SDKVersion;
        var bannerCfg = cfg[name];
        if (!bannerCfg) {
            return -1;
        }
        var bVersion = bannerCfg[SDKConfig_1.ADName.version];
        if (!bVersion) {
            return 0;
        }
        return SDKHelper_1.default.compareVersion(version, bVersion) >= 0;
    };
    WXChannel.prototype.init = function () {
        var cfg = this.cfg;
        if (this.hasAd(SDKConfig_1.ADName.banner)) {
            var bannerCfg = cfg[SDKConfig_1.ADName.banner];
            var list = bannerCfg[SDKConfig_1.ADName.adUnitIdList];
            if (list) {
                for (var index = 0; index < list.length; index++) {
                    var adId = list[index];
                    this.bannerAd.push(new WXBannerAd_1.default(this, adId));
                }
            }
        }
        if (this.hasAd(SDKConfig_1.ADName.insert)) {
            var bannerCfg = cfg[SDKConfig_1.ADName.insert];
            var list = bannerCfg[SDKConfig_1.ADName.adUnitIdList];
            if (list) {
                for (var index = 0; index < list.length; index++) {
                    var adId = list[index];
                    this.insertAd.push(new WXInsertAd_1.default(this, adId));
                }
            }
        }
        if (this.hasAd(SDKConfig_1.ADName.reward)) {
            var bannerCfg = cfg[SDKConfig_1.ADName.reward];
            var list = bannerCfg[SDKConfig_1.ADName.adUnitIdList];
            if (list) {
                for (var index = 0; index < list.length; index++) {
                    var adId = list[index];
                    this.rewardAd.push(new WXRewardAd_1.default(this, adId));
                }
            }
        }
        if (this.hasAd(SDKConfig_1.ADName.customAd)) {
            var bannerCfg = cfg[SDKConfig_1.ADName.customAd];
            var list = bannerCfg[SDKConfig_1.ADName.adUnitIdList];
            if (list) {
                for (var index = 0; index < list.length; index++) {
                    var adId = list[index];
                    this.customAd.push(new WXCustomAd_1.default(this, adId));
                }
            }
        }
        if (this.sdk.shareAppMessage) {
            this.share = new WXShare_1.default(this, cfg[SDKConfig_1.ADName.share]);
        }
        this.loginMgr = new WXlogin_1.default(this);
        this.screenshot = new WXScreenshot_1.default(this);
        this.subPackage = new BaseSubPackage_1.default(this);
        this.fileSystem = new WXFileSystem_1.default(this);
        this.event = new UmaEvent_1.default();
        this.checkForUpdate();
    };
    WXChannel.prototype.vibrateShort = function () {
        this.sdk.vibrateShort();
    };
    //展示网络图片
    WXChannel.prototype.previewImage = function (imgUrl) {
        this.sdk.previewImage({
            current: imgUrl,
            urls: [imgUrl] // 需要预览的图片http链接列表
        });
    };
    //跳转能力
    WXChannel.prototype.navigateToMiniProgram = function (appID) {
        this.sdk.navigateToMiniProgram({
            appId: appID,
            success: function () {
            }
        });
    };
    WXChannel.prototype.showToast = function (title) {
        this.sdk.showToast({ title: title });
    };
    WXChannel.prototype.postMessage = function (msg) {
        var context = this.sdk.getOpenDataContext();
        if (context) {
            msg.channelID = this.cfg.name;
            context.postMessage(msg);
        }
    };
    WXChannel.prototype.checkForUpdate = function () {
        var _this = this;
        var updateManager = this.sdk.getUpdateManager();
        if (!updateManager) {
            return;
        }
        updateManager.onCheckForUpdate(function (res) {
            // 请求完新版本信息的回调
            // console.log(res.hasUpdate)
        });
        updateManager.onUpdateReady(function () {
            _this.sdk.showModal({
                title: '更新提示',
                content: '新版本已经准备好，是否重启应用？',
                success: function (res) {
                    if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                    }
                }
            });
        });
        updateManager.onUpdateFailed(function () {
            // 新版本下载失败
            _this.showToast('新版本下载失败,下次启动继续...');
        });
    };
    WXChannel.prototype.hasAppBox = function () {
        return true;
    };
    WXChannel.prototype.showAppBoxAd = function (index, func) {
        if (index === void 0) { index = 0; }
        if (this.hasAppBox()) {
            var rx = 0.01;
            var ry = 0.25;
            this.showCustomAd(2, rx, ry);
        }
    };
    // getBannerByIndex(index: number) {
    //     let site = BannerIDMgr.instance().getIndex(index)
    //     if (this.bannerAd[site]) {
    //         return this.bannerAd[site]
    //     }
    // }
    /**
     * 显示banner广告
     * @param index 广告位索引
     */
    WXChannel.prototype.showBanner = function (index, d, func) {
        if (d === void 0) { d = SDKConfig_1.SDKDir.BOTTOM_MID; }
        this.destroyBanner(index);
        BannerIDMgr_1.default.instance().setIndex(index);
        var site = BannerIDMgr_1.default.instance().getIndex(index);
        console.log('showBanner index  ', index, 'site', site);
        if (this.hasBanner() && this.bannerAd[site]) {
            this.bannerAd[site].setDir(d);
            this.bannerAd[site].updateSize();
            this.bannerAd[site].open(func);
        }
    };
    WXChannel.prototype.isBannerOk = function (index) {
        var site = BannerIDMgr_1.default.instance().getIndex(index);
        console.log('isBannerOk index  ', index, 'site', site);
        if (this.hasBanner() && this.bannerAd[site]) {
            return this.bannerAd[site].isOk();
        }
        return false;
    };
    WXChannel.prototype.showBannerByXYWH = function (index, x, y, w, h, func) {
        this.destroyBanner(index);
        BannerIDMgr_1.default.instance().setIndex(index);
        var site = BannerIDMgr_1.default.instance().getIndex(index);
        console.log('showBannerByXYWH index  ', index, 'site', site);
        if (this.hasBanner() && this.bannerAd[site]) {
            this.bannerAd[site].setDir(SDKConfig_1.SDKDir.XY);
            this.bannerAd[site].setPosition(x, y);
            this.bannerAd[site].setContentSize(w, h);
            this.bannerAd[site].updateSize();
            this.bannerAd[site].open(func);
        }
    };
    WXChannel.prototype.showBannerByXY = function (index, x, y, func) {
        this.destroyBanner(index);
        BannerIDMgr_1.default.instance().setIndex(index);
        var site = BannerIDMgr_1.default.instance().getIndex(index);
        console.log('showBannerByXY index  ', index, 'site', site);
        if (this.hasBanner() && this.bannerAd[site]) {
            this.bannerAd[site].setDir(SDKConfig_1.SDKDir.XY);
            this.bannerAd[site].setPosition(x, y);
            this.bannerAd[site].updateSize();
            this.bannerAd[site].open(func);
        }
    };
    WXChannel.prototype.preloadBannerByXY = function (index, x, y, func) {
        this.destroyBanner(index);
        BannerIDMgr_1.default.instance().setIndex(index);
        var site = BannerIDMgr_1.default.instance().getIndex(index);
        console.log('preloadBannerByXY index  ', index, 'site', site);
        if (this.bannerAd[site]) {
            this.bannerAd[site].setDir(SDKConfig_1.SDKDir.XY);
            this.bannerAd[site].setPosition(x, y);
            this.bannerAd[site].updateSize();
            this.bannerAd[site].preload(SDKConfig_1.SDKState.close);
        }
    };
    WXChannel.prototype.openBanner = function (index) {
        var site = BannerIDMgr_1.default.instance().getIndex(index);
        console.log('openBanner index  ', index, 'site', site);
        if (this.hasBanner() && this.bannerAd[site]) {
            this.bannerAd[site].show();
        }
    };
    //隐藏banner广告
    WXChannel.prototype.hideBanner = function (index) {
        if (index === void 0) { index = 0; }
        var site = BannerIDMgr_1.default.instance().getIndex(index);
        console.log('hideBanner index  ', index, 'site', site);
        if (this.hasBanner() && this.bannerAd[site]) {
            this.bannerAd[site].close();
        }
        else {
            // console.log('hideBanner error ', site, this.bannerAd.length)
        }
    };
    /**
     * 索引不变，重新拉取
     * @param index
     * @param state
     */
    WXChannel.prototype.loadBanner = function (index, state) {
        if (index === void 0) { index = 0; }
        var site = BannerIDMgr_1.default.instance().getIndex(index);
        console.log('loadBanner index  ', index, 'site', site);
        if (this.hasBanner() && this.bannerAd[site]) {
            this.bannerAd[site].preload(state);
        }
    };
    WXChannel.prototype.destroyBanner = function (index) {
        var site = BannerIDMgr_1.default.instance().getIndex(index);
        console.log('destroyBanner index  ', index, 'site', site);
        if (this.hasBanner() && this.bannerAd[site]) {
            this.bannerAd[site].destroy();
        }
    };
    return WXChannel;
}(BaseChannel_1.default));
exports.default = WXChannel;

cc._RF.pop();