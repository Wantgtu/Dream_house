"use strict";
cc._RF.push(module, '5792erC74JC054vhXKjb0K7', 'GoogleInsertAd');
// Script/sdk/sdk/google/GoogleInsertAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseInsertAd_1 = require("../base/BaseInsertAd");
var GoogleInsertAd = /** @class */ (function (_super) {
    __extends(GoogleInsertAd, _super);
    function GoogleInsertAd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    GoogleInsertAd.prototype.create = function () {
        // 创建插屏广告实例，提前初始化
        if (!this.insertAd) {
            this.insertAd = this.sdk.createInterstitialAd({
                adUnitId: this.adUnitID
            });
            this.insertAd.onLoad(this.onLoad.bind(this));
            this.insertAd.onError(this.onError.bind(this));
        }
    };
    return GoogleInsertAd;
}(BaseInsertAd_1.default));
exports.default = GoogleInsertAd;

cc._RF.pop();