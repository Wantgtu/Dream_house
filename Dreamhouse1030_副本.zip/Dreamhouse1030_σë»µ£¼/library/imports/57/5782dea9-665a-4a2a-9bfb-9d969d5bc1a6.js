"use strict";
cc._RF.push(module, '5782d6pZlpKKpv7nZadW8Gm', 'SpecialTaskItemView');
// Script/logic/specialtask/view/SpecialTaskItemView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../cfw/view");
var model_1 = require("../../../cfw/model");
var ModuleConfig_1 = require("../../../config/ModuleConfig");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SpecialTaskItemView = /** @class */ (function (_super) {
    __extends(SpecialTaskItemView, _super);
    function SpecialTaskItemView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.starPointSprite = null;
        _this.circlePointSprite = null;
        _this.CheckSprite = null;
        _this.pointSprite = null;
        _this.itemIconSprite = null;
        return _this;
    }
    SpecialTaskItemView.prototype.onEnter = function () {
        this.content();
    };
    SpecialTaskItemView.prototype.addListener = function () {
        //在此之前节点被隐藏了就不会走onDestroy方法了。
        this.eventProxy.on(model_1.BaseItemModel.UPDATE_STATE, this.updateState, this);
    };
    // onDestroy() {
    //     super.onDestroy();
    //     console.warn('SpecialTaskItemView onDestroy ')
    // }
    SpecialTaskItemView.prototype.content = function () {
        if (!this.model) {
            return;
        }
        if (this.model.isLastTask()) {
            this.starPointSprite.node.active = true;
            this.circlePointSprite.node.active = false;
        }
        else {
            this.starPointSprite.node.active = false;
            this.circlePointSprite.node.active = true;
        }
        this.setSpriteAtlas(this.itemIconSprite, ModuleConfig_1.ModuleID.PUBLIC, this.model.getIcon(), this.model.getSpriteFrame());
        this.updateState();
    };
    SpecialTaskItemView.prototype.updateState = function () {
        // console.log('SpecialTaskItemView update ')
        // console.log('this.model.getState() ', this.model.getState(),this.model.getID())
        switch (this.model.getState()) {
            case model_1.ItemState.NOT_GET:
                this.CheckSprite.node.active = false;
                this.pointSprite.node.active = false;
                break;
            case model_1.ItemState.ON_GOING:
                this.CheckSprite.node.active = false;
                this.pointSprite.node.active = true;
                break;
            case model_1.ItemState.CAN_GET:
                this.showRewardItem(this.itemIconSprite.node);
                this.model.setState(model_1.ItemState.GOT);
                break;
            case model_1.ItemState.GOT:
                this.CheckSprite.node.active = true;
                this.pointSprite.node.active = false;
                break;
        }
    };
    SpecialTaskItemView.prototype.showRewardItem = function (node) {
        // this.rewardItem.setModel(item)
        // this.rewardItem.draw();
        // this.rewardItem.node.active = true;
        // this.rewardItem.node.scale = 0;
        var scale = node.scale;
        var s2 = scale + 1;
        var s3 = s2 + 0.1;
        cc.tween(node).to(0.5, { scale: s2 })
            .delay(0.2)
            .to(0.2, { scale: s3 })
            .to(0.5, { scale: scale })
            .call(function () {
            // this.icon.node.active = false;
        })
            .start();
    };
    __decorate([
        property({ type: cc.Sprite, displayName: "starPointSprite" })
    ], SpecialTaskItemView.prototype, "starPointSprite", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "circlePointSprite" })
    ], SpecialTaskItemView.prototype, "circlePointSprite", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "CheckSprite" })
    ], SpecialTaskItemView.prototype, "CheckSprite", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "pointSprite" })
    ], SpecialTaskItemView.prototype, "pointSprite", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "itemIconSprite" })
    ], SpecialTaskItemView.prototype, "itemIconSprite", void 0);
    SpecialTaskItemView = __decorate([
        ccclass
    ], SpecialTaskItemView);
    return SpecialTaskItemView;
}(view_1.BaseItemView));
exports.default = SpecialTaskItemView;

cc._RF.pop();