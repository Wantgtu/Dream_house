"use strict";
cc._RF.push(module, '35425Nm2EBFG6MjSQDgLnj4', 'VivoFileSystem');
// Script/sdk/sdk/vivo/VivoFileSystem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDKFileSystemManager_1 = require("../base/SDKFileSystemManager");
var SDKConfig_1 = require("../SDKConfig");
/**
 * https://minigame.vivo.com.cn/documents/#/api/data/file
 */
// let folderName = 
var VivoFileSystem = /** @class */ (function (_super) {
    __extends(VivoFileSystem, _super);
    function VivoFileSystem() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    VivoFileSystem.prototype.init = function () {
        this.sysPath = 'internal://files/work/';
    };
    VivoFileSystem.prototype.writeFile = function (fileName, data, encoding, callback) {
        var _this = this;
        if (encoding == SDKConfig_1.FileEncoding.BINARY) {
            var ua = data;
            data = ua.buffer;
        }
        var has = this.has(this.sysPath);
        console.log("handling result\uFF1A " + has);
        if (has) {
            var filePath = this.sysPath + fileName;
            console.log(' writeFile filePath ', filePath);
            this.sdk.writeFile({
                uri: filePath,
                text: data,
                encoding: encoding,
                success: function () {
                    console.log(' writeFile ok');
                    callback(SDKConfig_1.ResultState.YES);
                },
                fail: function (err) {
                    console.log(' writeFile fail', err);
                    callback(SDKConfig_1.ResultState.NO);
                },
                complete: function () {
                    console.log(' writeFile complete');
                }
            });
        }
        else {
            this.mkdir(this.sysPath, function (state) {
                if (state == SDKConfig_1.ResultState.YES) {
                    var filePath = _this.sysPath + fileName;
                    console.log(' writeFile filePath ', filePath);
                    _this.sdk.writeFile({
                        uri: filePath,
                        text: data,
                        encoding: encoding,
                        success: function () {
                            console.log(' writeFile ok');
                            callback(SDKConfig_1.ResultState.YES);
                        },
                        fail: function (err) {
                            console.log(' writeFile fail', err);
                            callback(SDKConfig_1.ResultState.NO);
                        },
                        complete: function () {
                            console.log(' writeFile complete');
                        }
                    });
                }
            });
        }
    };
    VivoFileSystem.prototype.has = function (name) {
        var has = this.sdk.accessFile({
            uri: name
        });
        return has;
    };
    VivoFileSystem.prototype.mkdir = function (name, callback) {
        this.sdk.mkdir({
            uri: name,
            success: function (uri) {
                console.log("handling success: " + uri);
                callback(SDKConfig_1.ResultState.YES);
            },
            fail: function (data, code) {
                console.log("handling fail, code = " + code);
                callback(SDKConfig_1.ResultState.NO);
            }
        });
    };
    VivoFileSystem.prototype.readFile = function (fileName, encoding, callback) {
        var filePath = this.sysPath + fileName;
        console.log(' readFile filePath ', filePath);
        // if (!this.has(folderName)) {
        //     callback(ResultState.NO, null)
        //     return;
        // }
        this.sdk.readFile({
            uri: filePath,
            encoding: encoding,
            success: function (res) {
                // console.log(' readFile ok',res)
                if (encoding == SDKConfig_1.FileEncoding.BINARY) {
                    var bytes = new Uint8Array(res.text);
                    callback(SDKConfig_1.ResultState.YES, bytes);
                }
                else {
                    callback(SDKConfig_1.ResultState.YES, res.text);
                }
            },
            fail: function (err) {
                console.log(' readFile fail', err);
                callback(SDKConfig_1.ResultState.NO, null);
            },
            complete: function () {
                console.log(' writeFile complete');
            }
        });
    };
    VivoFileSystem.prototype.writeFileSync = function (fileName, data, encoding, position) {
        var filePath = this.sysPath + fileName;
        if (encoding == SDKConfig_1.FileEncoding.BINARY) {
            var ua = data;
            data = ua.buffer;
        }
        var result = this.sdk.writeFileSync({
            uri: filePath,
            text: data,
            encoding: encoding,
            position: position
        });
        if (result === 'success') {
            return true;
        }
        else {
            console.log("handling fail, result = " + result);
            return false;
        }
    };
    VivoFileSystem.prototype.readFileSync = function (fileName, encoding) {
        var filePath = this.sysPath + fileName;
        var result = this.sdk.readFileSync({
            uri: filePath,
            encoding: encoding,
        });
        if (typeof result === 'string') {
            console.log("handling fail, error message = " + result);
            return null;
        }
        else {
            console.log('handling success, text: ' + result.text);
            return result.text;
        }
    };
    return VivoFileSystem;
}(SDKFileSystemManager_1.default));
exports.default = VivoFileSystem;

cc._RF.pop();