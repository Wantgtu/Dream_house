"use strict";
cc._RF.push(module, '5aaeaArEJ1A4KlJ7KwTh4Dg', 'BaseNativeAdItemModel');
// Script/sdk/sdk/base/BaseNativeAdItemModel.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SDKHelper_1 = require("../SDKHelper");
var BaseNativeAdItemModel = /** @class */ (function () {
    function BaseNativeAdItemModel() {
    }
    BaseNativeAdItemModel.prototype.init = function (data) {
        this.data = data;
    };
    BaseNativeAdItemModel.prototype.getID = function () {
        return this.data.adId;
    };
    BaseNativeAdItemModel.prototype.getTitle = function () {
        return '';
    };
    BaseNativeAdItemModel.prototype.getIcon = function () {
        var list = this.getIconList();
        if (list && list.length > 0) {
            return list[0];
        }
        return null;
    };
    BaseNativeAdItemModel.prototype.getRandomImage = function () {
        console.log(' this.imgUrlList.length ', this.data.imgUrlList.length);
        if (this.data.imgUrlList.length > 0) {
            return this.data.imgUrlList[SDKHelper_1.default.random(0, this.data.imgUrlList.length)];
        }
        return this.getIcon();
    };
    BaseNativeAdItemModel.prototype.getRandomIcon = function () {
        console.log(' this.data.icon ', this.data.icon);
        if (this.data.icon) {
            return this.data.icon;
        }
        return this.getRandomImage();
    };
    BaseNativeAdItemModel.prototype.getDesc = function () {
        return this.data.desc;
    };
    BaseNativeAdItemModel.prototype.getIconList = function () {
        return this.data.icon;
    };
    BaseNativeAdItemModel.prototype.getImgList = function () {
        return this.data.imgUrlList;
    };
    BaseNativeAdItemModel.prototype.getButtonText = function () {
    };
    BaseNativeAdItemModel.prototype.getShowImageList = function () {
        return [];
    };
    return BaseNativeAdItemModel;
}());
exports.default = BaseNativeAdItemModel;

cc._RF.pop();