"use strict";
cc._RF.push(module, '5a615ftTL5Fc5YPwMAf2SUt', 'module');
// Script/cfw/module.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BundleManager = exports.ModuleManager = exports.Module = void 0;
var xlsx_1 = require("./xlsx");
var res_1 = require("./res");
var Define_1 = require("./tools/Define");
var ResHelper_1 = require("../engine/ResHelper");
var Module = /** @class */ (function () {
    function Module(projectName, config) {
        this.projectName = '';
        this.projectName = projectName;
        this.config = config;
        //有名称的模块，需要在适当的时候加载bundle 并设置。
        if (!config.isBundle) { //name != '' 的 说明是自定义的bundle。
            // this.setLoader(new ResLoader(new ResHelper(cc.resources, hasSubPackage ? "" : config.bundleName)))
            // this.setAudio()
            // console.log('config.isBundle  ', config.isBundle, config.bundleName)
            this.setLoaderByBundle(null);
        }
        this.dataManager = new xlsx_1.XlsxDataManager();
    }
    Module.prototype.hasLoader = function () {
        // console.log('hasLoader ', this.loader)
        return !Define_1.isNull(this.loader);
    };
    Module.prototype.setLoader = function (loader) {
        this.loader = loader;
    };
    Module.prototype.setLoaderByBundle = function (bundle) {
        if (!this.hasLoader()) {
            var name = this.config.bundleName;
            var helper = BundleManager.instance().getBundle(name);
            if (!helper) {
                BundleManager.instance().addBundle(name, new ResHelper_1.default(bundle, name));
            }
            this.setLoader(new res_1.ResLoader(BundleManager.instance().getBundle(name)));
        }
    };
    Module.prototype.getDataManager = function () {
        return this.dataManager;
    };
    Module.prototype.isBundle = function () {
        return this.config.isBundle;
    };
    Module.prototype.getName = function () {
        return this.config.bundleName;
    };
    Module.prototype.getLoader = function () {
        return this.loader;
    };
    Module.prototype.release = function () {
        if (this.loader) {
            this.loader.release();
        }
        else {
            console.warn('release loader is null name ', this.getName());
        }
    };
    Module.prototype.loadRes = function (url, type, callback, onProgress) {
        if (this.loader) {
            this.loader.loadRes(url, type, callback, onProgress);
        }
        else {
            console.warn('loadRes loader is null name ', this.getName());
        }
    };
    Module.prototype.getRes = function (url, type) {
        if (this.loader) {
            return this.loader.getRes(url, type);
        }
        else {
            console.warn('getres loader is null');
            return null;
        }
    };
    return Module;
}());
exports.Module = Module;
var ModuleManager = /** @class */ (function () {
    function ModuleManager() {
    }
    ModuleManager.setDefaultID = function (id) {
        this.defaultID = id;
    };
    ModuleManager.getModuleList = function () {
        return this.moduleList;
    };
    ModuleManager.init = function (projectName, ModuleConfig) {
        for (var index = 0; index < ModuleConfig.length; index++) {
            var config = ModuleConfig[index];
            var m = new Module(projectName, config);
            if (config.isBundle) {
                this.moduleList.push(config.name);
            }
            this.moduleMap[config.name] = m;
        }
    };
    ModuleManager.getRes = function (moduleID, url, type) {
        var loader = this.getModule(moduleID);
        if (loader) {
            return loader.getRes(url, type);
        }
        else {
            console.warn('getres loader is null');
            return null;
        }
    };
    ModuleManager.loadRes = function (moduleID, url, type, callback, onProgress) {
        var loader = this.getModule(moduleID);
        if (loader) {
            loader.loadRes(url, type, callback, onProgress);
        }
        else {
            callback('loader is null name ' + this.name, null);
        }
    };
    ModuleManager.getName = function (id) {
        return this.getModule(id).getName();
    };
    ModuleManager.loadBundle = function (id, callback) {
        var _this = this;
        this.getModule(this.defaultID).loadRes(id, res_1.ResType.AssetBundle, function (err, item) {
            if (err) {
                if (callback) {
                    callback(0);
                }
                return;
            }
            _this.setLoaderByBundle(id, item.getRes());
            if (callback) {
                callback(1);
            }
        });
    };
    ModuleManager.setLoaderByBundle = function (id, bundle) {
        if (id === void 0) { id = this.moduleID; }
        if (this.moduleMap[id]) {
            this.moduleMap[id].setLoaderByBundle(bundle);
        }
        else {
            console.warn('moduleMap is null  ', id);
        }
    };
    ModuleManager.getModule = function (id) {
        return this.moduleMap[id];
    };
    ModuleManager.setModuleID = function (id) {
        this.moduleID = id;
    };
    // static getLoader(id: string): ResLoader {
    //     if (this.moduleMap[id]) {
    //         return this.moduleMap[id].getLoader()
    //     }
    //     console.warn(' getLoader loader is null')
    //     return null;
    // }
    ModuleManager.release = function (id) {
        if (id === void 0) { id = this.moduleID; }
        this.getModule(id).release();
    };
    ModuleManager.hasLoader = function (id) {
        if (id === void 0) { id = this.moduleID; }
        return this.getModule(id).hasLoader();
    };
    Object.defineProperty(ModuleManager, "dataManager", {
        // static publicLoader() {
        //     return this.getModule(this.defaultID).getLoader()
        // }
        //数据管理器默认在res分包下 简化加载处理
        get: function () {
            return xlsx_1.XlsxDataManager.instance();
        },
        enumerable: false,
        configurable: true
    });
    ModuleManager.addFile = function (json, fileName) {
        this.dataManager.addFile(json, fileName);
    };
    ModuleManager.getData = function (key) {
        return this.dataManager.get(key);
    };
    /**
     * 当前正在使用的模块
     */
    ModuleManager.moduleID = 'res';
    //使用bundle的模块
    ModuleManager.moduleList = [];
    //模块管理器
    ModuleManager.moduleMap = {};
    ModuleManager.defaultID = 'res';
    return ModuleManager;
}());
exports.ModuleManager = ModuleManager;
var BundleManager = /** @class */ (function () {
    function BundleManager() {
        this.bundles = {};
    }
    BundleManager.instance = function () {
        if (!this.ins) {
            this.ins = new BundleManager();
        }
        return this.ins;
    };
    BundleManager.prototype.addBundle = function (key, bundle) {
        // console.log(' addBundle key ', key)
        this.bundles[key] = bundle;
    };
    BundleManager.prototype.hasBundle = function (key) {
        return this.bundles[key] != null && this.bundles[key] != undefined;
    };
    BundleManager.prototype.getBundle = function (key) {
        var bundle = this.bundles[key];
        if (bundle) {
            bundle.add();
        }
        return bundle;
    };
    BundleManager.prototype.removeBundle = function (key) {
        var bundle = this.bundles[key];
        if (bundle) {
            bundle.sub();
            if (bundle.getCount() <= 0) {
                this.bundles[key] = null;
            }
        }
    };
    return BundleManager;
}());
exports.BundleManager = BundleManager;

cc._RF.pop();