"use strict";
cc._RF.push(module, '03c401tp/xGM4x5GT4IV52r', 'BuyTokenView');
// Script/logic/item/view/BuyTokenView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../cfw/view");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BuyTokenView = /** @class */ (function (_super) {
    __extends(BuyTokenView, _super);
    function BuyTokenView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.play_smallSprite = null;
        _this.play_smallButton = null;
        _this.levelLabel = null;
        _this.backBtnButton = null;
        return _this;
    }
    BuyTokenView.prototype.onLoad = function () {
        this.levelLabel.string = '' + this.model.getNum();
    };
    BuyTokenView.prototype.onDestroy = function () {
    };
    BuyTokenView.prototype.onplay_smallButtonClick = function () {
        if (this.controller) {
            this.hide();
            this.controller.openStoreView();
        }
    };
    BuyTokenView.prototype.onbackBtnButtonClick = function () {
        this.hide();
    };
    BuyTokenView.prototype.onPlayAdButtonClick = function () {
        this.controller.buyToken(this);
    };
    __decorate([
        property({ type: cc.Sprite, displayName: "play_smallSprite" })
    ], BuyTokenView.prototype, "play_smallSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "play_smallButton" })
    ], BuyTokenView.prototype, "play_smallButton", void 0);
    __decorate([
        property({ type: cc.Label, displayName: "levelLabel" })
    ], BuyTokenView.prototype, "levelLabel", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "backBtnButton" })
    ], BuyTokenView.prototype, "backBtnButton", void 0);
    BuyTokenView = __decorate([
        ccclass
    ], BuyTokenView);
    return BuyTokenView;
}(view_1.BaseView));
exports.default = BuyTokenView;

cc._RF.pop();