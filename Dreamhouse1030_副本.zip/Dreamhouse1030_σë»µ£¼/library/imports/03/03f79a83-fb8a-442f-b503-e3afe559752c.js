"use strict";
cc._RF.push(module, '03f79qD+4pEL7UD46/lWXUs', 'LobbyView');
// Script/logic/lobby/view/LobbyView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../cfw/view");
var GuideMgr_1 = require("../../../extention/guide/GuideMgr");
var Config_1 = require("../../../config/Config");
var ButtonDuration_1 = require("../../../cfw/widget/ButtonDuration");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LobbyView = /** @class */ (function (_super) {
    __extends(LobbyView, _super);
    function LobbyView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.contentNode = null;
        _this.playBtnSprite = null;
        _this.playBtnButton = null;
        _this.taskBtnSprite = null;
        _this.taskBtnButton = null;
        _this.leftD = new ButtonDuration_1.default();
        _this.rightD = new ButtonDuration_1.default();
        return _this;
    }
    LobbyView.prototype.onLoad = function () {
        var _this = this;
        this.controller.addScene(this.contentNode, this.controller.getCurID(), function () {
            _this.controller.init();
        });
        // this.gEventProxy.on(EventName.NEW_BUILD_OPEN, this.newBuildOpen, this)
        this.gEventProxy.on(Config_1.EventName.CLOSE_GAME_VIEW, this.newBuildOpen, this);
    };
    LobbyView.prototype.newBuildOpen = function (m) {
        if (m.getType() != this.controller.getCurID()) {
            this.controller.addScene(this.contentNode, m.getType());
        }
    };
    LobbyView.prototype.changeContent = function () {
        var child = this.contentNode.children[0];
        if (child) {
            child.destroy();
        }
        this.controller.addScene(this.contentNode, this.controller.getCurID());
    };
    LobbyView.prototype.onDestroy = function () {
    };
    LobbyView.prototype.onplayBtnButtonClick = function () {
        GuideMgr_1.default.instance().notify('LobbyView_onplayBtnButtonClick');
        this.controller.intoGame();
    };
    LobbyView.prototype.ontaskBtnButtonClick = function () {
        this.controller.intoTask();
    };
    LobbyView.prototype.onLeftClick = function () {
        if (this.leftD.canClick()) {
            this.controller.leftScene();
            this.changeContent();
        }
    };
    LobbyView.prototype.onRightClick = function () {
        if (this.rightD.canClick()) {
            this.controller.rightScene();
            this.changeContent();
        }
    };
    __decorate([
        property({ type: cc.Node, displayName: "contentNode" })
    ], LobbyView.prototype, "contentNode", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "playBtnSprite" })
    ], LobbyView.prototype, "playBtnSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "playBtnButton" })
    ], LobbyView.prototype, "playBtnButton", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "taskBtnSprite" })
    ], LobbyView.prototype, "taskBtnSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "taskBtnButton" })
    ], LobbyView.prototype, "taskBtnButton", void 0);
    LobbyView = __decorate([
        ccclass
    ], LobbyView);
    return LobbyView;
}(view_1.BaseView));
exports.default = LobbyView;

cc._RF.pop();