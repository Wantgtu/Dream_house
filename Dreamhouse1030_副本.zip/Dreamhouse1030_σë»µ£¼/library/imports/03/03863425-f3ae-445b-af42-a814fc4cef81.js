"use strict";
cc._RF.push(module, '03863Ql865EW69CqBT8TO+B', 'KSRecorder');
// Script/sdk/sdk/ks/KSRecorder.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseRecorder_1 = require("../base/BaseRecorder");
var SDKConfig_1 = require("../SDKConfig");
/**
 * https://microapp.bytedance.com/dev/cn/mini-game/develop/open-capacity/video-camera/request-method
 */
var KSRecorder = /** @class */ (function (_super) {
    __extends(KSRecorder, _super);
    function KSRecorder() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.isSave = true;
        _this.callback = null;
        // protected time: number = 0;
        _this.timeID = 0;
        return _this;
    }
    KSRecorder.prototype.init = function () {
        var _this = this;
        this.recorder = this.sdk.getGameRecorder();
        this.changeState(SDKConfig_1.SDKState.close);
        this.recorder.on('start', function (res) {
            console.log('录屏开始', res);
            _this.changeState(SDKConfig_1.SDKState.start);
        });
        this.recorder.on('stop', function (res) {
            _this.videoPath = res.videoID;
            console.log("videoID is " + res.videoID);
            console.log('录屏结束', res);
            _this.changeState(SDKConfig_1.SDKState.stop);
            _this.changeState(SDKConfig_1.SDKState.close);
            if (_this.callback) {
                _this.callback(1);
                _this.callback = null;
            }
            // this.changeState(SDKState.stop)
        });
        this.recorder.on('resume', function () {
            console.log('TTRecorder onResume');
        });
        this.recorder.on('pause', function () {
            console.log('TTRecorder onPuase');
        });
        this.recorder.on('error', function (res) {
            console.log('TTRecorder onPuase');
            _this.c.showToast("录屏失败");
            _this.videoPath = null;
            _this.changeState(SDKConfig_1.SDKState.close);
            if (_this.callback) {
                _this.callback(0);
                _this.callback = null;
            }
        });
    };
    KSRecorder.prototype.start = function (time) {
        var _this = this;
        if (time === void 0) { time = 30; }
        console.log(' ttRecoter start ', this.state == SDKConfig_1.SDKState.start);
        if (this.state == SDKConfig_1.SDKState.start) {
            return;
        }
        // this.time = Date.now();
        // this.changeState(ItemState.GOT)
        this.recorder.start();
        this.timeID = setTimeout(function () {
            console.log(' chang');
            _this.recorder.stop();
            _this.timeID = 0;
        }, time * 1000);
    };
    KSRecorder.prototype.stop = function (isSave, callback) {
        if (isSave === void 0) { isSave = true; }
        if (this.state != SDKConfig_1.SDKState.start) {
            if (this.videoPath) {
                callback(1);
            }
            else {
                callback(0);
            }
            return;
        }
        if (this.timeID > 0) {
            clearTimeout(this.timeID);
        }
        // let t = Date.now();
        // let dis = t - this.time;
        // if (Math.floor(dis / 1000) <= 3) {
        //     callback(0)
        //     return;
        // }
        this.callback = callback;
        this.changeState(SDKConfig_1.SDKState.loading);
        this.isSave = isSave;
        this.recorder.stop();
        console.log(' ttRecoter stop ');
    };
    KSRecorder.prototype.pause = function () {
        this.recorder.pause();
    };
    KSRecorder.prototype.resume = function () {
        this.recorder.resume();
    };
    KSRecorder.prototype.publish = function (callback) {
        var data = this.data;
        data.video = this.videoPath;
        data.callback = function (error) {
            if (error != null && error != undefined) {
                console.log("分享录屏失败: " + JSON.stringify(error));
                callback(SDKConfig_1.ResultState.NO);
            }
            else {
                console.log("分享录屏成功");
                callback(SDKConfig_1.ResultState.YES);
            }
        };
        this.recorder.publishVideo(data);
    };
    return KSRecorder;
}(BaseRecorder_1.default));
exports.default = KSRecorder;

cc._RF.pop();