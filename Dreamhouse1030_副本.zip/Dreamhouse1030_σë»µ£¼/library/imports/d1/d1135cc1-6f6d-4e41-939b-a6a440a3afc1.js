"use strict";
cc._RF.push(module, 'd1135zBb21OQZObpqRAo6/B', 'VivoScreenshot');
// Script/sdk/sdk/vivo/VivoScreenshot.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseScreenshot_1 = require("../base/BaseScreenshot");
var VivoScreenshot = /** @class */ (function (_super) {
    __extends(VivoScreenshot, _super);
    function VivoScreenshot() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    VivoScreenshot.prototype.showImage = function (_tempFilePath) {
        this.channel.previewImage(_tempFilePath);
    };
    VivoScreenshot.prototype.createImage = function (texture) {
        console.log(' createImage ');
        var canvas = this.getCanvas();
        var width = texture.width;
        var height = texture.height;
        var bytes = new Uint8Array(width * height * 4);
        texture.readPixels(bytes);
        var data = {
            data: bytes,
            width: canvas.width,
            height: canvas.height,
            fileType: 'png',
            reverse: true,
        };
        return data;
    };
    VivoScreenshot.prototype.saveFile = function (data, show, callBack) {
        var _this = this;
        if (this.sdk.saveImageTempSync) {
            // https://cdofs.oppomobile.com/cdo-activity/static/201810/26/quickgame/documentation/media/image.html?h=saveImageToPhotosAlbum
            var _tempFilePath_1 = this.sdk.saveImageTempSync(data);
            console.log('_tempFilePath ', _tempFilePath_1);
            this.sdk.saveImageToPhotosAlbum({
                filePath: _tempFilePath_1,
                success: function () {
                    console.log("save success" + _tempFilePath_1);
                    if (show) {
                        _this.showImage(_tempFilePath_1);
                    }
                },
                fail: function (data, code) {
                    console.log("handling fail, code = " + code);
                }
            });
        }
    };
    return VivoScreenshot;
}(BaseScreenshot_1.default));
exports.default = VivoScreenshot;

cc._RF.pop();