"use strict";
cc._RF.push(module, 'bbd7318BFxCEaVmOkixMFoN', 'MarketItemView0');
// Script/logic/market/view/MarketItemView0.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Config_1 = require("../../../config/Config");
var MarketItemView_1 = require("./MarketItemView");
var GameC_1 = require("../../game/GameC");
var GuidePoint_1 = require("../../../extention/guide/GuidePoint");
var GuideMgr_1 = require("../../../extention/guide/GuideMgr");
var UIText_1 = require("../../../cocos/lang/UIText");
var RedTipPoint_1 = require("../../../extention/redtip/RedTipPoint");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MarketItemView0 = /** @class */ (function (_super) {
    __extends(MarketItemView0, _super);
    function MarketItemView0() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.IconSprite = null;
        _this.lockSprite = null;
        _this.playBtnSprite = null;
        _this.playBtnButton = null;
        _this.costIconSprite = null;
        _this.costNumLabel = null;
        _this.leftNumLabel = null;
        _this.tipBtnSprite = null;
        _this.tipBtnButton = null;
        _this.gPoint = null;
        _this.tipPoint = null;
        return _this;
    }
    MarketItemView0.prototype.addListener = function () {
        this.eventProxy.on(Config_1.EventName.CHANGE_COUNT, this.updateCount, this);
        this.eventProxy.on(Config_1.EventName.UPDATE_FOOD, this.updateFood, this);
    };
    MarketItemView0.prototype.updateFood = function () {
        var itemList = this.model.getItemList();
        var food = itemList[0];
        this.setSpriteAtlas(this.IconSprite, food.getModuleID(), food.getIcon(), food.getSpriteFrame());
        var list = this.tipPoint.getComponents(RedTipPoint_1.default);
        for (var index = 0; index < list.length; index++) {
            var element = list[index];
            element.id = food.getID();
            element.upateState();
        }
        // this.tipPoint.id = food.getID()
        // Debug.log(' updateFood id ', food.getID())
    };
    MarketItemView0.prototype.updateCount = function () {
        var type = this.model.getType();
        if (type == 0) {
            this.leftNumLabel.node.active = false;
            if (this.model.getID() == this.gPoint.itemID) {
                this.gPoint.init();
            }
        }
        else {
            this.leftNumLabel.string = UIText_1.default.instance().getText(2, { num: this.model.getCount() }); // '剩余:' +;
        }
        if (this.model.getCount() > 0) {
            this.playBtnButton.node.active = true;
            this.lockSprite.node.active = false;
        }
        else {
            this.playBtnButton.node.active = false;
            this.lockSprite.node.active = true;
        }
    };
    MarketItemView0.prototype.updateCost = function () {
        var cost = this.model.getCostItem();
        if (cost) {
            this.setSpriteAtlas(this.costIconSprite, cost.getModuleID(), cost.getIcon(), cost.getSpriteFrame());
            this.costNumLabel.string = '' + this.model.getNum();
        }
        else {
            // this.costIconSprite.spriteFrame = null
            this.costIconSprite.node.active = false;
            this.costNumLabel.string = UIText_1.default.instance().getText(1); //'免费'
        }
    };
    MarketItemView0.prototype.onplayBtnButtonClick = function () {
        GuideMgr_1.default.instance().notify('onplayBtnClick');
        var pos = this.node.parent.convertToWorldSpaceAR(this.node.getPosition());
        this.controller.buyItem(this.model, pos);
    };
    MarketItemView0.prototype.ontipBtnButtonClick = function () {
        var list = this.model.getItemList();
        var item = list[list.length - 1];
        GameC_1.default.instance().showFoodInfo(item);
    };
    __decorate([
        property({ type: cc.Sprite, displayName: "IconSprite" })
    ], MarketItemView0.prototype, "IconSprite", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "lockSprite" })
    ], MarketItemView0.prototype, "lockSprite", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "playBtnSprite" })
    ], MarketItemView0.prototype, "playBtnSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "playBtnButton" })
    ], MarketItemView0.prototype, "playBtnButton", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "costIconSprite" })
    ], MarketItemView0.prototype, "costIconSprite", void 0);
    __decorate([
        property({ type: cc.Label, displayName: "costNumLabel" })
    ], MarketItemView0.prototype, "costNumLabel", void 0);
    __decorate([
        property({ type: cc.Label, displayName: "leftNumLabel" })
    ], MarketItemView0.prototype, "leftNumLabel", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "tipBtnSprite" })
    ], MarketItemView0.prototype, "tipBtnSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "tipBtnButton" })
    ], MarketItemView0.prototype, "tipBtnButton", void 0);
    __decorate([
        property(GuidePoint_1.default)
    ], MarketItemView0.prototype, "gPoint", void 0);
    __decorate([
        property(cc.Node)
    ], MarketItemView0.prototype, "tipPoint", void 0);
    MarketItemView0 = __decorate([
        ccclass
    ], MarketItemView0);
    return MarketItemView0;
}(MarketItemView_1.default));
exports.default = MarketItemView0;

cc._RF.pop();