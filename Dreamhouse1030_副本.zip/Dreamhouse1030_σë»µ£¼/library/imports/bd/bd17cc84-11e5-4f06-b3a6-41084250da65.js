"use strict";
cc._RF.push(module, 'bd17cyEEeVPBrOmQQhCUNpl', 'RadioButtonMgr');
// Script/cfw/widget/RadioButtonMgr.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RadioButtonMgr = /** @class */ (function () {
    function RadioButtonMgr() {
        this.buttons = [];
    }
    RadioButtonMgr.prototype.add = function (b) {
        this.buttons.push(b);
    };
    RadioButtonMgr.prototype.setRadioButtonState = function (button) {
        for (var index = 0; index < this.buttons.length; index++) {
            var element = this.buttons[index];
            if (element === button) {
                element.setRadioButtonState(true);
            }
            else {
                element.setRadioButtonState(false);
            }
        }
    };
    return RadioButtonMgr;
}());
exports.default = RadioButtonMgr;

cc._RF.pop();