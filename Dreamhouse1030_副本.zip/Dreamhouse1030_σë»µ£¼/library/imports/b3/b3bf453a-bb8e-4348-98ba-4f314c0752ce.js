"use strict";
cc._RF.push(module, 'b3bf4U6u45DSJi6TzFMB1LO', 'ResHelper');
// Script/engine/ResHelper.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var res_1 = require("../cfw/res");
var core_1 = require("../cfw/core");
var ResHelper = /** @class */ (function (_super) {
    __extends(ResHelper, _super);
    function ResHelper(mgr, name) {
        if (name === void 0) { name = ''; }
        var _this = _super.call(this) || this;
        //todo 先观察是否需要使用name
        _this.name = '';
        _this.mgr = mgr;
        if (!_this.mgr) {
            _this.mgr = cc.resources;
        }
        return _this;
    }
    /**
      * 加载资源
      * @param url
      * @param type
      * @param callback
      */
    ResHelper.prototype.loadRes = function (url, type, callback, onProgress) {
        // cc.log(' this.name ', this.name, ' type ', type)
        switch (type) {
            case res_1.ResType.Prefab:
                this.mgr.load(url, cc.Prefab, callback);
                break;
            case res_1.ResType.Texture2D:
                this.mgr.load(url, cc.Texture2D, callback);
                break;
            case res_1.ResType.SpriteFrame:
                this.mgr.load(url, cc.SpriteFrame, callback);
                break;
            case res_1.ResType.Json:
                this.mgr.load(url, cc.JsonAsset, callback);
                break;
            case res_1.ResType.SpriteAtlas:
                this.mgr.load(url, cc.SpriteAtlas, callback);
                break;
            case res_1.ResType.Particle2D:
                this.mgr.load(url, cc.ParticleAsset, callback);
                break;
            case res_1.ResType.AudioClip:
                this.mgr.load(url, cc.AudioClip, callback);
                break;
            case res_1.ResType.AssetBundle:
                // console.log('loadRes 111 ')
                cc.assetManager.loadBundle(url, callback);
                // console.log('loadRes 2222 ')
                break;
            case res_1.ResType.Scene:
                // cc.resources.preloadScene(url, callback)
                //cc.log('loadRes  url ', url)
                this.mgr.loadScene(url, callback);
                // let func: ResCallback = (err: any, res: any) => {
                //     cc.log(' err ==  ', err)
                //     callback(err, res)
                // }
                // this.mgr.load(url, cc.SceneAsset, func)
                break;
            case res_1.ResType.Remote:
                cc.assetManager.loadRemote(url, callback);
                break;
        }
    };
    /**
     * 清理资源
     * @param url
     */
    ResHelper.prototype.release = function (url, type) {
        // cc.loader.release(url);
        // cc.resources.release(asset)
        console.warn('release  url ', url);
        var asset = this.getRes(url, type);
        cc.assetManager.releaseAsset(asset);
    };
    ResHelper.prototype.getRes = function (url, type) {
        switch (type) {
            case res_1.ResType.Prefab:
                return this.mgr.get(url, cc.Prefab);
            case res_1.ResType.Texture2D:
                return this.mgr.get(url, cc.Texture2D);
            case res_1.ResType.SpriteFrame:
                return this.mgr.get(url, cc.SpriteFrame);
            case res_1.ResType.Json:
                return this.mgr.get(url, cc.JsonAsset);
            case res_1.ResType.SpriteAtlas:
                return this.mgr.get(url, cc.SpriteAtlas);
            case res_1.ResType.Particle2D:
                return this.mgr.get(url, cc.ParticleAsset);
            case res_1.ResType.AudioClip:
                return this.mgr.get(url, cc.AudioClip);
            case res_1.ResType.Scene:
                return this.mgr.get(url, cc.SceneAsset);
            case res_1.ResType.AssetBundle:
                return cc.assetManager.getBundle(url);
            case res_1.ResType.Remote:
                return null;
            default:
                console.error(' getRes error url is ', url, ' type is ', type);
                return null;
        }
    };
    ResHelper.prototype.getDependsRecursively = function (res) {
        // return cc.loader.getDependsRecursively(res)
        return [];
    };
    ResHelper.prototype.clear = function () {
    };
    return ResHelper;
}(core_1.TSRef));
exports.default = ResHelper;

cc._RF.pop();