"use strict";
cc._RF.push(module, 'ab91eRrcAZDpJdBypNQi8d4', 'LuckySpinItemModel');
// Script/logic/luckyspin/model/LuckySpinItemModel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.LuckySpinItemModelEnum = void 0;
var cfw_1 = require("../../../cfw/cfw");
var FoodMgr_1 = require("../../game/model/FoodMgr");
var LuckySpinItemModelEnum;
(function (LuckySpinItemModelEnum) {
    LuckySpinItemModelEnum[LuckySpinItemModelEnum["reward"] = 0] = "reward";
    LuckySpinItemModelEnum[LuckySpinItemModelEnum["weight"] = 1] = "weight";
    LuckySpinItemModelEnum[LuckySpinItemModelEnum["count"] = 2] = "count";
})(LuckySpinItemModelEnum = exports.LuckySpinItemModelEnum || (exports.LuckySpinItemModelEnum = {}));
/**
* 辛运转盘
**/
var LuckySpinItemModel = /** @class */ (function (_super) {
    __extends(LuckySpinItemModel, _super);
    function LuckySpinItemModel() {
        return _super.call(this, LuckySpinItemModel.CLASS_NAME) || this;
    }
    // 奖励道具
    LuckySpinItemModel.prototype.getReward = function () {
        return this.getValue(LuckySpinItemModelEnum.reward);
    };
    // 权重
    LuckySpinItemModel.prototype.getWeight = function () {
        return this.getValue(LuckySpinItemModelEnum.weight);
    };
    LuckySpinItemModel.prototype.clear = function () {
        this.item = null;
    };
    LuckySpinItemModel.prototype.getItem = function () {
        if (!this.item) {
            var list = this.getReward();
            this.item = FoodMgr_1.default.instance().getItemByRareList(list);
            // let count = list.length / 2
            // let index = Utils.random(0, count)
            // let id = list[index * 2]
            // let num = list[index * 2 + 1]
            // this.item = BagManager.instance().getNewItemModel(id, num)
        }
        return this.item;
    };
    LuckySpinItemModel.prototype.getCount = function () {
        return this.getValue(LuckySpinItemModelEnum.count);
    };
    LuckySpinItemModel.CLASS_NAME = 'LuckySpinItemModel';
    return LuckySpinItemModel;
}(cfw_1.DataModel));
exports.default = LuckySpinItemModel;

cc._RF.pop();