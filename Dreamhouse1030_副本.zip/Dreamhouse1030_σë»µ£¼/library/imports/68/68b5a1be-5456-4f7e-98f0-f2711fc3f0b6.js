"use strict";
cc._RF.push(module, '68b5aG+VFZPfpjw8nEfw/C2', 'CocosBannerAd');
// Script/sdk/sdk/cocos/CocosBannerAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDKConfig_1 = require("../SDKConfig");
var BaseBannerAd_1 = require("../base/BaseBannerAd");
var CocosBannerAd = /** @class */ (function (_super) {
    __extends(CocosBannerAd, _super);
    function CocosBannerAd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CocosBannerAd.prototype.create = function () {
        if (!this.bannerAd) {
            this.bannerAd = this.sdk.createBannerAd(SDKConfig_1.ADName.banner, this.adUnitID, 2);
            this.bannerAd.onLoad(this.onLoad.bind(this));
            this.bannerAd.onError(this.onError.bind(this));
        }
    };
    return CocosBannerAd;
}(BaseBannerAd_1.default));
exports.default = CocosBannerAd;

cc._RF.pop();