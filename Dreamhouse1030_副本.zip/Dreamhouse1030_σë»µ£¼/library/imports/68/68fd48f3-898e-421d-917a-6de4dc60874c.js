"use strict";
cc._RF.push(module, '68fd4jziY5CHZF6beTcYIdM', 'BaseHelper');
// Script/sdk/channel-ts/BaseHelper.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SDKManager_1 = require("../sdk/SDKManager");
var DailyTaskMgr_1 = require("../../logic/dailytask/model/DailyTaskMgr");
var Config_1 = require("../../config/Config");
var Debug_1 = require("../../cfw/tools/Debug");
var BagManager_1 = require("../../logic/public/bag/BagManager");
var EngineHelper_1 = require("../../engine/EngineHelper");
var LobbyC_1 = require("../../logic/lobby/LobbyC");
var osMap = {
    'Android': 'android',
    "iOS": 'ios'
};
var BaseHelper = /** @class */ (function () {
    // protected c: BaseChannel;
    function BaseHelper() {
        this.verson = '1.0';
        this.adData = [];
        Debug_1.default.isDebug = false;
    }
    // set channel(c: BaseChannel) {
    //     this.c = c;
    // }
    // get channel() {
    //     return this.c;
    // }
    BaseHelper.prototype.isF399 = function () {
        return false;
    };
    BaseHelper.prototype.trackEvent = function (eventID, param) {
        SDKManager_1.default.getChannel().trackEvent(eventID, param);
    };
    BaseHelper.prototype.hasEmail = function () {
        return true;
    };
    BaseHelper.prototype.getVersion = function () {
        return this.verson;
    };
    BaseHelper.prototype.marketHasType = function (type) {
        if (type == 4) {
            return SDKManager_1.default.getChannel().hasShare();
        }
        return true;
    };
    BaseHelper.prototype.showShare = function (site, callback, videoPath) {
        SDKManager_1.default.getChannel().showShare(site, callback, videoPath);
    };
    BaseHelper.prototype.showFuncInsertAd = function (site) {
        SDKManager_1.default.getChannel().showInsertAd(site);
    };
    BaseHelper.prototype.showInsertAd = function (site) {
        SDKManager_1.default.getChannel().showInsertAd(site);
    };
    BaseHelper.prototype.showRewardAd = function (site, callback) {
        var _this = this;
        SDKManager_1.default.getChannel().showRewardAd(site, function (r) {
            callback(r);
            if (r) {
                DailyTaskMgr_1.default.instance().updateTaskCount(Config_1.DailyTaskID.AD);
                if (!_this.canMultyAd()) {
                    BagManager_1.default.instance().updateItemNum(Config_1.ItemID.SCRATCH_CARD, 1, EngineHelper_1.default.getMidPos());
                }
            }
        });
    };
    BaseHelper.prototype.getBoxResult = function () {
        return 0;
    };
    BaseHelper.prototype.isOpen = function () {
        return false;
    };
    BaseHelper.prototype.getBannerTime = function () {
        return 30;
    };
    BaseHelper.prototype.getAddress = function () {
        return '';
    };
    BaseHelper.prototype.getClickParent = function () {
        return [0.4, 0.7];
    };
    BaseHelper.prototype.getClickBack = function () {
        return 10;
    };
    BaseHelper.prototype.getClickAdd = function () {
        return 15;
    };
    BaseHelper.prototype.updateClickNum = function () {
    };
    BaseHelper.prototype.hideCustomAd = function (index) {
        SDKManager_1.default.getChannel().hideCustomAd(index);
    };
    BaseHelper.prototype.showCustomAd = function (index, rx, ry) {
        SDKManager_1.default.getChannel().showCustomAd(index, rx, ry);
    };
    BaseHelper.prototype.getEmail = function () {
        return '135024930@qq.com';
    };
    BaseHelper.prototype.hasAgreement = function () {
        return false;
    };
    BaseHelper.prototype.getAppName = function () {
        return '梦幻别院';
    };
    BaseHelper.prototype.getCompany = function () {
        return '北京旺兔航天科技有限公司';
    };
    BaseHelper.prototype.getClickResult = function () {
        return 0;
    };
    BaseHelper.prototype.setVersion = function (v) {
        this.verson = v;
    };
    BaseHelper.prototype.hasNativeNextLimit = function () {
        return false;
    };
    BaseHelper.prototype.hasFriend = function () {
        return false;
    };
    BaseHelper.prototype.getFriendDuration = function () {
        return 0;
    };
    BaseHelper.prototype.hasEgg = function () {
        return false;
    };
    BaseHelper.prototype.loadConfig = function () {
    };
    BaseHelper.prototype.hasNativeAd = function () {
        return false;
    };
    BaseHelper.prototype.login = function (param) {
    };
    BaseHelper.prototype.getProcessTime = function () {
        return 0;
    };
    BaseHelper.prototype.getBannerRefreshTime = function () {
        return 30;
    };
    BaseHelper.prototype.isShowAgain = function () {
        return false;
    };
    BaseHelper.prototype.getRewardNum = function () {
        return 1;
    };
    BaseHelper.prototype.isVersion = function () {
        return false;
    };
    BaseHelper.prototype.isOpenNativeErrorClick = function () {
        return false;
    };
    BaseHelper.prototype.isSwtichOpen = function () {
        return false;
    };
    BaseHelper.prototype.isSystemOpen = function () {
        return false;
    };
    BaseHelper.prototype.getBannerDelayTime = function () {
        return 2;
    };
    BaseHelper.prototype.getOS = function () {
        // return osMap[cc.sys.os]
        return '';
    };
    BaseHelper.prototype.isErrorClickOpen = function () {
        return false;
    };
    BaseHelper.prototype.isStartErrorClick = function () {
        return false;
    };
    BaseHelper.prototype.isBannerErrorClick = function () {
        return false;
    };
    BaseHelper.prototype.loadAd = function () {
    };
    BaseHelper.prototype.setAdClickParam = function (game) {
    };
    BaseHelper.prototype.getAdData = function () {
        return this.adData;
    };
    BaseHelper.prototype.refresh = function () {
    };
    BaseHelper.prototype.hasCrazyClick = function () {
        return false;
    };
    BaseHelper.prototype.sortAdData = function () {
    };
    BaseHelper.prototype.changeData = function (m) {
    };
    BaseHelper.prototype.toOtherGame = function (model, success, fail, complete) {
    };
    BaseHelper.prototype.navigate2Mini = function (model, success, fail, complete) {
    };
    //是否弹出开始游戏后的砸蛋界面
    BaseHelper.prototype.isOpenStartEgg = function () {
        // let loginCount = User.instance().getLoginCount();
        return false;
    };
    BaseHelper.prototype.firstExport = function () {
        return false;
    };
    BaseHelper.prototype.hasSinglePrivicy = function () {
        return true;
    };
    BaseHelper.prototype.hasNativeLimit = function () {
        return false;
    };
    BaseHelper.prototype.hasBigExport = function () {
        return false;
    };
    BaseHelper.prototype.hasLoginBanner = function () {
        return false;
    };
    BaseHelper.prototype.hasDiamonView = function () {
        return false;
    };
    BaseHelper.prototype.hasNativeTouchSwitch = function () {
        return false;
    };
    BaseHelper.prototype.cantUseImageDataURL = function () {
        return false;
    };
    BaseHelper.prototype.getNativeCloseNum = function () {
        return 0;
    };
    BaseHelper.prototype.getNativeBannerRefreshTime = function () {
        return 30;
    };
    BaseHelper.prototype.getJumpTime = function () {
        return 0;
    };
    BaseHelper.prototype.getBannerWitch = function () {
        return 0;
    };
    BaseHelper.prototype.getNativeSlide = function () {
        return false;
    };
    BaseHelper.prototype.hasBanner = function () {
        return false;
    };
    BaseHelper.prototype.getzs_native_gap_time = function () {
        return 0;
    };
    BaseHelper.prototype.getAdSprite = function () {
        return 'texture/gift_sprite/gift_sprite_1024x1024_A_01_4';
    };
    BaseHelper.prototype.getzs_native_show_delay = function () {
        return 0;
    };
    BaseHelper.prototype.getzs_start_native_switch = function () {
        return 0;
    };
    BaseHelper.prototype.isJumpSwitchOpen = function () {
        return false;
    };
    BaseHelper.prototype.getzs_native_btn_text = function () {
        return '';
    };
    BaseHelper.prototype.noOneMinAdLimit = function () {
        return false;
    };
    BaseHelper.prototype.hasMoreGame = function () {
        return false;
    };
    BaseHelper.prototype.openMoreGameView = function (index, rx, ry) {
        if (index === void 0) { index = 0; }
        if (rx === void 0) { rx = 0; }
        if (ry === void 0) { ry = 0; }
    };
    BaseHelper.prototype.getzs_box_switch = function () {
        return false;
    };
    BaseHelper.prototype.getzs_box_show_delay = function () {
        return 0;
    };
    BaseHelper.prototype.getzs_video_box = function () {
        return 0;
    };
    BaseHelper.prototype.getzs_start_turntable = function () {
        return false;
    };
    BaseHelper.prototype.getzs_native_change_switch = function () {
        return 0;
    };
    BaseHelper.prototype.showBannerAd = function (index, dir) {
        SDKManager_1.default.getChannel().showBanner(index, dir);
    };
    BaseHelper.prototype.hideBannerAd = function (index) {
        SDKManager_1.default.getChannel().hideBanner(index);
    };
    BaseHelper.prototype.hideFuncInsertAd = function (index) {
    };
    BaseHelper.prototype.hideInsertAd = function (index) {
    };
    BaseHelper.prototype.hasNormalShare = function () {
        return false;
    };
    BaseHelper.prototype.getClick_award_video = function () {
        return 0;
    };
    BaseHelper.prototype.getzs_banner_force_click = function () {
        return false;
    };
    BaseHelper.prototype.getzs_advert_change = function () {
        return 0;
    };
    BaseHelper.prototype.hasInstallApp = function () {
        return false;
    };
    BaseHelper.prototype.canMultyAd = function () {
        return true;
    };
    BaseHelper.prototype.intoGame = function () {
    };
    BaseHelper.prototype.getzs_native_click_switch = function () {
        return 0;
    };
    BaseHelper.prototype.sheduleGame = function () {
    };
    BaseHelper.prototype.leaveGame = function () {
    };
    BaseHelper.prototype.firstIntoLobby = function () {
    };
    BaseHelper.prototype.startGame = function () {
        LobbyC_1.default.instance().intoLayer();
    };
    BaseHelper.prototype.hasOnline = function () {
        return false;
    };
    BaseHelper.prototype.hasOffline = function () {
        return true;
    };
    BaseHelper.prototype.hasDailyTask = function () {
        return false;
    };
    BaseHelper.prototype.hasLuckySpin = function () {
        return true;
    };
    BaseHelper.prototype.hasGiftSpecial = function () {
        return true;
    };
    BaseHelper.prototype.hasSpecialtask = function () {
        return true;
    };
    return BaseHelper;
}());
exports.default = BaseHelper;

cc._RF.pop();