"use strict";
cc._RF.push(module, '9369aFB4sJPI5mXsL9hojWe', 'WXCustomAd');
// Script/sdk/sdk/wx/WXCustomAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDKConfig_1 = require("../SDKConfig");
var BaseCustomAd_1 = require("../base/BaseCustomAd");
var SDKHelper_1 = require("../SDKHelper");
var SDKEventID_1 = require("../third/SDKEventID");
// import SDKEventID from "../../third/SDKEventID";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var WXCustomAd = /** @class */ (function (_super) {
    __extends(WXCustomAd, _super);
    function WXCustomAd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    WXCustomAd.prototype.isOk = function () {
        // console.log('WXCustomAd isOk  this.state ', this.state)
        return !SDKHelper_1.default.isNull(this.customAd) && this.state != SDKConfig_1.SDKState.loading && this.state != SDKConfig_1.SDKState.loadFail;
    };
    WXCustomAd.prototype.open = function () {
        // console.log('WXCustomAd this.state ', this.state, this.adUnitID)
        this.preload(SDKConfig_1.SDKState.open);
        this.show();
    };
    WXCustomAd.prototype.load = function () {
        this.destroy();
        this.create();
    };
    WXCustomAd.prototype.updateSize = function () {
        var winSize = this.sdk.getSystemInfoSync();
        var left = winSize.windowWidth * this.rx;
        var top = winSize.windowHeight * this.ry;
        this.customAd.style.left = left;
        this.customAd.style.top = top;
    };
    WXCustomAd.prototype.getStyle = function () {
        var winSize = this.sdk.getSystemInfoSync();
        var left = winSize.windowWidth * this.rx;
        var top = winSize.windowHeight * this.ry;
        // let left = 0
        // let top = 0;
        return {
            left: left,
            top: top,
        };
    };
    WXCustomAd.prototype.create = function () {
        if (!this.customAd) {
            this.setState(SDKConfig_1.SDKState.loading);
            this.customAd = this.sdk.createCustomAd({
                adUnitId: this.adUnitID,
                adIntervals: 30,
                style: this.getStyle(),
            });
            this.customAd.onLoad(this.getFunc(SDKConfig_1.FunctionType.onLoad));
            this.customAd.onError(this.getFunc(SDKConfig_1.FunctionType.onError));
            // this.instance.onHide(this.getFunc(FunctionType.onHide));
            this.customAd.onClose(this.getFunc(SDKConfig_1.FunctionType.onClose));
        }
    };
    WXCustomAd.prototype.show = function () {
        if (this.customAd) {
            // this.setState(SDKState.open)
            this.customAd.show();
        }
        else {
            this.load();
            this.show();
        }
    };
    WXCustomAd.prototype.onClose = function () {
        // console.log('WXCustomAd onClose')
    };
    WXCustomAd.prototype.onError = function (err) {
        // console.log('WXCustomAd onError ', err)
        this.setState(SDKConfig_1.SDKState.loadFail);
        // this.channel.showToast('广告拉取失败')
        if (err && err.errCode)
            this.channel.trackEvent(SDKEventID_1.default.custom_ad_error, { code: err.errCode });
    };
    WXCustomAd.prototype.onHide = function () {
        // console.log('WXCustomAd onHide')
    };
    WXCustomAd.prototype.onLoad = function () {
        // console.log('WXCustomAd onLoad ')
        this.setState(SDKConfig_1.SDKState.loadSucess);
    };
    WXCustomAd.prototype.close = function () {
        this.hide();
    };
    WXCustomAd.prototype.hide = function () {
        if (this.customAd) {
            // console.log(' CustomAd hide', this.isShow())
            // if (this.isShow()) {
            if (this.customAd.hide)
                this.customAd.hide();
        }
    };
    WXCustomAd.prototype.isShow = function () {
        if (this.customAd) {
            return this.customAd.isShow();
        }
        return false;
    };
    WXCustomAd.prototype.destroy = function () {
        if (this.customAd) {
            this.customAd.offLoad(this.getFunc(SDKConfig_1.FunctionType.onLoad));
            this.customAd.offError(this.getFunc(SDKConfig_1.FunctionType.onError));
            // this.instance.offHide(this.getFunc(FunctionType.onHide))
            this.customAd.offClose(this.getFunc(SDKConfig_1.FunctionType.onClose));
            this.customAd.destroy();
            this.customAd = null;
        }
    };
    return WXCustomAd;
}(BaseCustomAd_1.default));
exports.default = WXCustomAd;

cc._RF.pop();