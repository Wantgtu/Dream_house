"use strict";
cc._RF.push(module, '934428yl8FB8qRQ5GJC72El', 'MiMoNativeAd');
// Script/sdk/sdk/mimo/MiMoNativeAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseNativeAd_1 = require("../base/BaseNativeAd");
var OppoNativeAdItemModel_1 = require("../oppo/OppoNativeAdItemModel");
var SDKConfig_1 = require("../SDKConfig");
var MiMoNativeAd = /** @class */ (function (_super) {
    __extends(MiMoNativeAd, _super);
    function MiMoNativeAd() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.instances = [];
        return _this;
    }
    MiMoNativeAd.prototype.getItemModel = function () {
        return new OppoNativeAdItemModel_1.default();
    };
    MiMoNativeAd.prototype.create = function () {
        console.log(" OppoNativeAd create", this.adUnitID);
        this.nativeAd = this.instances[this.adUnitID];
        if (!this.nativeAd) {
            this.nativeAd = this.sdk.createNativeAd({
                adUnitId: this.adUnitID,
            });
            this.nativeAd.onLoad(this.getFunc(SDKConfig_1.FunctionType.onLoad));
            this.nativeAd.onError(this.getFunc(SDKConfig_1.FunctionType.onError));
            this.instances[this.adUnitID] = this.nativeAd;
        }
    };
    return MiMoNativeAd;
}(BaseNativeAd_1.default));
exports.default = MiMoNativeAd;

cc._RF.pop();