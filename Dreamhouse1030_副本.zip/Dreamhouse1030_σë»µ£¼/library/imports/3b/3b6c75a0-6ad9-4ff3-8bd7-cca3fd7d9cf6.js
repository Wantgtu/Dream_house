"use strict";
cc._RF.push(module, '3b6c7WgatlP84vXzKP9fZz2', 'SelectFoodView');
// Script/logic/game/view/SelectFoodView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../cfw/view");
var engine_1 = require("../../../engine/engine");
var SelectFoodItemView_1 = require("./SelectFoodItemView");
var FoodMgr_1 = require("../model/FoodMgr");
var RadioButtonMgr_1 = require("../../../cfw/widget/RadioButtonMgr");
var Config_1 = require("../../../config/Config");
var GameC_1 = require("../GameC");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SelectFoodView = /** @class */ (function (_super) {
    __extends(SelectFoodView, _super);
    function SelectFoodView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.foodIconSprite = null;
        _this.layoutLayout = null;
        _this.play_smallSprite = null;
        _this.backBtnSprite = null;
        _this.backBtnButton = null;
        _this.itemPrefab = null;
        _this.radioButtonMgr = new RadioButtonMgr_1.default();
        return _this;
    }
    SelectFoodView.prototype.onEnter = function () {
        this.play_smallSprite.node.active = false;
        var list = this.model.getOutput();
        for (var index = 0; index < list.length; index++) {
            var foodID = list[index];
            var node = engine_1.engine.instantiate(this.itemPrefab);
            if (node) {
                var item = node.getComponent(SelectFoodItemView_1.default);
                if (item) {
                    var model = FoodMgr_1.default.instance().getFoodItemModel(foodID);
                    if (model) {
                        item.setModel(model);
                        this.layoutLayout.node.addChild(node);
                        this.radioButtonMgr.add(item);
                    }
                }
            }
        }
        this.gEventProxy.on(Config_1.EventName.SELECT_FOOD, this.selectFood, this);
        this.setSpriteAtlas(this.foodIconSprite, this.model.getModuleID(), this.model.getIcon(), this.model.getSpriteFrame());
    };
    SelectFoodView.prototype.selectFood = function (food) {
        this.radioButtonMgr.setRadioButtonState(food);
        if (!this.play_smallSprite.node.active) {
            this.play_smallSprite.node.active = true;
        }
    };
    SelectFoodView.prototype.onbackBtnButtonClick = function () {
        this.hide();
    };
    SelectFoodView.prototype.onSelectBtnClick = function () {
        this.hide();
        GameC_1.default.instance().clickSelectOK();
    };
    __decorate([
        property({ type: cc.Sprite, displayName: "foodIconSprite" })
    ], SelectFoodView.prototype, "foodIconSprite", void 0);
    __decorate([
        property({ type: cc.Layout, displayName: "layoutLayout" })
    ], SelectFoodView.prototype, "layoutLayout", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "play_smallSprite" })
    ], SelectFoodView.prototype, "play_smallSprite", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "backBtnSprite" })
    ], SelectFoodView.prototype, "backBtnSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "backBtnButton" })
    ], SelectFoodView.prototype, "backBtnButton", void 0);
    __decorate([
        property(cc.Prefab)
    ], SelectFoodView.prototype, "itemPrefab", void 0);
    SelectFoodView = __decorate([
        ccclass
    ], SelectFoodView);
    return SelectFoodView;
}(view_1.BaseView));
exports.default = SelectFoodView;

cc._RF.pop();