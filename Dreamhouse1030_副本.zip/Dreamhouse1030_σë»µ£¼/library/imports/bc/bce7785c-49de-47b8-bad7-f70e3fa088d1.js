"use strict";
cc._RF.push(module, 'bce77hcSd5HuLrX9w4/oIjR', 'Utils');
// Script/cfw/tools/Utils.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 我们目前所用的K、M、G、T等都是英文表示方法，分别是Kilo（103）、Mega（106）、Giga（109）、Tera（1012）的简写，
 * 更大的还有Peta（1015）、Exa（1018）、Bronto（1021）等。
 */
var moneyNum = [1000000000000000000000, 1000000000000000000, 1000000000000000, 1000000000000, 1000000000, 1000000, 1000, 1];
var moneyText = ['b', 'e', 'p', 't', 'g', 'm', 'k', ''];
var Utils = /** @class */ (function () {
    function Utils() {
    }
    /**
     * s = at*at/2
     * @param a
     * @param s
     */
    Utils.getVy = function (a, s) {
        var h = 0;
        var v0 = 0;
        var t = 0;
        if (a > 0) {
            while (h < s) {
                v0 += a;
                h += v0;
                t++;
            }
        }
        return v0;
    };
    Utils.replace = function (str, key, value) {
        str = str.replace("%{" + key + "}", value);
        return str;
    };
    Utils.replaceOpt = function (str, opt) {
        if (str) {
            if (str.indexOf('\\') >= 0) {
                str = str.replace(/\\n/g, '\n');
            }
            if (opt) {
                for (var key in opt) {
                    // let option:LangOption = opt[key];
                    var value = opt[key];
                    // if(option.getType() == LangOptionType.LANG_ID){
                    //     value = this.data.getValue(value);
                    // }
                    // console.log(' key ',key,' value ',value)
                    str = str.replace("%{" + key + "}", value);
                    // console.log(' str ',str)
                }
            }
        }
        return str;
    };
    /**
     * 获取最后一个字符串
     * @param str
     * @param tag
     */
    Utils.laststring = function (str, tag) {
        var index = str.indexOf(tag);
        if (index >= 0) {
            var list = str.split(tag);
            return list[list.length - 1];
        }
        return str;
    };
    /**
     *
     * @param num
     */
    Utils.getShortStr = function (num, len) {
        if (len === void 0) { len = 100; }
        var i = moneyNum.length - 1;
        var money = 0;
        for (var index = 0; index < moneyNum.length; index++) {
            var element = moneyNum[index];
            if (num >= element) {
                i = index;
                money = Math.floor(num * len / element);
                break;
            }
        }
        var tail = moneyText[i];
        return (money / len) + tail;
    };
    Utils.getRandomValueByList = function (randomList) {
        var r = 0;
        var step = 2;
        var count = randomList.length / step;
        for (var index = 0; index < count; index++) {
            var num = randomList[index * step];
            var random = randomList[index * step + 1];
            r += random;
            var ran = this.random(0, 100);
            if (ran <= r) {
                return num;
            }
        }
        return 0;
    };
    Utils.random = function (start, end) {
        if (end) {
            return Math.floor(Math.random() * (end - start) + start);
        }
        else {
            return Math.floor(Math.random() * start);
        }
    };
    Utils.randomFloat = function (min, max) {
        return Math.random() * (max - min) + min;
    };
    /**
  *
  * @param x1
  * @param y1
  * @param x2
  * @param y2
  */
    Utils.distance = function (x1, y1, x2, y2) {
        var dx = x1 - x2;
        var dy = y1 - y2;
        var distance = Math.sqrt(dx * dx + dy * dy);
        return distance;
    };
    /**
     * 根据角度获得弧度
     * @param radian
     */
    Utils.getAngleByRadian = function (radian) {
        return radian * 57.3;
    };
    Utils.getRadinByAngle = function (angle) {
        return angle / 57.3;
    };
    /**
     * 获得弧度
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     */
    Utils.getRadianByXY = function (x1, y1, x2, y2) {
        var disx = Math.abs(x2 - x1);
        var disy = Math.abs(y2 - y1);
        var dis = Math.sqrt(disx * disx + disy * disy);
        var radian = Math.asin(disx / dis);
        return radian;
    };
    Utils.getRadianByXY2 = function (x1, y1, x2, y2) {
        var disx = Math.abs(x2 - x1);
        var disy = Math.abs(y2 - y1);
        var dis = Math.sqrt(disx * disx + disy * disy);
        var radian = Math.acos(disx / dis);
        return radian;
    };
    /**
     * 获得角度
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     */
    Utils.getAngleByXY = function (x1, y1, x2, y2) {
        return this.getRadianByXY(x1, y1, x2, y2) * Math.PI;
    };
    Utils.isRectCollideRect2 = function (x1, width1, x2, width2) {
        var flag = !(x2 + width2 < x1 || x2 > x1 + width1);
        return flag;
    };
    Utils.isRecctCollideRect3 = function (left1, right1, top1, bottom1, left2, right2, top2, bottom2) {
        var flag = !(right2 < left1 || bottom2 < top1 || left2 > right1 || top2 > bottom1);
        return flag;
    };
    Utils.isRecctCollideRect = function (left1, right1, top1, bottom1, left2, right2, top2, bottom2) {
        var flag = !(right2 < left1 || bottom2 > top1 || left2 > right1 || top2 < bottom1);
        return flag;
    };
    Utils.isRectCollideAnchor = function (x1, y1, w1, h1, a1x, a1y, x2, y2, w2, h2, a2x, a2y) {
        var left1 = x1 - (w1 * a1x);
        var right1 = left1 + w1;
        var bottom1 = y1 - (h1 * a1y);
        var top1 = bottom1 + h1;
        var left2 = x2 - (w2 * a2x);
        var right2 = left2 + w2;
        var bottom2 = y2 - (h2 * a2y);
        var top2 = bottom2 + h2;
        return this.isRecctCollideRect(left1, right1, top1, bottom1, left2, right2, top2, bottom2);
    };
    Utils.isRectCollideAnchorScale = function (x1, y1, w1, h1, a1x, a1y, s1, x2, y2, w2, h2, a2x, a2y, s2) {
        var left1 = x1 - (w1 * s1 * a1x);
        var right1 = left1 + w1 * s1;
        var bottom1 = y1 - (h1 * s1 * a1y);
        var top1 = bottom1 + h1 * s1;
        var left2 = x2 - (w2 * s2 * a2x);
        var right2 = left2 + w2 * s2;
        var bottom2 = y2 - (h2 * s2 * a2y);
        var top2 = bottom2 + h2 * s2;
        return this.isRecctCollideRect(left1, right1, top1, bottom1, left2, right2, top2, bottom2);
    };
    Utils.isRectCollide = function (r1, r2) {
        var flag = !(r2.right < r1.left || r2.bottom > r1.top || r2.left > r1.right || r2.top < r1.bottom);
        return flag;
    };
    Utils.isXYInRect = function (x, y, rect) {
        return x <= rect.right && x >= rect.left && y <= rect.top && y >= rect.bottom;
    };
    /**
     *
     * @param x
     * @param y
     * @param x2
     * @param y2
     * @param width
     * @param height
     * @param an
     * @param des
     */
    Utils.isPosInRect = function (x, y, x2, y2, width, height, anx, any) {
        var left = x2 - width * anx;
        var buttom = y2 - height * any;
        var flag1 = x <= left + width;
        var flag2 = x >= left;
        var flag3 = y <= buttom + height;
        var flag4 = y >= buttom;
        return flag1 && flag2 && flag3 && flag4;
    };
    /**
     * 物体是否已经出屏
     * @param x
     * @param y
     * @param size
     */
    Utils.isOutScreen = function (x, y, w, h, dw, dh) {
        // let screen = cc.view.getFrameSize();
        var hw = w / 2;
        var hh = h / 2;
        var flag = x < -hw || x > dw + hw || y > dh + hh || y < -hh;
        if (flag) {
            // cc.log('isOutScreen width ',dw,' height ',dh,' x ',x,' y ',y,' flag ',flag)
        }
        return flag;
    };
    /**
     * 物体是否已经出屏
     * @param x
     * @param y
     * @param size
     */
    Utils.isOutScreenExceptTop = function (x, y, w, h, dw, dh) {
        // let screen = cc.view.getFrameSize();
        var hw = w / 2;
        var hh = h / 2;
        var flag = x < -hw || x > dw + hw || y < -hh;
        if (flag) {
            // cc.log('isEnemyOutScreen width ',dw,' height ',dh,' x ',x,' y ',y,' flag ',flag)
        }
        //
        return flag;
    };
    Utils.isNull = function (obj) {
        return obj == undefined || obj == null;
    };
    Utils.sendHttpRequest = function (address, data, callback, method) {
        if (method === void 0) { method = "GET"; }
        console.log('sendHttpRequest  address ', address);
        var xhr = new XMLHttpRequest();
        xhr.timeout = 15000;
        xhr.ontimeout = function () {
            callback('ontimeout ', null);
        };
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 400) {
                var data = xhr.responseText;
                callback(null, data);
            }
            else {
                callback('onload error ', null);
            }
        };
        if (method == 'GET') {
            address = address + "?" + data;
            xhr.open(method, address);
            try {
                xhr.send();
            }
            catch (error) {
                callback('get error ' + error, null);
            }
        }
        else {
            // post请求
            xhr.open(method, address);
            try {
                xhr.send(data);
            }
            catch (error) {
                callback('POST error ' + error, null);
            }
        }
    };
    Utils.uint8ArrayToString = function (fileData) {
        var dataString = "";
        for (var i = 0; i < fileData.length; i++) {
            dataString += String.fromCharCode(fileData[i]);
        }
        return dataString;
    };
    Utils.stringToUint8Array = function (str) {
        var arr = [];
        for (var i = 0, j = str.length; i < j; ++i) {
            arr.push(str.charCodeAt(i));
        }
        var tmpUint8Array = new Uint8Array(arr);
        return tmpUint8Array;
    };
    Utils.compareVersion = function (v1, v2) {
        v1 = v1.split('.');
        v2 = v2.split('.');
        var len = Math.max(v1.length, v2.length);
        while (v1.length < len) {
            v1.push('0');
        }
        while (v2.length < len) {
            v2.push('0');
        }
        for (var i = 0; i < len; i++) {
            var num1 = parseInt(v1[i]);
            var num2 = parseInt(v2[i]);
            if (num1 > num2) {
                return 2;
            }
            else if (num1 < num2) {
                return 0;
            }
        }
        return 1;
    };
    //x,y,width,height是cocos坐标的节点的中心点位置和长高
    Utils.convertToSDKStyle = function (centerX, centerY, width, height, screenWidth, screenHeight, visibleSize) {
        var scaleValue = visibleSize.height / screenHeight;
        var wxWidth = width / scaleValue;
        var wxHeight = height / scaleValue;
        var left = (centerX / scaleValue) - wxWidth / 2;
        var top = screenHeight - centerY / scaleValue - wxHeight / 2;
        var result = { left: left, top: top, width: wxWidth, height: wxHeight };
        return result;
    };
    return Utils;
}());
exports.default = Utils;

cc._RF.pop();