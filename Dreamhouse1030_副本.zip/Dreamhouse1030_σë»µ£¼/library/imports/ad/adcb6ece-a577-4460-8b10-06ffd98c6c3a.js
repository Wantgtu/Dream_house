"use strict";
cc._RF.push(module, 'adcb67OpXdEYIsQBv/ZjGw6', 'BaseSDK');
// Script/sdk/sdk/base/BaseSDK.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var BindFunction_1 = require("../tools/BindFunction");
var BaseSDK = /** @class */ (function () {
    function BaseSDK(sdk) {
        this.setSDK(sdk);
        this.funcHelper = new BindFunction_1.default();
    }
    BaseSDK.prototype.getFunc = function (func) {
        return this.funcHelper.getFunc(func, this);
    };
    BaseSDK.prototype.setSDK = function (sdk) {
        this.sdk = sdk;
        // console.log(' BaseSDK sdk ====== ', this.sdk)
    };
    BaseSDK.prototype.getSDK = function () {
        return this.sdk;
    };
    return BaseSDK;
}());
exports.default = BaseSDK;

cc._RF.pop();