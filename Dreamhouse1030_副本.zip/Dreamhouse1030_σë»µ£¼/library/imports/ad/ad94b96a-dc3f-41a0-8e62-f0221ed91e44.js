"use strict";
cc._RF.push(module, 'ad94blq3D9BoI5i8CIe2R5E', 'BuyTaskItemView');
// Script/logic/buy/view/BuyTaskItemView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../cfw/view");
var TaskC_1 = require("../../task/TaskC");
var TaskMgr_1 = require("../../task/model/TaskMgr");
var model_1 = require("../../../cfw/model");
var Config_1 = require("../../../config/Config");
var GuideMgr_1 = require("../../../extention/guide/GuideMgr");
var SoundMgr_1 = require("../../sound/model/SoundMgr");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BuyTaskItemView = /** @class */ (function (_super) {
    __extends(BuyTaskItemView, _super);
    function BuyTaskItemView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BuyTaskItemView.prototype.setGameView = function (gv) {
        this.gameView = gv;
    };
    BuyTaskItemView.prototype.onButtonClick = function () {
        GuideMgr_1.default.instance().notify('onTaskBtnClick');
        TaskC_1.default.instance().intoLayer();
    };
    BuyTaskItemView.prototype.getOrder = function () {
        return 10;
    };
    BuyTaskItemView.prototype.start = function () {
        this.gEventProxy.on(Config_1.EventName.UPDATE_TASK_STATE, this.updateTaskState, this);
        this.updateTaskState();
    };
    BuyTaskItemView.prototype.updateTaskState = function () {
        var task = TaskMgr_1.default.instance().getCurTask();
        // let node = this.ScrollView.content.getChildByName('BuyTaskItemView')
        if (task && task.getState() == model_1.ItemState.CAN_GET) {
            this.node.active = true;
            SoundMgr_1.default.instance().playSound(Config_1.SoundID.sfx_greenTick);
            this.popAnim();
        }
        else {
            this.node.active = false;
        }
    };
    BuyTaskItemView.prototype.popAnim = function () {
        cc.tween(this.node).by(0.2, { scale: 0.4 }).by(0.2, { scale: -0.4 }).start();
    };
    BuyTaskItemView = __decorate([
        ccclass
    ], BuyTaskItemView);
    return BuyTaskItemView;
}(view_1.BaseItemView));
exports.default = BuyTaskItemView;

cc._RF.pop();