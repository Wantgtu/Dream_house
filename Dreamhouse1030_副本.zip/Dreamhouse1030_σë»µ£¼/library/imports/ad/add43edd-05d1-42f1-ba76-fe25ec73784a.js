"use strict";
cc._RF.push(module, 'add437dBdFC8bp2/iXsc3hK', 'RecorderC');
// Script/sdk/recorder/RecorderC.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var ui_1 = require("../../cfw/ui");
var SDKManager_1 = require("../sdk/SDKManager");
var BagManager_1 = require("../../logic/public/bag/BagManager");
var EngineHelper_1 = require("../../engine/EngineHelper");
var TipC_1 = require("../../logic/public/tip/TipC");
var CMgr_1 = require("../channel-ts/CMgr");
var UmengEventID_1 = require("../../config/UmengEventID");
var ShareController_1 = require("./ShareController");
var RecorderC = /** @class */ (function (_super) {
    __extends(RecorderC, _super);
    function RecorderC() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    RecorderC.prototype.stopRecorder = function (view) {
        var _this = this;
        // console.log(' stopRecorder ')
        console.log('------------------------------------------');
        var recorder = SDKManager_1.default.getChannel().getRecorder();
        recorder.stop(true, function (r) {
            // console.log(' 录屏裁剪结果 stop r ', r, recorder.getVideoPath())
            if (r) {
                recorder.publish(function (s) {
                    // console.log(' 录屏分享结果 s ', s)
                    if (s) {
                        // MoneyMgr.instance().updateGoldNum(GOLD_NUM)
                        CMgr_1.default.helper.trackEvent(UmengEventID_1.default.buy_energy_use_share);
                        BagManager_1.default.instance().updateItem(_this.getItem(), EngineHelper_1.default.getMidPos());
                    }
                    else {
                        // console.log(' 录屏分享失败 s ', s)
                        TipC_1.default.instance().showToast('分享失败');
                    }
                    _this.startRecorder();
                    ui_1.default.instance().popView(view);
                });
                // SDKManager.getChannel().showShare(0, (s: number) => {
                //     // console.log(' 录屏分享结果 s ', s)
                //     if (s) {
                //         // MoneyMgr.instance().updateGoldNum(GOLD_NUM)
                //         CMgr.helper.trackEvent(UmengEventID.buy_energy_use_share)
                //         BagManager.instance().updateItem(this.getItem(), EngineHelper.getMidPos())
                //     } else {
                //         // console.log(' 录屏分享失败 s ', s)
                //         TipC.instance().showToast('分享失败')
                //     }
                //     this.startRecorder();
                //     UIManager.instance().popView(view)
                // }, recorder.getVideoPath())
                recorder.clear();
            }
            else {
                // console.log(' 屏幕录制失败 r ', r)
                // SDKManager.getChannel().showShare(1, (rs: number) => {
                //     if (rs) {
                //         CMgr.helper.trackEvent(UmengEventID.buy_energy_use_share)
                //         BagManager.instance().updateItem(this.getItem(), EngineHelper.getMidPos())
                //     } else {
                //         TipC.instance().showToast('分享失败')
                //     }
                //     this.startRecorder();
                //     UIManager.instance().popView(view)
                // }, null)
                TipC_1.default.instance().showToast('录屏时间太短');
            }
            // console.log('++++++++++++++++++++++++++++++++++++++')
        });
    };
    RecorderC.prototype.startRecorder = function () {
        // let recorder = SDKManager.getChannel().getRecorder()
        var recorder = SDKManager_1.default.getChannel().getRecorder();
        if (recorder) {
            recorder.start();
        }
    };
    return RecorderC;
}(ShareController_1.default));
exports.default = RecorderC;

cc._RF.pop();