"use strict";
cc._RF.push(module, '3380ef1e7ZMR5sDv78oA/gg', 'DialogItemView');
// Script/extention/dialog/view/DialogItemView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../cfw/view");
var Define_1 = require("../../../cfw/tools/Define");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var DialogItemView = /** @class */ (function (_super) {
    __extends(DialogItemView, _super);
    function DialogItemView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label = null;
        _this.personName = null;
        _this.personIcon = [];
        _this.person = [];
        return _this;
    }
    DialogItemView.prototype.content = function () {
        this.node.scale = 0;
        this.label.string = this.model.getContent();
        var dir = this.model.getDir();
        var person = this.model.getPerson();
        if (person) {
            this.person[dir].active = true;
            var odir = Define_1.OPPSITE_DIR[dir];
            this.person[odir].active = false;
            this.personName.string = person.getName();
            var icon = person.getEmoji(this.model.getEmoji());
            this.setSpriteAtlas(this.personIcon[dir], person.getModuleID(), person.getIcon(), icon);
        }
        cc.tween(this.node).to(0.2, { scale: 1.2 }).to(0.2, { scale: 1 }).start();
    };
    __decorate([
        property(cc.Label)
    ], DialogItemView.prototype, "label", void 0);
    __decorate([
        property(cc.Label)
    ], DialogItemView.prototype, "personName", void 0);
    __decorate([
        property([cc.Sprite])
    ], DialogItemView.prototype, "personIcon", void 0);
    __decorate([
        property([cc.Node])
    ], DialogItemView.prototype, "person", void 0);
    DialogItemView = __decorate([
        ccclass
    ], DialogItemView);
    return DialogItemView;
}(view_1.BaseItemView));
exports.default = DialogItemView;

cc._RF.pop();