"use strict";
cc._RF.push(module, '33555MBEeNPw5OyISY7zSR5', 'GameTipModel');
// Script/extention/gameTip/model/GameTipModel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameTipModelEnum = void 0;
var cfw_1 = require("../../../cfw/cfw");
var GameTipModelEnum;
(function (GameTipModelEnum) {
    GameTipModelEnum[GameTipModelEnum["content"] = 0] = "content";
    GameTipModelEnum[GameTipModelEnum["isSkip"] = 1] = "isSkip";
    GameTipModelEnum[GameTipModelEnum["x"] = 2] = "x";
    GameTipModelEnum[GameTipModelEnum["y"] = 3] = "y";
})(GameTipModelEnum = exports.GameTipModelEnum || (exports.GameTipModelEnum = {}));
/**
* 提示表
**/
var GameTipModel = /** @class */ (function (_super) {
    __extends(GameTipModel, _super);
    function GameTipModel() {
        return _super.call(this, GameTipModel.CLASS_NAME) || this;
    }
    // 提示内容
    GameTipModel.prototype.getContent = function () {
        return this.getValue(GameTipModelEnum.content);
        // let langID = this.getValue(GameTipModelEnum.content)
        // return LangManager.instance().getLocalString(langID)
    };
    // 是否直接跳过
    GameTipModel.prototype.getIsSkip = function () {
        return this.getValue(GameTipModelEnum.isSkip);
    };
    // 屏幕x
    GameTipModel.prototype.getX = function () {
        return this.getValue(GameTipModelEnum.x);
    };
    // 屏幕y
    GameTipModel.prototype.getY = function () {
        return this.getValue(GameTipModelEnum.y);
    };
    GameTipModel.CLASS_NAME = 'GameTipModel';
    return GameTipModel;
}(cfw_1.DataModel));
exports.default = GameTipModel;

cc._RF.pop();