"use strict";
cc._RF.push(module, '3353dUzk3xGebHuvGP48bHg', 'event');
// Script/cfw/event.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GEventProxy = exports.GEvent = exports.EventProxy = exports.EventDispatcher = void 0;
var EventTarget = /** @class */ (function () {
    function EventTarget() {
    }
    return EventTarget;
}());
var EventDispatcher = /** @class */ (function () {
    function EventDispatcher() {
        this.eventHash = {};
    }
    EventDispatcher.prototype.offAll = function () {
        this.eventHash = {};
    };
    EventDispatcher.prototype.offByName = function (type) {
        this.eventHash[type] = [];
    };
    EventDispatcher.prototype.clearByTarget = function (type, ower) {
        var events = this.eventHash[type];
        if (events && events.length > 0) {
            for (var index = 0; index < events.length; index++) {
                var event = events[index];
                if (event.ower === ower) {
                    events.splice(index, 1);
                    break;
                }
            }
        }
    };
    EventDispatcher.prototype.on = function (type, cb, ower) {
        var index = this.has(type, cb, ower);
        if (index >= 0) {
            return;
        }
        if (!this.eventHash[type]) {
            this.eventHash[type] = [];
        }
        var event = new EventTarget();
        event.ower = ower;
        event.type = type;
        event.cb = cb;
        this.eventHash[type].push(event);
    };
    ;
    EventDispatcher.prototype.has = function (type, cb, ower) {
        var events = this.eventHash[type];
        if (events && events.length > 0) {
            for (var index = 0; index < events.length; index++) {
                var event = events[index];
                if (event.ower === ower && event.cb === cb) {
                    return index;
                }
            }
        }
        return -1;
    };
    EventDispatcher.prototype.off = function (type, cb, ower) {
        var events = this.eventHash[type];
        if (events && events.length > 0) {
            for (var index = 0; index < events.length; index++) {
                var event = events[index];
                if (event.ower === ower && event.cb === cb) {
                    events.splice(index, 1);
                    break;
                }
            }
        }
    };
    EventDispatcher.prototype.emit = function (type) {
        var _a;
        var data = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            data[_i - 1] = arguments[_i];
        }
        var events = this.eventHash[type];
        if (events && events.length > 0) {
            for (var index = 0; index < events.length; index++) {
                var event = events[index];
                (_a = event.cb).call.apply(_a, __spreadArrays([event.ower], data));
            }
        }
    };
    return EventDispatcher;
}());
exports.EventDispatcher = EventDispatcher;
var EventProxy = /** @class */ (function () {
    function EventProxy() {
        this.eventMap = {};
        this.count = 0;
    }
    EventProxy.prototype.setDispatcher = function (dispatcher) {
        this.dispatcher = dispatcher;
        this.count = 0;
    };
    EventProxy.prototype.on = function (eventName, func, target) {
        this.count++;
        if (!this.eventMap[eventName]) {
            this.dispatcher.on(eventName, func, target);
            this.eventMap[eventName] = { eventName: eventName, target: target, func: func };
        }
    };
    EventProxy.prototype.has = function (eventName) {
        return this.eventMap[eventName] != undefined;
    };
    EventProxy.prototype.offAll = function () {
        if (this.dispatcher) {
            for (var key in this.eventMap) {
                var element = this.eventMap[key];
                this.count--;
                this.dispatcher.off(element.eventName, element.func, element.target);
            }
            this.eventMap = {};
        }
    };
    return EventProxy;
}());
exports.EventProxy = EventProxy;
var GEvent = /** @class */ (function (_super) {
    __extends(GEvent, _super);
    function GEvent() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    GEvent.instance = function () {
        if (!this.ins) {
            this.ins = new this();
        }
        return this.ins;
    };
    GEvent.prototype.pause = function () {
        this.emit(GEvent.EVENT_HIDE);
    };
    GEvent.prototype.resume = function () {
        this.emit(GEvent.EVENT_SHOW);
    };
    GEvent.EVENT_HIDE = 'EVENT_HIDE';
    GEvent.EVENT_SHOW = 'EVENT_SHOW';
    GEvent.CHANGE_AD_STATE = 'EVENT_CHANGE_AD_STATE';
    GEvent.POP_VIEW = 'POP_VIEW';
    GEvent.CHANGE_LANG = 'CHANGE_LANG';
    return GEvent;
}(EventDispatcher));
exports.GEvent = GEvent;
var GEventProxy = /** @class */ (function (_super) {
    __extends(GEventProxy, _super);
    function GEventProxy() {
        var _this = _super.call(this) || this;
        _this.setDispatcher(GEvent.instance());
        return _this;
    }
    return GEventProxy;
}(EventProxy));
exports.GEventProxy = GEventProxy;

cc._RF.pop();