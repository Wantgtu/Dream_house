"use strict";
cc._RF.push(module, 'be88fR60wFMj4OI6m9H+Q6m', 'BaseBlockAd');
// Script/sdk/sdk/base/BaseBlockAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseAd_1 = require("./BaseAd");
var SDKConfig_1 = require("../SDKConfig");
var BaseBlockAd = /** @class */ (function (_super) {
    __extends(BaseBlockAd, _super);
    function BaseBlockAd() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._x = 0;
        _this._y = 0;
        _this._dir = SDKConfig_1.ADDir.vertical;
        _this.count = 1;
        return _this;
    }
    BaseBlockAd.prototype.setDir = function (dir) {
        this._dir = dir;
    };
    BaseBlockAd.prototype.setPosition = function (x, y) {
        this._x = x;
        this._y = y;
    };
    BaseBlockAd.prototype.setCount = function (c) {
        if (this.count != c) {
            this.setState(SDKConfig_1.SDKState.close);
            this.count = c;
        }
    };
    return BaseBlockAd;
}(BaseAd_1.default));
exports.default = BaseBlockAd;

cc._RF.pop();