"use strict";
cc._RF.push(module, '32304h8hkFKk6I4lbT9XrDL', 'state');
// Script/cfw/state.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimpleActionManager = exports.NPCManager = exports.GameState = void 0;
var Component3D_1 = require("../engine/Component3D");
var GameState = /** @class */ (function (_super) {
    __extends(GameState, _super);
    function GameState() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.state = 0;
        _this.preState = -1;
        //每个状态存储的数据
        _this.data = [];
        return _this;
    }
    /**
     * 行动开始
     * @param s
     * @param param
     */
    GameState.prototype.changeState = function (s, param) {
        this.endState(param);
        this.preState = this.state;
        this.setState(s);
        this.beginState(param);
    };
    GameState.prototype.getPreState = function () {
        return this.preState;
    };
    GameState.prototype.beginState = function (param) {
    };
    GameState.prototype.endState = function (param) {
    };
    GameState.prototype.setState = function (s) {
        this.state = s;
    };
    GameState.prototype.getState = function () {
        return this.state;
    };
    //行动更新,
    /**
     * 每帧更新
     * @param dt 每帧间隔时间
     * @param s 状态
     * @param param 附加参数
     */
    GameState.prototype.updateState = function (dt, param) {
    };
    return GameState;
}(Component3D_1.default));
exports.GameState = GameState;
/**
 * cgw 20200923
 * 对象管理器，可以做为对象池使用。
 */
var NPCManager = /** @class */ (function () {
    function NPCManager() {
        this.npcList = [];
        this.removeList = [];
        this.buffer = [];
    }
    /**
     * 添加
     * @param item
     */
    NPCManager.prototype.push = function (item) {
        this.npcList.push(item);
    };
    /**
     * 移除，为了不破坏迭代器，不会马上从数组中移除
     * 而且先缓存到另一个数组中
     * @param item
     */
    NPCManager.prototype.remove = function (item) {
        this.removeList.push(item);
    };
    /**
     * 回收对象
     */
    NPCManager.prototype.recover = function () {
        while (this.removeList.length > 0) {
            var item = this.removeList.shift();
            this.delete(item);
        }
    };
    NPCManager.prototype.recoverAll = function () {
        for (var index = 0; index < this.npcList.length; index++) {
            var element = this.npcList[index];
            this.buffer.push(element);
        }
        this.npcList.length = 0;
    };
    NPCManager.prototype.delete = function (item) {
        var index = this.npcList.indexOf(item);
        if (index >= 0) {
            this.buffer.push(item);
            this.npcList.splice(index, 1);
        }
    };
    NPCManager.prototype.getByIndex = function (index) {
        return this.npcList[index];
    };
    /**
     * 获取一个对象
     * @param func
     */
    NPCManager.prototype.get = function (func) {
        // console.log(' this.buffer.length ', this.buffer.length)
        var item = this.buffer.length > 0 ? this.buffer.shift() : func();
        return item;
    };
    /**
     * 获取所有对象
     */
    NPCManager.prototype.getList = function () {
        return this.npcList;
    };
    NPCManager.prototype.size = function () {
        return this.npcList.length;
    };
    Object.defineProperty(NPCManager.prototype, "length", {
        get: function () {
            return this.size();
        },
        enumerable: false,
        configurable: true
    });
    NPCManager.prototype.clear = function () {
        for (var index = 0; index < this.buffer.length; index++) {
            var element = this.buffer[index];
            element.destroy();
        }
        this.buffer.length = 0;
    };
    return NPCManager;
}());
exports.NPCManager = NPCManager;
var SimpleActionManager = /** @class */ (function (_super) {
    __extends(SimpleActionManager, _super);
    function SimpleActionManager() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SimpleActionManager.prototype.setTarget = function (t) {
        this.target = t;
    };
    //行为初始化
    SimpleActionManager.prototype.init = function (s, param) { };
    SimpleActionManager.prototype.getAction = function () {
        return this.getState();
    };
    /**
     * 每次动画结束时调用
     * @param s
     */
    SimpleActionManager.prototype.onActionFinish = function () {
    };
    SimpleActionManager.prototype.isActionFinish = function () {
        return false;
    };
    //行动结束，告知行动对象可以思考了。
    SimpleActionManager.prototype.complete = function () {
    };
    return SimpleActionManager;
}(GameState));
exports.SimpleActionManager = SimpleActionManager;

cc._RF.pop();