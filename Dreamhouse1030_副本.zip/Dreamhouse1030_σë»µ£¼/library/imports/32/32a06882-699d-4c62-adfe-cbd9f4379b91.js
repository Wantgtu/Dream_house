"use strict";
cc._RF.push(module, '32a06iCaZ1MYq3+y9n0N5uR', 'MusicManager');
// Script/engine/MusicManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var engine_1 = require("./engine");
var MusicManager = /** @class */ (function () {
    function MusicManager() {
    }
    MusicManager.prototype.getMaxNum = function () {
        return engine_1.engine.audioEngine.getMaxAudioInstance();
    };
    MusicManager.prototype.play = function (name, res, isLoop) {
        if (this.tempName == name) {
            return;
        }
        this.stop();
        this.tempName = name;
        var audioId = engine_1.engine.audioEngine.playMusic(res, isLoop);
        if (!isLoop) {
            engine_1.engine.audioEngine.setFinishCallback(audioId, this.stop.bind(this, name));
        }
    };
    MusicManager.prototype.pause = function () {
        engine_1.engine.audioEngine.pauseMusic();
    };
    MusicManager.prototype.resume = function () {
        engine_1.engine.audioEngine.resumeMusic();
    };
    MusicManager.prototype.stop = function () {
        if (!this.tempName) {
            return;
        }
        engine_1.engine.audioEngine.stopMusic();
        this.tempName = null;
    };
    MusicManager.prototype.setVolume = function (count) {
        engine_1.engine.audioEngine.setMusicVolume(count);
    };
    MusicManager.prototype.isPlaying = function () {
        return engine_1.engine.audioEngine.isMusicPlaying();
    };
    MusicManager.prototype.clear = function () {
        this.stop();
    };
    return MusicManager;
}());
exports.default = MusicManager;

cc._RF.pop();