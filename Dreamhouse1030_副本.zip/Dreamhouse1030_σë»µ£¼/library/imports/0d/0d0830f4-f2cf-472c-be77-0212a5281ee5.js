"use strict";
cc._RF.push(module, '0d083D08s9HLL53AhKlKB7l', 'MoveObject');
// Script/cfw/move/MoveObject.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

cc._RF.pop();