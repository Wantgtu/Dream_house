"use strict";
cc._RF.push(module, 'a3926KtOO9JPL6X4rPfwi5n', 'unity');
// Script/engine/unity.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Vector3 = exports.Vector2 = exports.ISize = exports.IRect = void 0;
var IRect = /** @class */ (function (_super) {
    __extends(IRect, _super);
    function IRect() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return IRect;
}(cc.Rect));
exports.IRect = IRect;
var ISize = /** @class */ (function (_super) {
    __extends(ISize, _super);
    function ISize() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ISize;
}(cc.Size));
exports.ISize = ISize;
var Vector2 = /** @class */ (function (_super) {
    __extends(Vector2, _super);
    function Vector2() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Vector2;
}(cc.Vec2));
exports.Vector2 = Vector2;
var Vector3 = /** @class */ (function (_super) {
    __extends(Vector3, _super);
    function Vector3() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Vector3;
}(cc.Vec3));
exports.Vector3 = Vector3;

cc._RF.pop();