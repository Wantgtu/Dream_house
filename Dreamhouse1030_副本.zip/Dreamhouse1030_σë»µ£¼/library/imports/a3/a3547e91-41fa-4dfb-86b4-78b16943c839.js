"use strict";
cc._RF.push(module, 'a35476RQfpN+4a0eLFpQ8g5', 'LuckySpinView');
// Script/logic/luckyspin/view/LuckySpinView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../cfw/view");
var LuckyspinMgr_1 = require("../model/LuckyspinMgr");
// import CMgr from "../../../sdk/channel-ts/CMgr";
// import OVNativeAdC from "../../../sdk/nativeAd/OVNativeAdC";
var engine_1 = require("../../../engine/engine");
var ItemView_1 = require("../../item/view/ItemView");
var UIText_1 = require("../../../cocos/lang/UIText");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LuckySpinView = /** @class */ (function (_super) {
    __extends(LuckySpinView, _super);
    // @property(cc.Node)
    // nativeAd: cc.Node = null;
    // @property(cc.Node)
    // jumpBtn: cc.Node = null;
    function LuckySpinView() {
        var _this = _super.call(this) || this;
        _this.backBtn = null;
        _this.content = null;
        _this.okBtn = null;
        _this.angle = null;
        _this.adImg = null;
        _this.itemPrefab = null;
        // 更多参数说明请访问: https://ldc2.layabox.com/doc/?nav=zh-as-2-4-0
        _this.itemPos = [];
        _this.tip = null;
        _this.state = 0;
        _this.pos = 0;
        return _this;
    }
    LuckySpinView.prototype.onEnable = function () {
    };
    LuckySpinView.prototype.onDisable = function () {
    };
    LuckySpinView.prototype.onEnter = function () {
        this.model.reset();
        var list = this.model.getLuckySpinItemModelList();
        for (var index = 0; index < list.length; index++) {
            var element = list[index];
            var item = element.getItem();
            var node_1 = engine_1.engine.instantiate(this.itemPrefab);
            // node.scaleX = 0.5;
            // node.scaleY = 0.5;
            node_1.anchorX = 0.5;
            node_1.anchorY = 0.5;
            this.itemPos[index].addChild(node_1);
            var comp = node_1.getComponent(ItemView_1.default);
            if (comp) {
                comp.setModel(item);
                comp.draw();
                comp.label.string = element.getWeight() + '%';
            }
        }
        this.updateButton();
        var node = engine_1.engine.instantiate(this.itemPrefab);
        this.node.addChild(node);
        this.rewardItem = node.getComponent(ItemView_1.default);
        node.active = false;
        // if (CMgr.helper.hasNativeLimit()) {
        //     let num = CMgr.helper.getzs_native_change_switch();
        //     console.log('updateState num', num)
        //     if (num == 0) {
        //         if (this.nativeAd)
        //             this.nativeAd.active = true;
        //     } else {
        //         OVNativeAdC.instance().intoLayer()
        //     }
        // }
    };
    LuckySpinView.prototype.addListener = function () {
        this.eventProxy.on(LuckyspinMgr_1.default.NOTIFY_RESULT, this.notifyResult, this);
    };
    LuckySpinView.prototype.notifyResult = function () {
        var _this = this;
        var result = this.model.getResult();
        if (result) {
            // this.isRolling = true;
            this.state = 1;
            var n = 6;
            this.content.angle = 0;
            cc.tween(this.content).to(3, { angle: 360 * n })
                .call(function () {
                _this.spinFinish(result);
            })
                .start();
            // , 3000, null, Laya.Handler.create(this, this.spinFinish, [result]))
        }
    };
    LuckySpinView.prototype.spinFinish = function (result) {
        var _this = this;
        var to = result.getIndex();
        var final = to + this.itemPos.length;
        var per = 360 / this.itemPos.length;
        cc.tween(this.content).to(1, { angle: this.content.angle + per * final })
            .call(function () {
            _this.spinOver(result);
        })
            .start();
        // , 1000, null, Laya.Handler.create(this, this.spinOver, [result]))
    };
    LuckySpinView.prototype.spinOver = function (result) {
        this.state = 0;
        this.controller.addItem(result);
        // BagManager.instance().updateItem(result.getItem(), EngineHelper.getMidPos())
        this.updateButton();
        // this.isRolling = false;
        this.showRewardItem(result.getItem());
    };
    LuckySpinView.prototype.showRewardItem = function (item) {
        var _this = this;
        this.rewardItem.setModel(item);
        this.rewardItem.draw();
        this.rewardItem.node.active = true;
        this.rewardItem.node.scale = 0;
        cc.tween(this.rewardItem.node).to(0.5, { scale: 2 })
            .delay(1)
            .to(0.2, { scale: 2.1 })
            .to(0.5, { scale: 0 })
            .call(function () {
            _this.rewardItem.node.active = false;
        })
            .start();
    };
    LuckySpinView.prototype.updateButton = function () {
        var flag = this.model.needAd();
        console.log("updateState flag ", flag);
        this.adImg.node.active = flag;
        var next = this.model.getNextModel();
        if (!next) {
            this.tip.node.active = false;
        }
        else {
            var item = next.getItem();
            var nextCount = next.getCount() - this.model.getCount();
            this.tip.node.active = true;
            this.tip.string = UIText_1.default.instance().getText(54, { num: nextCount, name: item.getName() });
        }
        // if (flag) {
        //     console.log('CMgr.helper.hasNativeLimit() ', CMgr.helper.hasNativeLimit())
        //     if (CMgr.helper.hasNativeLimit()) {
        //         let num = CMgr.helper.getzs_native_change_switch();
        //         console.log('updateState num', num)
        //         if (num == 0) {
        //             this.jumpBtn.active = true;
        //         } else {
        //             // OVNativeAdC.instance().intoLayer()
        //         }
        //     }
        // }
    };
    LuckySpinView.prototype.onBackBtnClick = function () {
        // if (this.state != 0) {
        //     return;
        // }
        this.hide();
    };
    LuckySpinView.prototype.onBtnClick = function () {
        if (this.state != 0) {
            return;
        }
        this.controller.onOkClick(this.model);
    };
    __decorate([
        property(cc.Button)
    ], LuckySpinView.prototype, "backBtn", void 0);
    __decorate([
        property(cc.Node)
    ], LuckySpinView.prototype, "content", void 0);
    __decorate([
        property(cc.Button)
    ], LuckySpinView.prototype, "okBtn", void 0);
    __decorate([
        property(cc.Sprite)
    ], LuckySpinView.prototype, "angle", void 0);
    __decorate([
        property(cc.Sprite)
    ], LuckySpinView.prototype, "adImg", void 0);
    __decorate([
        property(cc.Prefab)
    ], LuckySpinView.prototype, "itemPrefab", void 0);
    __decorate([
        property([cc.Node])
    ], LuckySpinView.prototype, "itemPos", void 0);
    __decorate([
        property(cc.Label)
    ], LuckySpinView.prototype, "tip", void 0);
    LuckySpinView = __decorate([
        ccclass
    ], LuckySpinView);
    return LuckySpinView;
}(view_1.BaseView));
exports.default = LuckySpinView;

cc._RF.pop();