"use strict";
cc._RF.push(module, 'a31e8/tWhtO4b4/UqgM/iYO', 'SoundC');
// Script/logic/sound/SoundC.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var mvc_1 = require("../../cfw/mvc");
var ViewManager_1 = require("../../cfw/tools/ViewManager");
var ModuleConfig_1 = require("../../config/ModuleConfig");
var UIConfig_1 = require("../../config/UIConfig");
var SoundMgr_1 = require("./model/SoundMgr");
var SoundC = /** @class */ (function (_super) {
    __extends(SoundC, _super);
    function SoundC() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SoundC.prototype.intoLayer = function () {
        // if (UIManager.instance().hasView('SettingView', UIIndex.STACK)) {
        //     return;
        // }
        ViewManager_1.default.pushUIView({
            path: 'prefabs/SettingView',
            moduleID: ModuleConfig_1.ModuleID.PUBLIC,
            uiIndex: UIConfig_1.UIIndex.STACK,
            model: SoundMgr_1.default.instance(),
            controller: this,
        });
    };
    return SoundC;
}(mvc_1.BaseController));
exports.default = SoundC;

cc._RF.pop();