"use strict";
cc._RF.push(module, '51bd9xSBbpCnrBuPkJAviIj', 'GameText');
// Script/config/GameText.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameText = void 0;
exports.GameText = {
    zh: {
        RES_LOAD_ERROR: '某些资源加载失败！是否重新加载？',
        BUY_GOLD: '是否观看广告获得%{num}金币？',
        ATTACK: '攻击',
        CD: 'CD',
        SPEED: '速度',
        UPGRADE: '升级',
        UN_LOCK: '解锁',
        CONFORM: '确定',
        START: '开始',
        CHANGE_WEAPON: '换武器',
        USE: "使用中",
        UN_USE: "未使用",
        UNLOCK: "未解锁",
        YOU: "你",
        NAMES: ["江元", "宋佳", "蔡建", "董建",
            "陈斌", "李林", "刘斌", "赵斌华",
            "陈伟强", "李芳", "刘桂林", "赵斌",
            "陈文武", "李赵连", "刘天齐", "赵括", "王顺"],
        FUHUO: "是否原地满血复活？",
        JIESUO: "是否观看视频解锁神龙?",
        BACK_LOBBY: "是否返回大厅?",
        LEVEL_TITLE: ['未解锁', '已完成', '已解锁'],
        BALK_LOBBY: "返回大厅",
        NEXT_BATTLE: "下一关",
        RESTART: "重新开始",
        YOU_WIN: "胜利",
        YOU_FAIL: "失败",
        WIN_TITLE: "任务结束",
        FAIL_TITLE: "任务失败",
        RESUME: '回到游戏',
        PAUSE_TITLE: '游戏暂停',
        GAME_PAUSE: '游戏暂停中',
        NOT_GOLD_ENOUGH: '没有足够的金钱!',
        BUY_ARROW: '观看视频广告，获得%{num}个弓箭',
        NOT_PASS: '未能踏入婚姻',
        PASS: '共同度过',
        MEDDY_TEST: ['未能牵手成功', '共同度过水晶婚', '共同度过珍珠婚', '共同度过珊瑚婚', '共同度过翡翠婚'],
        CLOTHE_NAME: ['装饰', '发型', '裤子', '上衣', '鞋子'],
        ATTR_NAME: ['财力', '气质', '体力', '智力'],
        RIGHT: '小哥哥非常满意你的回答',
        WRONG: '小哥哥不满意你的回答',
        NOT_HIT: '很遗憾，未中奖',
        LEVEL_AT: '达到%{num}级',
        REFRESH: '冷却中...'
    }
};

cc._RF.pop();