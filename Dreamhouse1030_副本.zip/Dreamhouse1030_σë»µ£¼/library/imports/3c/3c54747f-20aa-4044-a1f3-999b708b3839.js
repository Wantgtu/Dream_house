"use strict";
cc._RF.push(module, '3c547R/IKpARKHzmZtwizg5', 'MoveSystem');
// Script/cfw/move/MoveSystem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var event_1 = require("../event");
var Define_1 = require("../tools/Define");
var PhysicalManager_1 = require("./PhysicalManager");
var Utils_1 = require("../tools/Utils");
var MoveConfig_1 = require("./MoveConfig");
var MoveSystem = /** @class */ (function (_super) {
    __extends(MoveSystem, _super);
    function MoveSystem(obj) {
        var _this = _super.call(this) || this;
        _this.b = [];
        // protected collideFlag: boolean = false;
        //是否受重力影响
        _this.g = true;
        //是否可见
        _this.enable = true;
        //是否参与缩放
        _this.scale = true;
        //是否更新位置
        _this.updatePos = true;
        //速度
        // speed: Vector3 = new Vector3(0, 0, 0)
        _this.speedX = 0;
        _this.speedY = 0;
        _this.speedZ = 0;
        //角色在地图中的位置
        // position: Vector3 = new Vector3(0, 0, 0)
        _this.x = 0;
        _this.y = 0;
        _this.z = 0;
        //款到纵深
        _this.width = 0;
        _this.height = 0;
        _this.depth = 0;
        // 弹力
        _this.elasticity = 0;
        //摩擦力
        _this.frictional = 0;
        //跳跃高度
        _this.jumpHigh = 350;
        //左右移动方向
        _this.moveXDir = Define_1.DIR.RIGHT;
        //上下移动方向
        _this.moveZDir = Define_1.DIR.UP;
        // isMoveObject: boolean = false;
        _this.isPlane = false;
        _this.maxY = -1;
        _this.minY = -1;
        _this.onGroundFlag = true;
        _this._node = obj;
        return _this;
    }
    Object.defineProperty(MoveSystem.prototype, "node", {
        get: function () {
            return this._node;
        },
        enumerable: false,
        configurable: true
    });
    MoveSystem.prototype.getLeft = function () {
        return this.x - this.node.getAnchorX() * this.width;
    };
    MoveSystem.prototype.getRight = function () {
        return this.x + (1 - this.node.getAnchorX()) * this.width;
    };
    MoveSystem.prototype.getMidY = function () {
        return this.y + MoveConfig_1.SCREEN_Y * (this.node.getAnchorY() * this.height) / 2;
    };
    MoveSystem.prototype.getMidX = function () {
        return this.x + (1 - this.node.getAnchorX()) * this.width / 2;
    };
    MoveSystem.prototype.getTop = function () {
        return this.y + MoveConfig_1.SCREEN_Y * this.node.getAnchorY() * this.height;
    };
    MoveSystem.prototype.getBottom = function () {
        return this.y - MoveConfig_1.SCREEN_Y * (1 - this.node.getAnchorY()) * this.height;
    };
    MoveSystem.prototype.setCollide = function (c) {
        this.collide = c;
    };
    MoveSystem.prototype.getCollide = function () {
        return this.collide;
    };
    // setCollideFlag(f: boolean) {
    //     this.collideFlag = f;
    // }
    // isCollide() {
    //     return this.collideFlag;
    // }
    MoveSystem.prototype.onGround = function (func, target) {
        this.on('onGround', func, target);
    };
    MoveSystem.prototype.offGround = function (func, target) {
        this.off('onGround', func, target);
    };
    MoveSystem.prototype.emitGround = function () {
        this.emit('onGround', this.onGroundFlag);
    };
    MoveSystem.prototype.isScale = function () {
        return this.scale;
    };
    MoveSystem.prototype.isUpdatePos = function () {
        return this.updatePos;
    };
    MoveSystem.prototype.start = function () {
        if (this.enable) {
            this.setEnable(true);
        }
    };
    MoveSystem.prototype.onDestroy = function () {
        if (this.enable) {
            this.setEnable(false);
        }
    };
    MoveSystem.prototype.getDir = function (mv) {
        var dh = this.height / 3;
        var dw = this.width / 3;
        if (Math.abs(mv.getTop() - this.getBottom()) <= dh) {
            return Define_1.DIR.DOWN;
        }
        else if (Math.abs(mv.getLeft() - this.getRight()) <= dw) {
            return Define_1.DIR.RIGHT;
        }
        else if (Math.abs(mv.getRight() - this.getLeft()) <= dw) {
            return Define_1.DIR.LEFT;
        }
        else if (Math.abs(mv.getBottom() - this.getTop()) <= dh) {
            return Define_1.DIR.UP;
        }
        else {
            return Define_1.DIR.NONE;
        }
    };
    MoveSystem.prototype.setEnable = function (f) {
        this.enable = f;
        //console.log('MoveSystem setEnable f ', f)
        if (this.enable) {
            if (this.isPlane) {
                PhysicalManager_1.PhysicalManager.instance().addPlane(this);
            }
            else {
                PhysicalManager_1.PhysicalManager.instance().add(this);
            }
        }
        else {
            if (this.isPlane) {
                PhysicalManager_1.PhysicalManager.instance().removePlane(this);
            }
            else {
                PhysicalManager_1.PhysicalManager.instance().remove(this);
            }
        }
    };
    MoveSystem.prototype.isEnable = function () {
        return this.enable;
    };
    MoveSystem.prototype.setMoveXDir = function (d) {
        this.moveXDir = d;
    };
    MoveSystem.prototype.getMoveXDir = function () {
        return this.moveXDir;
    };
    MoveSystem.prototype.setMoveZDir = function (d) {
        this.moveZDir = d;
    };
    MoveSystem.prototype.getMoveZDir = function () {
        return this.moveZDir;
    };
    MoveSystem.prototype.getFrictional = function () {
        return this.frictional;
    };
    MoveSystem.prototype.setGrictional = function (n) {
        this.frictional = n;
    };
    MoveSystem.prototype.setElasticity = function (n) {
        this.elasticity = n;
    };
    MoveSystem.prototype.getElasticity = function () {
        return this.elasticity;
    };
    MoveSystem.prototype.isG = function () {
        return this.g;
    };
    MoveSystem.prototype.setG = function (f) {
        this.g = f;
    };
    MoveSystem.prototype.getJumpHigh = function () {
        return this.jumpHigh;
    };
    MoveSystem.prototype.setJumpHight = function (h) {
        this.jumpHigh = h;
    };
    MoveSystem.prototype.addJumpHigh = function (h) {
        this.jumpHigh += h;
    };
    MoveSystem.prototype.jump = function (h) {
        this.jumpHigh = h;
        var spy = Utils_1.default.getVy(MoveConfig_1.G, h);
        console.log(' jump spy ', spy);
        this.onGroundFlag = false;
        this.setSpeedY(spy);
    };
    // isJumping() {
    //     return this.position.y > 0
    // }
    MoveSystem.prototype.setX = function (x) {
        this.x = x;
    };
    MoveSystem.prototype.getMinY = function () {
        return this.minY;
    };
    MoveSystem.prototype.getMaxY = function () {
        return this.maxY;
    };
    MoveSystem.prototype.setY = function (y) {
        this.y = y;
        if (this.minY == -1) {
            this.minY = y;
        }
        else if (y < this.minY) {
            this.minY = y;
        }
        if (this.maxY == -1) {
            this.maxY = y;
        }
        else if (y > this.maxY) {
            this.maxY = y;
        }
    };
    MoveSystem.prototype.getZ = function () {
        return this.z;
    };
    MoveSystem.prototype.setZ = function (z) {
        this.z = z;
    };
    MoveSystem.prototype.updateZIndex = function () {
        this.node.setZIndex(-this.getZ());
    };
    MoveSystem.prototype.getX = function () {
        return this.x;
    };
    MoveSystem.prototype.getY = function () {
        return this.y;
    };
    MoveSystem.prototype.getSpeedX = function () {
        return this.speedX;
    };
    MoveSystem.prototype.setSpeedX = function (s) {
        this.speedX = s;
    };
    MoveSystem.prototype.setSpeedY = function (spy) {
        this.speedY = spy;
    };
    MoveSystem.prototype.getSpeedY = function () {
        return this.speedY;
    };
    MoveSystem.prototype.setSpeedZ = function (z) {
        this.speedZ = z;
    };
    MoveSystem.prototype.getSpeedZ = function () {
        return this.speedZ;
    };
    MoveSystem.prototype.isOnGround = function () {
        return this.onGroundFlag;
    };
    MoveSystem.prototype.setOnGroundFlag = function (f) {
        this.onGroundFlag = f;
        this.emitGround();
    };
    MoveSystem.prototype.setSpeed = function (x, y, z) {
        // console.log(' setSpeed ', x, y, z)
        this.setSpeedX(x);
        this.setSpeedY(y);
        this.setSpeedZ(z);
    };
    MoveSystem.prototype.setPosition = function (x, y, z) {
        // console.log(' setPosition ', x, y, z)
        this.setX(x);
        this.setZ(z);
        var sy = y - z;
        if (sy < 0) {
            sy = 0;
        }
        this.setY(sy);
    };
    MoveSystem.prototype.getWidth = function () {
        return this.width;
    };
    MoveSystem.prototype.getHeight = function () {
        return this.height;
    };
    MoveSystem.prototype.getDepth = function () {
        return this.depth;
    };
    MoveSystem.prototype.setWidth = function (w) {
        this.width = w;
    };
    MoveSystem.prototype.setHeight = function (h) {
        this.height = h;
    };
    return MoveSystem;
}(event_1.EventDispatcher));
exports.default = MoveSystem;

cc._RF.pop();