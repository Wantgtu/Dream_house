"use strict";
cc._RF.push(module, '6706dpXVgxLkYNor/uO96tH', 'BaseRewardAd');
// Script/sdk/sdk/base/BaseRewardAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseAd_1 = require("./BaseAd");
var SDKConfig_1 = require("../SDKConfig");
var SDKEvent_1 = require("../tools/SDKEvent");
var SDKEventID_1 = require("../third/SDKEventID");
var BaseRewardAd = /** @class */ (function (_super) {
    __extends(BaseRewardAd, _super);
    function BaseRewardAd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BaseRewardAd.prototype.open = function (callback) {
        console.log(' BaseRewardAd open state ', this.state);
        if (callback) {
            this.callback = callback;
        }
        if (this.state == SDKConfig_1.SDKState.loadSucess) {
            this.show();
        }
        else {
            this.reload(SDKConfig_1.SDKState.open);
        }
    };
    BaseRewardAd.prototype.reload = function (s) {
        this.logicState = s;
        this.setState(SDKConfig_1.SDKState.loading);
        this.destroy();
        this.create();
    };
    BaseRewardAd.prototype.load = function () {
        if (this.rewardAd) {
            this.rewardAd.load();
        }
    };
    BaseRewardAd.prototype.onError = function (err) {
        console.log('NativeTest 视频加载失败 ', err);
        this.setState(SDKConfig_1.SDKState.loadFail);
        if (this.callback) {
            this.callback(SDKConfig_1.ResultState.NO);
            this.callback = null;
        }
        this.channel.showToast('视频加载失败');
        if (err && err.errCode)
            this.channel.trackEvent(SDKEventID_1.default.vedio_ad_error, { code: err.errCode });
    };
    BaseRewardAd.prototype.show = function () {
        var _this = this;
        this.setState(SDKConfig_1.SDKState.open);
        this.logicState = SDKConfig_1.SDKState.close;
        if (this.rewardAd) {
            // console.log(' 展示激励视频 ')
            this.rewardAd.show().then(function () {
                _this.setState(SDKConfig_1.SDKState.open);
                // console.log(' 激励视频展示成功 ')
                _this.pause();
            }).catch(function () {
                // 失败重试
                // console.log(' show  激励视频 播放失败重试')
                _this.rewardAd.load()
                    .then(function () {
                    _this.rewardAd.show();
                    _this.setState(SDKConfig_1.SDKState.open);
                    _this.pause();
                })
                    .catch(function (err) {
                    // console.log(' 激励视频重试失败 err ', err)
                    _this.setState(SDKConfig_1.SDKState.loadFail);
                    _this.channel.showToast('视频加载失败');
                    if (err && err.errCode)
                        _this.channel.trackEvent(SDKEventID_1.default.vedio_ad_error, { code: err.errCode });
                    // callback(false)
                    // this.channel.showShare(0, this.callback)
                });
            });
        }
    };
    BaseRewardAd.prototype.onLoad = function () {
        console.log('NativeTest 视频加载成功 ');
        this.setState(SDKConfig_1.SDKState.loadSucess);
        if (this.logicState == SDKConfig_1.SDKState.open) {
            this.show();
        }
        // sel
    };
    BaseRewardAd.prototype.destroy = function () {
        if (this.rewardAd) {
            this.rewardAd.destroy();
            this.rewardAd = null;
        }
    };
    BaseRewardAd.prototype.onClose = function (res) {
        console.log('NativeTest onClose ', res);
        this.setState(SDKConfig_1.SDKState.close);
        if (res && res.isEnded || res === undefined) {
            // console.log('视频结束关闭 ')
            // 正常播放结束，可以下发游戏奖励
            if (this.callback) {
                this.callback(SDKConfig_1.ResultState.YES);
                this.callback = null;
            }
        }
        else {
            // 播放中途退出，不下发游戏奖励
            // console.log('视频中途关闭 ')
            if (this.callback) {
                this.callback(SDKConfig_1.ResultState.NO);
                this.callback = null;
                // ToastController.instance().intoLayer('ui.not_finish');
            }
        }
        this.resume();
    };
    BaseRewardAd.prototype.pause = function () {
        // console.warn(' BaseReward Ad  pause')
        SDKEvent_1.default.instance().emit(SDKEvent_1.default.REWARD_AD_OPEN);
    };
    BaseRewardAd.prototype.resume = function () {
        // console.warn(' BaseReward Ad  resume')
        SDKEvent_1.default.instance().emit(SDKEvent_1.default.REWARD_AD_CLOSE);
    };
    return BaseRewardAd;
}(BaseAd_1.default));
exports.default = BaseRewardAd;

cc._RF.pop();