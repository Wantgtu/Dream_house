"use strict";
cc._RF.push(module, '045eeLBsw9O66MbPVHc2WMX', 'RecorderComp');
// Script/sdk/recorder/RecorderComp.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var SDKManager_1 = require("../../sdk/sdk/SDKManager");
var SDKConfig_1 = require("../../sdk/sdk/SDKConfig");
var RecorderC_1 = require("./RecorderC");
var RedTipMgr_1 = require("../../extention/redtip/RedTipMgr");
var Config_1 = require("../../config/Config");
/**
 * 1. 手动开启
 * 2. 手动分享
 * 3. 自动停止后手动分享
 */
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var RecorderComp = /** @class */ (function (_super) {
    __extends(RecorderComp, _super);
    function RecorderComp() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.recordStart = null;
        _this.recordEnd = null;
        _this.recordIcon = null;
        _this.desc = null;
        return _this;
    }
    RecorderComp.prototype.start = function () {
        this.node.active = SDKManager_1.default.getChannel().hasRecorder();
        if (this.node.active) {
            this.node.on(cc.Node.EventType.TOUCH_END, this.onButtonClick, this);
            var recorder = SDKManager_1.default.getChannel().getRecorder();
            this.func = this.changeState.bind(this);
            recorder.on(this.func);
            this.startRecorder();
            // this.setState(recorder.getState())
            // this.onButtonClick()
        }
    };
    RecorderComp.prototype.startRecorder = function () {
        var recorder = SDKManager_1.default.getChannel().getRecorder();
        recorder.start();
    };
    RecorderComp.prototype.onDestroy = function () {
        var recorder = SDKManager_1.default.getChannel().getRecorder();
        if (recorder) {
            recorder.off(this.func);
        }
    };
    RecorderComp.prototype.changeState = function (s) {
        console.log('changeState s ', s);
        this.setState(s);
    };
    RecorderComp.prototype.setState = function (s) {
        // this.state = s;
        switch (s) {
            case SDKConfig_1.SDKState.stop:
                if (this.recordIcon) {
                    this.recordIcon.spriteFrame = this.recordEnd;
                }
                this.desc.string = '录制完成';
                RedTipMgr_1.default.instance().addRedTip(Config_1.RedTipType.HAS_RECORDER);
                this.onButtonClick();
                break;
            case SDKConfig_1.SDKState.start:
                this.desc.string = '录制中...';
                RedTipMgr_1.default.instance().removeRedTip(Config_1.RedTipType.HAS_RECORDER);
                if (this.recordIcon) {
                    this.recordIcon.spriteFrame = this.recordStart;
                }
                break;
        }
    };
    RecorderComp.prototype.update = function (dt) {
    };
    RecorderComp.prototype.onButtonClick = function () {
        // let recorder = SDKManager.getChannel().getRecorder()
        // recorder.start();
        RecorderC_1.default.instance().intoLayer();
    };
    __decorate([
        property(cc.SpriteFrame)
    ], RecorderComp.prototype, "recordStart", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], RecorderComp.prototype, "recordEnd", void 0);
    __decorate([
        property(cc.Sprite)
    ], RecorderComp.prototype, "recordIcon", void 0);
    __decorate([
        property(cc.Label)
    ], RecorderComp.prototype, "desc", void 0);
    RecorderComp = __decorate([
        ccclass
    ], RecorderComp);
    return RecorderComp;
}(cc.Component));
exports.default = RecorderComp;

cc._RF.pop();