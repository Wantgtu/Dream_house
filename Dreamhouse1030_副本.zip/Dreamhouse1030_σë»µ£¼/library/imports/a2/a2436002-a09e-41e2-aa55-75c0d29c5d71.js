"use strict";
cc._RF.push(module, 'a2436ACoJ5B4qpVdcDSnF1x', 'QQAppBoxAd');
// Script/sdk/sdk/qq/QQAppBoxAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseAd_1 = require("../base/BaseAd");
var SDKConfig_1 = require("../SDKConfig");
var QQAppBoxAd = /** @class */ (function (_super) {
    __extends(QQAppBoxAd, _super);
    function QQAppBoxAd(c, id) {
        var _this = _super.call(this, c, id) || this;
        _this.preload(SDKConfig_1.SDKState.close);
        return _this;
    }
    QQAppBoxAd.prototype.preload = function (s) {
        this.logicState = s;
        console.log('QQAppBoxAd preload ====================');
        this.destroy();
        this.create();
        this.load();
    };
    QQAppBoxAd.prototype.open = function (call) {
        this.callback = call;
        console.log('QQAppBoxAd open ');
        // this.destroy()
        if (this.state == SDKConfig_1.SDKState.loadSucess) {
            this.show();
        }
        else {
            this.logicState = SDKConfig_1.SDKState.open;
            this.load();
        }
    };
    QQAppBoxAd.prototype.onClose = function () {
        console.log(' AppBox onClose ');
        this.setState(SDKConfig_1.SDKState.close);
        if (this.callback) {
            this.callback();
        }
        this.load();
    };
    QQAppBoxAd.prototype.create = function () {
        if (!this.appBoxAd) {
            this.appBoxAd = this.sdk.createAppBox({ adUnitId: this.adUnitID });
            this.appBoxAd.onClose(this.getFunc(SDKConfig_1.FunctionType.onClose));
        }
    };
    QQAppBoxAd.prototype.load = function () {
        var _this = this;
        console.log("QQAppBoxAd  load 1111");
        if (this.appBoxAd) {
            console.log("QQAppBoxAd  load ");
            this.appBoxAd.load().then(function () {
                console.log("QQAppBoxAd  load 2222 ");
                _this.setState(SDKConfig_1.SDKState.loadSucess);
                // this.show()
            }).catch(function (err) {
                console.log("QQAppBoxAd  load err", err);
            });
        }
        else {
            console.log(' instance is null ');
        }
    };
    QQAppBoxAd.prototype.show = function () {
        var _this = this;
        console.log("QQAppBoxAd  show 1111");
        if (this.appBoxAd) {
            this.appBoxAd.show().then(function () {
                console.log("QQAppBoxAd  show ");
                // this.load()
            }).catch(function (err) {
                console.log("QQAppBoxAd  show ", err);
                _this.load();
            });
        }
    };
    QQAppBoxAd.prototype.destroy = function () {
        if (this.appBoxAd) {
            this.appBoxAd.destroy();
            this.appBoxAd = null;
        }
    };
    return QQAppBoxAd;
}(BaseAd_1.default));
exports.default = QQAppBoxAd;

cc._RF.pop();