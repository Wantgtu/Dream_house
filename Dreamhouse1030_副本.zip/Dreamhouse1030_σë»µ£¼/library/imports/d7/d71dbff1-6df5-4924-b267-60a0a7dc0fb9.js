"use strict";
cc._RF.push(module, 'd71db/xbfVJJLJnYKCn3A+5', 'UmengEventID');
// Script/config/UmengEventID.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UmengEventID = /** @class */ (function () {
    function UmengEventID() {
    }
    UmengEventID.offline_reward = 'offline_reward';
    UmengEventID.online_reward = 'online_reward';
    UmengEventID.online_reach_time = 'online_reach_time';
    UmengEventID.storage_level = 'storage_level';
    UmengEventID.buy_energy_use_share = 'buy_energy_use_share';
    UmengEventID.daily_task = 'daily_task';
    UmengEventID.buy_token_at_out = 'buy_token_at_out';
    UmengEventID.buy_energy_use_token = 'buy_energy_use_token';
    UmengEventID.buy_energy = 'buy_energy';
    UmengEventID.build_open = 'build_open';
    UmengEventID.market_reawrd = 'market_reawrd';
    UmengEventID.buy_item = 'buy_item';
    UmengEventID.weekly_reward = 'weekly_reward';
    UmengEventID.task = 'task';
    UmengEventID.level = 'level';
    UmengEventID.market_reawrd_by_share = 'market_reawrd_by_share';
    UmengEventID.click_gift = 'click_gift';
    UmengEventID.click_gift_2 = 'click_gift_2';
    UmengEventID.boxpop_ad_count = 'boxpop_ad_count';
    UmengEventID.boxpop_count = 'boxpop_count';
    UmengEventID.luckyspin_ad_count = 'luckyspin_ad_count';
    UmengEventID.luckyspin_count = 'luckyspin_count';
    UmengEventID.specialtask_level = 'specialtask_level';
    UmengEventID.enter_lobby = 'enter_lobby';
    UmengEventID.enter_game = 'enter_game';
    UmengEventID.first_game = 'first_game';
    return UmengEventID;
}());
exports.default = UmengEventID;

cc._RF.pop();