"use strict";
cc._RF.push(module, 'd7b683GXAdCWozI3JDZ3L3a', 'attribute');
// Script/cfw/attribute.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttrManager = exports.AttrInfo = exports.PropertyAddedValue = exports.AttrType = exports.ValueType = exports.PropertyAddType = void 0;
var PropertyAddType = /** @class */ (function () {
    function PropertyAddType() {
    }
    PropertyAddType.ADDTYPE_VALUE = 0; // 数值类型
    PropertyAddType.ADDTYPE_RATE = 1; // 乘积系数类型	
    PropertyAddType.ADDTYPE_MULTIPLY = 2; //所有数值相乘
    return PropertyAddType;
}());
exports.PropertyAddType = PropertyAddType;
var ValueType = /** @class */ (function () {
    function ValueType() {
    }
    ValueType.MIN = 0;
    ValueType.MAX = 1;
    return ValueType;
}());
exports.ValueType = ValueType;
var AttrType;
(function (AttrType) {
    AttrType[AttrType["HP"] = 0] = "HP";
    AttrType[AttrType["POWER"] = 1] = "POWER";
    AttrType[AttrType["HEAL_POINT"] = 2] = "HEAL_POINT";
    AttrType[AttrType["ATK_CD"] = 3] = "ATK_CD";
    AttrType[AttrType["JUMP_POWER"] = 4] = "JUMP_POWER";
    AttrType[AttrType["SKILL"] = 5] = "SKILL";
    AttrType[AttrType["MOVE_SPEED"] = 6] = "MOVE_SPEED";
    AttrType[AttrType["RUN_SPEED"] = 7] = "RUN_SPEED";
    AttrType[AttrType["EXTRA"] = 8] = "EXTRA";
    AttrType[AttrType["MAX"] = 9] = "MAX";
})(AttrType = exports.AttrType || (exports.AttrType = {}));
var VALUE_TYPE_LIST = [
    ValueType.MAX,
    ValueType.MIN,
    ValueType.MIN,
    ValueType.MIN,
    ValueType.MIN,
    ValueType.MIN,
    ValueType.MIN,
    ValueType.MIN,
    ValueType.MIN,
];
var PropertyAddedValue = /** @class */ (function () {
    function PropertyAddedValue(valueType) {
        // 属性值
        this.finalValue = 0;
        this.addType = valueType;
        if (this.addType == PropertyAddType.ADDTYPE_MULTIPLY) {
            this.finalValue = 1;
        }
        else {
            this.finalValue = 0;
        }
    }
    PropertyAddedValue.prototype.AddType = function () {
        return this.addType;
    };
    PropertyAddedValue.prototype.add = function (addedValue) {
        if (this.addType == PropertyAddType.ADDTYPE_MULTIPLY) {
            this.finalValue *= addedValue;
        }
        else {
            this.finalValue += addedValue;
        }
    };
    PropertyAddedValue.prototype.remove = function (removeValue) {
        // this.finalValue -= removeValue;
        if (this.addType == PropertyAddType.ADDTYPE_MULTIPLY) {
            this.finalValue /= removeValue;
        }
        else {
            this.finalValue -= removeValue;
        }
    };
    PropertyAddedValue.prototype.getValue = function () {
        return this.finalValue;
    };
    return PropertyAddedValue;
}());
exports.PropertyAddedValue = PropertyAddedValue;
var AttrInfo = /** @class */ (function () {
    function AttrInfo(type) {
        this.level = 0;
        //最总值
        this.propFinalValue = 0;
        //基础值
        this.propBaseValue = 0;
        // 最大值
        this.maxValue = 0;
        //相加的数值
        this.addedValue = new PropertyAddedValue(PropertyAddType.ADDTYPE_VALUE);
        this.addedRate = new PropertyAddedValue(PropertyAddType.ADDTYPE_RATE);
        this.addedMultiply = new PropertyAddedValue(PropertyAddType.ADDTYPE_MULTIPLY);
        this.type = type;
    }
    AttrInfo.prototype.setLevel = function (lv) {
        this.level = lv;
    };
    AttrInfo.prototype.getLevel = function () {
        return this.level;
    };
    AttrInfo.prototype.getPropValue = function () {
        return this.propFinalValue;
    };
    /**
     * 设置某个基础属性值
     * @param type
     * @param value
     * @param update 是否更新最终值
     */
    AttrInfo.prototype.setBasePropValue = function (value) {
        this.propBaseValue = value;
        this.maxValue = value;
        this.propFinalValue = this.propBaseValue;
    };
    AttrInfo.prototype.getMaxValue = function () {
        return this.maxValue;
    };
    AttrInfo.prototype.getRatioValue = function () {
        var cur = this.propFinalValue;
        var total = this.maxValue;
        var value = 1;
        if (total > 0) {
            value = cur / total;
        }
        return value * 100;
    };
    AttrInfo.prototype.changePropValue = function (propType, value) {
        if (propType == PropertyAddType.ADDTYPE_VALUE) {
            this.propBaseValue += value;
        }
        else if (propType == PropertyAddType.ADDTYPE_RATE) {
            this.propBaseValue += Math.ceil(this.maxValue * value);
        }
        else {
            this.propBaseValue *= this.maxValue * value;
        }
        // this.totalValueList[type] = this.propBaseValueList[type]
        if (this.type == ValueType.MAX) {
            if (this.propBaseValue > this.maxValue) {
                this.propBaseValue = this.maxValue;
            }
        }
        else {
            if (this.propBaseValue > this.maxValue) {
                this.maxValue = this.propBaseValue;
            }
        }
        // if (update) {
        this.updateFinalValue();
        // }
    };
    /**
     * 更新某个属性的最终值
     * @param type 属性类型
     */
    AttrInfo.prototype.updateFinalValue = function () {
        this.propFinalValue = this.propBaseValue;
        this.propFinalValue += this.addedValue.getValue();
        var addNum = this.propFinalValue * this.addedRate.getValue();
        this.propFinalValue += addNum;
        this.propFinalValue *= this.addedMultiply.getValue();
        if (this.propFinalValue < 0) {
            this.propFinalValue = 0;
        }
        // logInfo(' updateFinalValue ', this.propFinalValue)
    };
    AttrInfo.prototype.getPropertyAddedValue = function (addType) {
        var propertyAddedValue = null;
        if (addType == PropertyAddType.ADDTYPE_VALUE) {
            propertyAddedValue = this.addedValue;
        }
        else if (addType == PropertyAddType.ADDTYPE_RATE) {
            propertyAddedValue = this.addedRate;
        }
        else {
            propertyAddedValue = this.addedMultiply;
        }
        return propertyAddedValue;
    };
    /**
     * 为某个属性添加数值
     * @param type 属性类型
     * @param addType 是增减 还是倍率
     * @param value 负号为减
     */
    AttrInfo.prototype.addValue = function (addType, value) {
        // console.log("addValue  AddValue type is " + type + " addType " + addType + " value " + value);
        var propertyAddedValue = this.getPropertyAddedValue(addType);
        propertyAddedValue.add(value);
        this.updateFinalValue();
    };
    /**
     * 移除效果的附加值
     * @param type
     * @param addType
     * @param value
     */
    AttrInfo.prototype.removeValue = function (addType, value) {
        // console.log("removeValue  AddValue type is " + type + " addType " + addType + " value " + value);
        var propertyAddedValue = this.getPropertyAddedValue(addType);
        propertyAddedValue.remove(value);
        this.updateFinalValue();
    };
    return AttrInfo;
}());
exports.AttrInfo = AttrInfo;
var AttrManager = /** @class */ (function () {
    function AttrManager() {
        this.attrMap = [];
        this.initialize();
    }
    AttrManager.prototype.getAttribute = function (type) {
        return this.attrMap[type];
    };
    AttrManager.prototype.setLevel = function (type, lv) {
        if (this.attrMap[type]) {
            this.attrMap[type].setLevel(lv);
        }
    };
    AttrManager.prototype.getLevel = function (type) {
        return this.attrMap[type].getLevel();
    };
    AttrManager.prototype.getMaxValue = function (t) {
        return this.attrMap[t].getMaxValue();
    };
    AttrManager.prototype.getRatioValue = function (type) {
        if (this.attrMap[type]) {
            return this.attrMap[type].getRatioValue();
        }
        return 0;
    };
    /**
     * 直接添加到基础属性中，比如一些一次性的效果 如加血道具。
     * 这些添加的数值是不会消失的。
     * @param type
     * @param value
     * @param update 是否更新最终值
     */
    AttrManager.prototype.changePropValue = function (type, propType, value) {
        if (this.attrMap[type]) {
            this.attrMap[type].changePropValue(propType, value);
        }
    };
    /**
     * 设置某个基础属性值
     * @param type
     * @param value
     * @param update 是否更新最终值
     */
    AttrManager.prototype.setBasePropValue = function (type, value) {
        if (this.attrMap[type]) {
            this.attrMap[type].setBasePropValue(value);
        }
    };
    //初始化
    AttrManager.prototype.initialize = function () {
        for (var i = 0; i < AttrType.MAX; i++) {
            this.attrMap[i] = new AttrInfo(VALUE_TYPE_LIST[i]);
        }
    };
    /**
     * 得到内部最终的属性值
     */
    AttrManager.prototype.getPropValue = function (propType) {
        if (this.attrMap[propType])
            return this.attrMap[propType].getPropValue();
        else {
            return 0;
        }
    };
    /**
     * 添加buff
     * @param type
     * @param addType
     * @param value
     */
    AttrManager.prototype.addValue = function (type, addType, value) {
        if (this.attrMap[type]) {
            this.attrMap[type].addValue(addType, value);
        }
    };
    /**
     * 移除buff
     * @param type
     * @param addType
     * @param value
     */
    AttrManager.prototype.removeValue = function (type, addType, value) {
        if (this.attrMap[type]) {
            this.attrMap[type].removeValue(addType, value);
        }
    };
    return AttrManager;
}());
exports.AttrManager = AttrManager;

cc._RF.pop();