"use strict";
cc._RF.push(module, 'd7f6b8/ZV9NyZcH408Likke', 'MiMoSelfRenderAd');
// Script/sdk/sdk/mimo/MiMoSelfRenderAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseAd_1 = require("../base/BaseAd");
var SDKConfig_1 = require("../SDKConfig");
var MiMoSelfRenderAd = /** @class */ (function (_super) {
    __extends(MiMoSelfRenderAd, _super);
    function MiMoSelfRenderAd() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.click_switch = 0;
        _this.close_num = 0;
        return _this;
    }
    MiMoSelfRenderAd.prototype.open = function (param) {
        this.callback = param.callback;
        this.click_switch = param.click_switch;
        this.close_num = param.close_num;
        this.destroy();
        this.create();
        this.load();
    };
    MiMoSelfRenderAd.prototype.create = function () {
        if (!this.instance) {
            this.instance = this.sdk.createSelfRenderAd({
                adUnitId: this.adUnitID,
                click_switch: this.click_switch,
                close_num: this.close_num
            });
            this.instance.onLoad(this.getFunc(SDKConfig_1.FunctionType.onLoad));
            this.instance.onError(this.getFunc(SDKConfig_1.FunctionType.onError));
        }
    };
    MiMoSelfRenderAd.prototype.load = function (ls) {
        if (ls === void 0) { ls = SDKConfig_1.SDKState.open; }
        this.logicState = ls;
        if (this.instance) {
            this.instance.load();
        }
    };
    MiMoSelfRenderAd.prototype.onLoad = function () {
        if (this.logicState == SDKConfig_1.SDKState.open) {
            this.instance.show();
        }
        if (this.callback) {
            this.callback(SDKConfig_1.ResultState.YES);
            this.callback = null;
        }
    };
    MiMoSelfRenderAd.prototype.onError = function () {
        if (this.callback) {
            this.callback(SDKConfig_1.ResultState.NO);
            this.callback = null;
        }
    };
    MiMoSelfRenderAd.prototype.destroy = function () {
        if (this.instance) {
            this.instance.destroy();
            this.instance = null;
        }
    };
    return MiMoSelfRenderAd;
}(BaseAd_1.default));
exports.default = MiMoSelfRenderAd;

cc._RF.pop();