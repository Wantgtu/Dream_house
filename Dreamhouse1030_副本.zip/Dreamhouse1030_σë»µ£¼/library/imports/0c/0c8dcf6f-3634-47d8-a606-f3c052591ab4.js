"use strict";
cc._RF.push(module, '0c8dc9vNjRH2KYG88BSWRq0', 'OppoChannel');
// Script/sdk/sdk/oppo/OppoChannel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseChannel_1 = require("../base/BaseChannel");
var SDKConfig_1 = require("../SDKConfig");
var OppoRewardAd_1 = require("./OppoRewardAd");
var OppoBannerAd_1 = require("./OppoBannerAd");
var OppoNativeAd_1 = require("./OppoNativeAd");
var OppoScreenshot_1 = require("./OppoScreenshot");
var OppoFileSystem_1 = require("./OppoFileSystem");
var BaseSubPackage_1 = require("../base/BaseSubPackage");
var GamePortalAd_1 = require("./GamePortalAd");
var SDKHelper_1 = require("../SDKHelper");
var OppoChannel = /** @class */ (function (_super) {
    __extends(OppoChannel, _super);
    function OppoChannel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    OppoChannel.prototype.hasAd = function (name) {
        var cfg = this.cfg;
        var version = this.sdk.getSystemInfoSync().platformVersionCode;
        //console.log('VivoChannel hasAd version ', version)
        var bannerCfg = cfg[name];
        if (!bannerCfg) {
            return -1;
        }
        var bVersion = bannerCfg[SDKConfig_1.ADName.version];
        if (!bVersion) {
            return 0;
        }
        return version >= bVersion;
    };
    OppoChannel.prototype.init = function () {
        var cfg = this.cfg;
        console.log('OppoChannel  constructor ');
        this.sdk.onShow(function () {
            console.log('OppoChannel  onShow ');
        });
        this.sdk.onHide(function () {
            console.log('OppoChannel  onHide ');
        });
        // this.bannerAd = new WXBanner()
        if (this.hasAd(SDKConfig_1.ADName.reward)) {
            var adCfg = cfg[SDKConfig_1.ADName.reward];
            var list = adCfg[SDKConfig_1.ADName.adUnitIdList];
            if (list) {
                for (var index = 0; index < list.length; index++) {
                    var adId = list[index];
                    this.rewardAd.push(new OppoRewardAd_1.default(this, adId));
                }
            }
        }
        // console.log(' this.sdk.createBannerAd ', this.sdk.createBannerAd)
        if (this.hasAd(SDKConfig_1.ADName.banner)) {
            var adCfg = cfg[SDKConfig_1.ADName.banner];
            var list = adCfg[SDKConfig_1.ADName.adUnitIdList];
            if (list) {
                for (var index = 0; index < list.length; index++) {
                    var adId = list[index];
                    this.bannerAd.push(new OppoBannerAd_1.default(this, adId));
                }
            }
        }
        else {
            console.warn(' 没有banner广告');
        }
        // if (this.hasAd(ADName.insert)) {
        //     let adCfg = cfg[ADName.insert]
        //     let list = adCfg[ADName.adUnitIdList]
        //     if (list) {
        //         for (let index = 0; index < list.length; index++) {
        //             const adId = list[index];
        //             this.insertAd.push(new OppoInsertAd(this, adId))
        //         }
        //     }
        // }
        if (this.hasAd(SDKConfig_1.ADName.native)) {
            var adCfg = cfg[SDKConfig_1.ADName.native];
            var list = adCfg[SDKConfig_1.ADName.adUnitIdList];
            if (list) {
                this.nativeAd = new OppoNativeAd_1.default(this, list);
            }
        }
        // console.log(' this.sdk.GamePortalAd ', this.sdk.createGamePortalAd)
        if (this.hasAd(SDKConfig_1.ADName.portal)) {
            var adCfg = cfg[SDKConfig_1.ADName.portal];
            var list = adCfg[SDKConfig_1.ADName.adUnitIdList];
            if (list) {
                for (var index = 0; index < list.length; index++) {
                    var adId = list[index];
                    this.appBoxAd.push(new GamePortalAd_1.default(this, adId));
                }
            }
        }
        console.log('OppoChannel  constructor  222222');
        this.subPackage = new BaseSubPackage_1.default(this);
        this.screenshot = new OppoScreenshot_1.default(this);
        this.fileSystem = new OppoFileSystem_1.default(this);
    };
    OppoChannel.prototype.hasMoreGame = function () {
        return this.hasAppBox();
    };
    OppoChannel.prototype.showToast = function (title) {
        this.sdk.showToast({ title: title });
    };
    OppoChannel.prototype.vibrateShort = function () {
        this.sdk.vibrateShort({
            success: function (res) { },
            fail: function (res) { },
            complete: function (res) { }
        });
    };
    OppoChannel.prototype.canInstallShortcut = function (func) {
        this.sdk.hasShortcutInstalled({
            success: function (res) {
                // 判断图标未存在时，创建图标
                console.log('canInstallShortcut res  ', res);
                if (res == false) {
                    func(SDKConfig_1.ResultState.YES);
                }
                else {
                    func(SDKConfig_1.ResultState.NO);
                }
            },
            fail: function (err) {
                func(SDKConfig_1.ResultState.NO);
            },
            complete: function () {
                // func(false)
            }
        });
    };
    OppoChannel.prototype.installShortcut = function (result) {
        this.sdk.installShortcut({
            success: function (param) {
                // 执行用户创建图标奖励
                console.log(' 安装成功 ', param);
                result(SDKConfig_1.ResultState.YES);
            },
            fail: function (err) {
                console.log(' 安装失败 ', err);
                result(SDKConfig_1.ResultState.NO);
            },
            complete: function () {
                // result(false)
            }
        });
    };
    OppoChannel.prototype.setLoadingProgress = function (progress) {
        this.sdk.setLoadingProgress({
            progress: progress
        });
    };
    OppoChannel.prototype.loadingComplete = function () {
        this.sdk.loadingComplete({
            complete: function (res) { }
        });
    };
    OppoChannel.prototype.navigateToMiniGame = function (appID) {
        this.sdk.navigateToMiniGame({
            pkgName: appID,
            success: function () { },
            fail: function (res) {
                // console.log(JSON.stringify(res))
            }
        });
    };
    OppoChannel.prototype.previewImage = function (_tempFilePath) {
        this.sdk.previewImage({
            urls: [_tempFilePath],
            success: function (res) {
                console.log('Preview image success.');
                // self.label = '';
            }
        });
    };
    OppoChannel.prototype.exitApplication = function () {
        this.sdk.exitApplication({
            success: function () {
                console.log('退出成功');
            },
            fail: function () {
                console.log('退出失败');
            }
        });
    };
    OppoChannel.prototype.request = function (url, func) {
        SDKHelper_1.default.sendHttpRequest(url, '', function (msg, data) {
            func(msg, data);
        });
    };
    return OppoChannel;
}(BaseChannel_1.default));
exports.default = OppoChannel;

cc._RF.pop();