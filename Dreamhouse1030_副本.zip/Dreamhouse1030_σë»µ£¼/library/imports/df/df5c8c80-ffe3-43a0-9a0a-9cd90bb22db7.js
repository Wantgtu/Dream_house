"use strict";
cc._RF.push(module, 'df5c8yA/+NDoJoKnNkLsi23', 'QQRewardAd');
// Script/sdk/sdk/qq/QQRewardAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseRewardAd_1 = require("../base/BaseRewardAd");
var SDKConfig_1 = require("../SDKConfig");
var QQRewardAd = /** @class */ (function (_super) {
    __extends(QQRewardAd, _super);
    function QQRewardAd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    QQRewardAd.prototype.destroy = function () {
    };
    QQRewardAd.prototype.create = function () {
        console.log(' 不支持多例');
        if (!this.rewardAd) {
            console.log(' create 111111');
            this.rewardAd = this.sdk.createRewardedVideoAd({ adUnitId: this.adUnitID });
            this.rewardAd.onLoad(this.onLoad.bind(this));
            this.rewardAd.onError(this.onError.bind(this));
            this.rewardAd.onClose(this.onClose.bind(this));
        }
        else {
        }
        console.log(' create 2222');
        this.rewardAd.load();
    };
    QQRewardAd.prototype.show = function () {
        this.logicState = SDKConfig_1.SDKState.close;
        this.setState(SDKConfig_1.SDKState.open);
        if (this.rewardAd) {
            console.log(' 展示激励视频 ');
            this.rewardAd.show();
        }
    };
    return QQRewardAd;
}(BaseRewardAd_1.default));
exports.default = QQRewardAd;

cc._RF.pop();