"use strict";
cc._RF.push(module, '0b6ccSNnZxHpodFgcAVFfZN', 'BoxpopMgr');
// Script/logic/boxpop/model/BoxpopMgr.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var model_1 = require("../../../cfw/model");
var module_1 = require("../../../cfw/module");
var BoxPopItemModel_1 = require("./BoxPopItemModel");
var Utils_1 = require("../../../cfw/tools/Utils");
var local_1 = require("../../../cfw/local");
var User_1 = require("../../user/User");
var RedTipMgr_1 = require("../../../extention/redtip/RedTipMgr");
var Config_1 = require("../../../config/Config");
var TestConfig_1 = require("../../../config/TestConfig");
var LevelMgr_1 = require("../../level/model/LevelMgr");
/**
* %SheetName%
**/
var BoxpopMgr = /** @class */ (function (_super) {
    __extends(BoxpopMgr, _super);
    function BoxpopMgr() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.boxPopItemModelMgr = new model_1.ModelManager();
        return _this;
    }
    // protected temp: BoxPopItemModel[]
    BoxpopMgr.prototype.initData = function () {
        this.boxPopItemModelMgr.initWithData(module_1.ModuleManager.dataManager.get(BoxPopItemModel_1.default.CLASS_NAME), BoxPopItemModel_1.default);
        this.count = new local_1.LocalValue('BoxpopMgrcount', 0);
        this.dayNum = new local_1.LocalValue('BoxpopMgrdayNum', 0);
        if (this.dayNum.getInt() != User_1.default.instance().getLoginDayNum()) {
            this.count.setValue(0);
            this.dayNum.setValue(User_1.default.instance().getLoginDayNum());
        }
        if (!this.needAd() && this.isOpen()) {
            RedTipMgr_1.default.instance().addRedTip(Config_1.RedTipType.BOX_POP);
        }
        if (TestConfig_1.default.BOX_POP) {
            // let list = this.getBoxPopItemModelList();
            // for (let index = 0; index < list.length; index++) {
            // 	const element = list[index];
            // 	let data = element.getItemAndWeight();
            // 	let count = data.length % 3;
            // 	console.log('BoxpopMgr data.length ', data.length, count)
            // 	if (count != 0) {
            // 		cc.error(' count is error ', index)
            // 	}
            // }
        }
    };
    BoxpopMgr.prototype.needAd = function () {
        return this.count.getInt() >= 2;
    };
    BoxpopMgr.prototype.updateCount = function () {
        this.count.updateValue(1);
    };
    BoxpopMgr.prototype.getBoxPopItemModel = function (id) { return this.boxPopItemModelMgr.getByID(id); };
    BoxpopMgr.prototype.getBoxPopItemModelList = function () { return this.boxPopItemModelMgr.getList(); };
    BoxpopMgr.prototype.setRandomList = function () {
        var array = this.getBoxPopItemModelList();
        for (var index = 0; index < array.length; index++) {
            var element = array[index];
            element.reset();
        }
        var spe = Utils_1.default.random(0, array.length);
        console.log(' spe ========= ', spe);
        if (array[spe]) {
            console.log(' spe ========= 222', spe);
            array[spe].setSpecial(1);
        }
        // let temp = []
        // let list = this.boxPopItemModelMgr.copy()
        // for (let index = 0; index < 9; index++) {
        // 	let r = Utils.random(0, list.length)
        // 	temp.push(list[r])
        // 	list.splice(r, 1)
        // }
        // this.temp = temp;
    };
    BoxpopMgr.prototype.getRandomList = function () {
        return this.getBoxPopItemModelList();
    };
    BoxpopMgr.prototype.isOpen = function () {
        return LevelMgr_1.default.instance().getLevel() >= Config_1.RANDOM_BOX_OPEN_LEVEL;
    };
    BoxpopMgr.prototype.getTip = function () {
        return Config_1.RANDOM_BOX_OPEN_LEVEL + '级之后开启';
    };
    return BoxpopMgr;
}(model_1.BaseModel));
exports.default = BoxpopMgr;

cc._RF.pop();