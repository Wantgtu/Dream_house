"use strict";
cc._RF.push(module, '6f89f4A/5dNcpcuFBCudy/R', 'KSShare');
// Script/sdk/sdk/ks/KSShare.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseShare_1 = require("../base/BaseShare");
var SDKConfig_1 = require("../SDKConfig");
var KSShare = /** @class */ (function (_super) {
    __extends(KSShare, _super);
    function KSShare() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    KSShare.prototype.getData = function (site) {
        var data = this.data[site];
        return data;
    };
    KSShare.prototype.share = function (index, func, videoPath) {
        var data = this.data[index];
        console.log(' share data ', data, videoPath, 'index ', index);
        // let videoPath = this.channel.getRecorder().getVideoPath();
        if (videoPath && data.extra) {
            data.extra.videoPath = videoPath;
        }
        data.success = function () {
            console.log('分享成功');
            if (func) {
                func(SDKConfig_1.ResultState.YES);
            }
            // this.shareSuccess();
        };
        data.fail = function (e) {
            console.log('分享失败');
            func(SDKConfig_1.ResultState.NO);
            // ToastController.instance().showLayerByText("分享失败")
        };
        this.sdk.shareAppMessage(data);
    };
    return KSShare;
}(BaseShare_1.BaseShare));
exports.default = KSShare;

cc._RF.pop();