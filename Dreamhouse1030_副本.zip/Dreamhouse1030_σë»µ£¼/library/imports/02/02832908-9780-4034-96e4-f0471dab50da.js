"use strict";
cc._RF.push(module, '02832kIl4BANJbk8Ecdq1Da', 'MiMoChannel');
// Script/sdk/sdk/mimo/MiMoChannel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseChannel_1 = require("../base/BaseChannel");
var SDKConfig_1 = require("../SDKConfig");
var MiMoBannerAd_1 = require("./MiMoBannerAd");
var MiMoRewardAd_1 = require("./MiMoRewardAd");
var MiMoInsertAd_1 = require("./MiMoInsertAd");
var MiMoCustomAd_1 = require("./MiMoCustomAd");
var MiMoSelfRenderAd_1 = require("./MiMoSelfRenderAd");
var MiMoLogin_1 = require("./MiMoLogin");
var MiMoChannel = /** @class */ (function (_super) {
    __extends(MiMoChannel, _super);
    function MiMoChannel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    MiMoChannel.prototype.init = function () {
        var cfg = this.cfg;
        var list = cfg[SDKConfig_1.ADName.reward];
        if (list) {
            for (var index = 0; index < list.length; index++) {
                var adId = list[index];
                this.rewardAd.push(new MiMoRewardAd_1.default(this, adId));
            }
        }
        list = cfg[SDKConfig_1.ADName.banner];
        if (list) {
            for (var index = 0; index < list.length; index++) {
                var adId = list[index];
                this.bannerAd.push(new MiMoBannerAd_1.default(this, adId));
            }
        }
        list = cfg[SDKConfig_1.ADName.insert];
        if (list) {
            for (var index = 0; index < list.length; index++) {
                var adId = list[index];
                this.insertAd.push(new MiMoInsertAd_1.default(this, adId));
            }
        }
        list = cfg[SDKConfig_1.ADName.customAd];
        if (list) {
            for (var index = 0; index < list.length; index++) {
                var adId = list[index];
                this.customAd.push(new MiMoCustomAd_1.default(this, adId));
            }
        }
        list = cfg[SDKConfig_1.ADName.selfrender];
        if (list) {
            for (var index = 0; index < list.length; index++) {
                var adId = list[index];
                this.selfRender.push(new MiMoSelfRenderAd_1.default(this, adId));
            }
        }
        this.loginMgr = new MiMoLogin_1.default(this);
    };
    MiMoChannel.prototype.exitApplication = function () {
        this.sdk.exitApplication();
    };
    MiMoChannel.prototype.initAd = function () {
        this.sdk.initAd();
    };
    return MiMoChannel;
}(BaseChannel_1.default));
exports.default = MiMoChannel;

cc._RF.pop();