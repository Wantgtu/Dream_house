"use strict";
cc._RF.push(module, 'daf60aV9c9I2bZrsHsdsXE7', 'QQChannel2');
// Script/sdk/sdk/qq/QQChannel2.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var QQChannel_1 = require("./QQChannel");
var SDKConfig_1 = require("../SDKConfig");
var QQBannerAd_1 = require("./QQBannerAd");
var QQChannel2 = /** @class */ (function (_super) {
    __extends(QQChannel2, _super);
    function QQChannel2() {
        // protected list: BaseBannerAd[] = []
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.pos = 0;
        _this.curBanner = 0;
        _this.max = 3;
        _this.logicState = SDKConfig_1.SDKState.open;
        return _this;
    }
    QQChannel2.prototype.add = function () {
        // this.bannerAd.push()
        var list = this.cfg[SDKConfig_1.ADName.banner];
        var adId = list[this.pos++];
        var banner = new QQBannerAd_1.default(this, adId);
        this.bannerAd.push(banner);
        if (this.pos >= this.max) {
            this.pos = 0;
        }
    };
    QQChannel2.prototype.refreshBanner = function () {
        if (this.curBanner >= 0 && this.bannerAd.length > this.curBanner) {
            this.bannerAd[this.curBanner].setVisible(false);
        }
        if (this.bannerAd.length <= 5) {
            this.add();
        }
        this.clear();
        if (this.logicState == SDKConfig_1.SDKState.open) {
            this.showBanner();
        }
    };
    QQChannel2.prototype.clear = function () {
        var d = [];
        for (var i = 0; i < this.bannerAd.length; i++) {
            var element = this.bannerAd[i];
            if (element.isError()) {
                d.push(element);
            }
        }
        if (this.bannerAd.length > 5) {
            for (var i = 0; i < this.bannerAd.length; i++) {
                var element = this.bannerAd[i];
                if (element.getAliveTime() > 30 || element.getShowTime() > 5 || element.isError()) {
                    d.push(element);
                }
            }
        }
        if (d.length > 0) {
            while (d.length > 0) {
                var e = d.shift();
                var idx = this.bannerAd.indexOf(e);
                if (idx >= 0) {
                    this.bannerAd[idx].close();
                    this.bannerAd[idx].destroy();
                    this.bannerAd.splice(idx, 1);
                }
            }
        }
    };
    QQChannel2.prototype.hideBanners = function () {
        for (var index = 0; index < this.bannerAd.length; index++) {
            var element = this.bannerAd[index];
            element.hide();
        }
    };
    QQChannel2.prototype.getIndex = function () {
        var i = -1;
        var showTime = 0;
        console.log('getIndex this.list.length ', this.bannerAd.length);
        for (var index = 0; index < this.bannerAd.length; index++) {
            var element = this.bannerAd[index];
            var ttime = element.getShowTime();
            console.log('getAliveTime   ', element.getAliveTime(), 'ttime   ', ttime);
            if (i == -1) {
                i = index;
                showTime = ttime;
            }
            else {
                if (ttime < showTime) {
                    i = index;
                    showTime = ttime;
                }
            }
        }
        return i;
    };
    QQChannel2.prototype.showBanner = function (state, dir, func) {
        if (state === void 0) { state = 0; }
        if (dir === void 0) { dir = SDKConfig_1.SDKDir.BOTTOM_MID; }
        var i = this.getIndex();
        console.log('showBanner i ', i, this.curBanner);
        this.hideBanners();
        this.curBanner = i;
        this.logicState = state;
        if (i >= 0) {
            _super.prototype.showBanner.call(this, i, dir, func);
        }
        else {
            console.warn('showBanner i < 0');
        }
        // this.list[0].show();
    };
    QQChannel2.prototype.setLogicState = function (s) {
        this.logicState = s;
    };
    QQChannel2.prototype.showBannerByXY = function (state, x, y, func) {
        if (state === void 0) { state = 0; }
        var i = this.getIndex();
        this.hideBanners();
        console.log('showBannerByXY i ', i);
        this.curBanner = i;
        this.logicState = state;
        if (i >= 0) {
            _super.prototype.showBannerByXY.call(this, i, x, y, func);
        }
        else {
            console.warn('showBannerByXY i < 0');
        }
    };
    QQChannel2.prototype.hideBanner = function (state) {
        if (state === void 0) { state = 0; }
        this.logicState = SDKConfig_1.SDKState.close;
        this.hideBanners();
        // console.log(' QQChannel2 hideBanner this.curBanner ', this.curBanner)
        // if (this.curBanner >= 0) {
        //     super.hideBanner(this.curBanner)
        //     // this.bannerAd.splice(this.curBanner, 1)
        //     // this.curBanner = -1;
        // }
        // this.list[0].hide();
    };
    return QQChannel2;
}(QQChannel_1.default));
exports.default = QQChannel2;

cc._RF.pop();