"use strict";
cc._RF.push(module, 'da398iu0llEt4lqIElKJn/v', 'AdaptUI');
// Script/cocos/adapt/AdaptUI.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var OrientationType;
(function (OrientationType) {
    OrientationType[OrientationType["Portrait"] = 0] = "Portrait";
    OrientationType[OrientationType["Landscape"] = 1] = "Landscape";
})(OrientationType || (OrientationType = {}));
;
var AdaptTarget = cc.Enum({
    None: 0,
    AdaptPosForTopBang: 1,
    AdaptPosForBottomBar: 2,
    AdaptSizeForTopBang: 3,
    AdaptSizeForBottomBar: 4,
});
var FitType;
(function (FitType) {
    FitType[FitType["HEIGHT"] = 0] = "HEIGHT";
    FitType[FitType["WIDTH"] = 1] = "WIDTH";
})(FitType || (FitType = {}));
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var AdaptUI = /** @class */ (function (_super) {
    __extends(AdaptUI, _super);
    function AdaptUI() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.num = 100;
        _this.target = AdaptTarget.AdaptPosForTopBang;
        return _this;
    }
    AdaptUI.prototype.start = function () {
        this.widget = this.node.getComponent(cc.Widget);
        if (!this.widget) {
            this.widget = this.node.addComponent(cc.Widget);
        }
        var frameSize = cc.view.getFrameSize();
        var frameAspectRatio = frameSize.width / frameSize.height;
        var designSize = cc.Canvas.instance.designResolution;
        var designAspectRatio = designSize.width / designSize.height;
        var sub = designAspectRatio > frameAspectRatio ? designAspectRatio - frameAspectRatio : frameAspectRatio - designAspectRatio;
        // console.log("sub  ", sub, ' frameAspectRatio ', frameAspectRatio, ' designAspectRatio ', designAspectRatio);
        //顶部偏移
        var topOffset = sub * this.num; //这个值根据自己的设计分辨率调整
        //底部偏移
        var bottomOffset = sub * this.num;
        var orientation = designSize.height > designSize.width ? OrientationType.Portrait : OrientationType.Landscape;
        this.adaptLogic(topOffset, bottomOffset, orientation);
    };
    AdaptUI.prototype.adaptLogic = function (topOffset, bottomOffset, orientation) {
        // console.log("adaptLogic", topOffset, bottomOffset, orientation)
        switch (this.target) {
            case AdaptTarget.AdaptPosForTopBang:
                if (topOffset == 0) {
                    return;
                }
                switch (orientation) {
                    case OrientationType.Portrait:
                        this.widget.top += topOffset;
                        break;
                    case OrientationType.Landscape:
                        this.widget.left += topOffset;
                        break;
                }
                break;
            case AdaptTarget.AdaptPosForBottomBar:
                if (bottomOffset == 0) {
                    return;
                }
                switch (orientation) {
                    case OrientationType.Portrait:
                        this.widget.bottom += bottomOffset;
                        break;
                    case OrientationType.Landscape:
                        this.widget.right += bottomOffset;
                        break;
                }
                break;
            case AdaptTarget.AdaptSizeForTopBang:
                if (topOffset == 0) {
                    return;
                }
                switch (orientation) {
                    case OrientationType.Portrait:
                        this.node.anchorY = 1;
                        this.node.height += topOffset;
                        break;
                    case OrientationType.Landscape:
                        this.node.anchorX = 0;
                        this.node.width += topOffset;
                        break;
                }
                break;
            case AdaptTarget.AdaptSizeForBottomBar:
                if (bottomOffset == 0) {
                    return;
                }
                switch (orientation) {
                    case OrientationType.Portrait:
                        this.node.anchorY = 0;
                        this.node.height += bottomOffset;
                        break;
                    case OrientationType.Landscape:
                        this.node.anchorX = 1;
                        this.node.width += bottomOffset;
                        break;
                }
                break;
        }
    };
    __decorate([
        property
    ], AdaptUI.prototype, "num", void 0);
    __decorate([
        property({
            type: AdaptTarget
        })
    ], AdaptUI.prototype, "target", void 0);
    AdaptUI = __decorate([
        ccclass
    ], AdaptUI);
    return AdaptUI;
}(cc.Component));
exports.default = AdaptUI;

cc._RF.pop();