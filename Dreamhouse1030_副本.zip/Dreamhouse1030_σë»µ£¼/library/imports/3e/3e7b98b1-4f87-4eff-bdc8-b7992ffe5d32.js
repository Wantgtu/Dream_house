"use strict";
cc._RF.push(module, '3e7b9ixT4dO/73It5kv/l0y', 'SoundManager');
// Script/engine/SoundManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SoundManager = void 0;
var engine_1 = require("./engine");
var audio_1 = require("../cfw/audio");
var SoundManager = /** @class */ (function () {
    function SoundManager() {
        this.sourcePool = {};
        // private soundMap: TSMap<string, number> = new TSMap();
        this.playingName = [];
    }
    SoundManager.prototype.getMaxNum = function () {
        return engine_1.engine.audioEngine.getMaxAudioInstance();
    };
    /**
     *
     * @param name
     * @param res
     * @param canMulply 不可以同时播放两个以上
     */
    SoundManager.prototype.play = function (name, res, playCount, type) {
        if (playCount === void 0) { playCount = 1; }
        if (type === void 0) { type = audio_1.SoundType.NO_LIMIT; }
        // cc.log(' play sound name ', name, ' canMulply ', canMulply)
        var audioId = -1;
        switch (type) {
            case audio_1.SoundType.CLOSE_OTHER:
                var runningName = this.playingName[type];
                if (runningName) {
                    this.stop(runningName);
                    this.playingName[type] = null;
                }
                break;
            case audio_1.SoundType.HAS_OTHER:
                if (this.playingName[type]) {
                    return;
                }
                break;
            case audio_1.SoundType.NO_LIMIT:
                break;
        }
        audioId = engine_1.engine.audioEngine.playEffect(res, playCount);
        if (audioId) {
            this.playingName[type] = name;
            this.addSound(name, audioId);
            if (playCount == 1)
                engine_1.engine.audioEngine.setFinishCallback(audioId, this.over.bind(this, type));
        }
    };
    SoundManager.prototype.addSound = function (name, audioId) {
        if (!this.sourcePool[name]) {
            this.sourcePool[name] = [];
        }
        this.sourcePool[name].push(audioId);
    };
    SoundManager.prototype.get = function (name, isDelete) {
        if (isDelete === void 0) { isDelete = false; }
        // console.log(' this.sourcePool.has(name) ', this.sourcePool.has(name))
        // if (this.sourcePool[name]) {
        var list = this.sourcePool[name];
        if (list && list.length > 0) {
            if (isDelete) {
                return list.shift();
            }
            else {
                return list[0];
            }
        }
        // }
        return 0;
    };
    SoundManager.prototype.over = function (type) {
        var name = this.playingName[type];
        // this.soundMap.remove(name)
        this.get(name, true);
        this.playingName[type] = null;
    };
    SoundManager.prototype.pause = function (name) {
        for (var key in this.sourcePool) {
            var list = this.sourcePool[key];
            for (var index = 0; index < list.length; index++) {
                var audioId = list[index];
                engine_1.engine.audioEngine.pauseEffect(audioId);
            }
        }
    };
    SoundManager.prototype.resume = function (name) {
        for (var key in this.sourcePool) {
            var list = this.sourcePool[key];
            for (var index = 0; index < list.length; index++) {
                var audioId = list[index];
                engine_1.engine.audioEngine.resumeEffect(audioId);
            }
        }
    };
    SoundManager.prototype.stop = function (name) {
        var audioId = this.get(name, true);
        // console.log('SoundManager stop name ', name, ' audioId ', audioId)
        if (audioId >= 0 || typeof (audioId) == 'object') {
            engine_1.engine.audioEngine.stopEffect(audioId);
        }
    };
    SoundManager.prototype.setVolume = function (count) {
        engine_1.engine.audioEngine.setEffectsVolume(count);
    };
    SoundManager.prototype.stopAll = function () {
        for (var key in this.sourcePool) {
            var list = this.sourcePool[key];
            for (var index = 0; index < list.length; index++) {
                var audioId = list[index];
                engine_1.engine.audioEngine.stopEffect(audioId);
            }
        }
        // this.soundMap.clear();
    };
    SoundManager.prototype.isPlaying = function () {
        return false;
    };
    SoundManager.prototype.clear = function () {
        this.stopAll();
        this.sourcePool = {};
        // this.soundMap.clear()
    };
    return SoundManager;
}());
exports.SoundManager = SoundManager;

cc._RF.pop();