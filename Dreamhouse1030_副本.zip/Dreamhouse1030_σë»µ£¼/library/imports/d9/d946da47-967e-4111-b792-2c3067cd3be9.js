"use strict";
cc._RF.push(module, 'd946dpHln5BEbeSLDBnzTvp', 'CMgr');
// Script/sdk/channel-ts/CMgr.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DevHelper_1 = require("./DevHelper");
var QQHelper_1 = require("./QQHelper");
var VivoHelper_1 = require("./VivoHelper");
var WXHelper_1 = require("./WXHelper");
var OppoHelper_1 = require("./OppoHelper");
var SDKConfig_1 = require("../sdk/SDKConfig");
var TTHelper_1 = require("./TTHelper");
var F399Helper_1 = require("./F399Helper");
var KSHelper_1 = require("./KSHelper");
var MiMoHelper_1 = require("./MiMoHelper");
/**
 * ChannelManager
 */
var CMgr = /** @class */ (function () {
    function CMgr() {
    }
    Object.defineProperty(CMgr, "helper", {
        get: function () {
            return this.h;
        },
        enumerable: false,
        configurable: true
    });
    CMgr.setHelper = function (id) {
        var helper = null;
        var channelID = id;
        // console.log(' getChannel id ', id, channelID)
        switch (channelID) {
            case SDKConfig_1.ChannelID.QQ:
                helper = new QQHelper_1.default();
                break;
            case SDKConfig_1.ChannelID.VIVO:
                helper = new VivoHelper_1.default();
                break;
            case SDKConfig_1.ChannelID.WX:
                helper = new WXHelper_1.default();
                break;
            case SDKConfig_1.ChannelID.OPPO:
                helper = new OppoHelper_1.default();
                break;
            case SDKConfig_1.ChannelID.TT:
                helper = new TTHelper_1.default();
                break;
            case SDKConfig_1.ChannelID.F399:
                helper = new F399Helper_1.default();
                break;
            case SDKConfig_1.ChannelID.KS:
                helper = new KSHelper_1.default();
                break;
            case SDKConfig_1.ChannelID.MIMO:
                helper = new MiMoHelper_1.default();
                break;
            default:
                helper = new DevHelper_1.default();
                break;
        }
        this.h = helper;
    };
    return CMgr;
}());
exports.default = CMgr;

cc._RF.pop();