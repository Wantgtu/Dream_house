"use strict";
cc._RF.push(module, 'd960fktLaBHvYDEXhWVVGXS', 'UIText');
// Script/cocos/lang/UIText.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var module_1 = require("../../cfw/module");
var LangManager_1 = require("../../cfw/tools/LangManager");
var UIText = /** @class */ (function () {
    function UIText() {
        this.uiData = module_1.ModuleManager.dataManager.get('UITextModel');
    }
    UIText.instance = function () {
        if (!this.ins) {
            this.ins = new UIText();
        }
        return this.ins;
    };
    UIText.prototype.getText = function (id, opt) {
        var content = this.uiData.getValue(id, 0);
        // console.log(' content ', content)
        return LangManager_1.default.instance().getLocalString(content, opt);
    };
    return UIText;
}());
exports.default = UIText;

cc._RF.pop();