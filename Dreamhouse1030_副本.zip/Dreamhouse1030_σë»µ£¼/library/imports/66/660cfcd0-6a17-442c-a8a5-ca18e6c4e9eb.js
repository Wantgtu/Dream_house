"use strict";
cc._RF.push(module, '660cfzQahdELKilyhjmxOnr', 'MoveCollide');
// Script/cfw/move/MoveCollide.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

cc._RF.pop();