"use strict";
cc._RF.push(module, '66de73uZU9EMYqKPhjEWUNk', 'LobbyC');
// Script/logic/lobby/LobbyC.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var mvc_1 = require("../../cfw/mvc");
var ViewManager_1 = require("../../cfw/tools/ViewManager");
var ModuleConfig_1 = require("../../config/ModuleConfig");
var UIConfig_1 = require("../../config/UIConfig");
var module_1 = require("../../cfw/module");
var res_1 = require("../../cfw/res");
var LoadingC_1 = require("../public/loading/LoadingC");
var ItemC_1 = require("../item/ItemC");
var SceneC_1 = require("../scene/SceneC");
var GameC_1 = require("../game/GameC");
var TaskC_1 = require("../task/TaskC");
var TaskMgr_1 = require("../task/model/TaskMgr");
var LevelC_1 = require("../level/LevelC");
var StartC_1 = require("../start/StartC");
var model_1 = require("../../cfw/model");
var SoundMgr_1 = require("../sound/model/SoundMgr");
var Config_1 = require("../../config/Config");
var User_1 = require("../user/User");
var ActivityC_1 = require("../activity/ActivityC");
var WeeklyC_1 = require("../weekly/WeeklyC");
var GameEventAdapter_1 = require("../../extention/gevent/GameEventAdapter");
var DailyTaskMgr_1 = require("../dailytask/model/DailyTaskMgr");
var ActivityMgr_1 = require("../activity/model/ActivityMgr");
var LangManager_1 = require("../../cfw/tools/LangManager");
var SceneMgr_1 = require("../scene/model/SceneMgr");
var PrivacyC_1 = require("../../sdk/agreement/PrivacyC");
var CMgr_1 = require("../../sdk/channel-ts/CMgr");
var SDKManager_1 = require("../../sdk/sdk/SDKManager");
var GiftBoxC_1 = require("../giftbox/GiftBoxC");
var UmengEventID_1 = require("../../config/UmengEventID");
var Debug_1 = require("../../cfw/tools/Debug");
var preloads = ['public/public', 'texture/props', 'bg/person'];
var LobbyC = /** @class */ (function (_super) {
    __extends(LobbyC, _super);
    function LobbyC() {
        return _super.call(this) || this;
        // GEvent.instance().on(EventName.NEW_BUILD_OPEN, this.newBuildOpen, this)
    }
    LobbyC.prototype.getCurID = function () {
        return SceneMgr_1.default.instance().getCurID();
    };
    LobbyC.prototype.intoLayer = function () {
        var _this = this;
        var flag = module_1.BundleManager.instance().hasBundle(ModuleConfig_1.ModuleID.PUBLIC);
        // console.log('SceneC flag ', model.getBundle(), flag)
        if (flag) {
            this.showView();
        }
        else {
            LoadingC_1.default.instance().addItem('data/game_info', res_1.ResType.Json, ModuleConfig_1.ModuleID.RES, '加载游戏配置信息');
            LoadingC_1.default.instance().addItem('data/activity_info', res_1.ResType.Json, ModuleConfig_1.ModuleID.RES, '加载活动配置信息');
            LoadingC_1.default.instance().addItem('data/game_lang_zh', res_1.ResType.Json, ModuleConfig_1.ModuleID.RES, '加载文本配置信息');
            LoadingC_1.default.instance().addItem(ModuleConfig_1.ModuleID.PUBLIC, res_1.ResType.AssetBundle, ModuleConfig_1.ModuleID.RES, '加载公共分包');
            LoadingC_1.default.instance().addItem(ModuleConfig_1.ModuleID.CRAZY_CLICK, res_1.ResType.AssetBundle, ModuleConfig_1.ModuleID.RES, '加载砸蛋分包');
            LoadingC_1.default.instance().addItem(ModuleConfig_1.ModuleID.GAME, res_1.ResType.AssetBundle, ModuleConfig_1.ModuleID.RES, '加载游戏分包');
            LoadingC_1.default.instance().addItem(ModuleConfig_1.ModuleID.AUDIO, res_1.ResType.AssetBundle, ModuleConfig_1.ModuleID.RES, '加载音频分包');
            if (StartC_1.default.instance().isState(model_1.ItemState.NOT_GET)) {
                LoadingC_1.default.instance().addItem(ModuleConfig_1.ModuleID.START, res_1.ResType.AssetBundle, ModuleConfig_1.ModuleID.RES, '加载初始分包');
            }
            console.log('SDKManager.getChannel().hasNativeAd() ', SDKManager_1.default.getChannel().hasNativeAd());
            if (SDKManager_1.default.getChannel().hasNativeAd()) {
                LoadingC_1.default.instance().addItem(ModuleConfig_1.ModuleID.nativeAd, res_1.ResType.AssetBundle, ModuleConfig_1.ModuleID.RES, '加载nativeAd分包');
            }
            if (CMgr_1.default.helper.hasInstallApp()) {
                LoadingC_1.default.instance().addItem(ModuleConfig_1.ModuleID.install, res_1.ResType.AssetBundle, ModuleConfig_1.ModuleID.RES, '加载install分包');
            }
            LoadingC_1.default.instance().addItem('public/public', res_1.ResType.SpriteAtlas, ModuleConfig_1.ModuleID.PUBLIC, '加载共用大图');
            LoadingC_1.default.instance().addItem('texture/props', res_1.ResType.SpriteAtlas, ModuleConfig_1.ModuleID.GAME, '加载游戏大图');
            LoadingC_1.default.instance().addItem('bg/person', res_1.ResType.SpriteAtlas, ModuleConfig_1.ModuleID.GAME, '加载角色头像大图');
            // LoadingC.instance().addItem('data/guide_config', ResType.Json, ModuleID.RES, '加载配置文件')
            LoadingC_1.default.instance().intoLayer(function () {
                var data = module_1.ModuleManager.dataManager.get('game_lang_zh').getData();
                // console.log("data['data']", data)
                LangManager_1.default.instance().addData(data);
                if (CMgr_1.default.helper.hasAgreement()) {
                    PrivacyC_1.default.instance().intoLayer(function () {
                        if (StartC_1.default.instance().isState(model_1.ItemState.NOT_GET)) {
                            StartC_1.default.instance().intoLayer();
                        }
                        else {
                            _this.firstShow();
                        }
                    });
                }
                else {
                    if (StartC_1.default.instance().isState(model_1.ItemState.NOT_GET)) {
                        StartC_1.default.instance().intoLayer();
                    }
                    else {
                        _this.firstShow();
                    }
                }
            });
        }
    };
    LobbyC.prototype.firstShow = function () {
        var time = Debug_1.default.timeEnd();
        CMgr_1.default.helper.trackEvent(UmengEventID_1.default.enter_lobby, { time: time });
        TaskMgr_1.default.instance();
        this.showView();
        ItemC_1.default.instance().intoLayer();
        LevelC_1.default.instance().intoLayer();
        GiftBoxC_1.default.instance().intoLayer();
        CMgr_1.default.helper.sheduleGame();
    };
    LobbyC.prototype.showView = function () {
        ViewManager_1.default.pushUIView({
            path: 'prefabs/LobbyView',
            moduleID: ModuleConfig_1.ModuleID.PUBLIC,
            uiIndex: UIConfig_1.UIIndex.ROOT,
            controller: this,
            func: function () {
            }
        });
    };
    LobbyC.prototype.init = function () {
        setTimeout(function () {
            if (SoundMgr_1.default.instance().getMusicFlag()) {
                SoundMgr_1.default.instance().playMusic(Config_1.SoundID.MusicBg);
            }
            // console.log(' User.instance().getLoginCount() ', User.instance().getLoginCount())
            if (User_1.default.instance().getLoginCount() > 1) {
                if (!GameEventAdapter_1.default.instance().isOpen()) {
                    ActivityC_1.default.instance().showOfflineView();
                    CMgr_1.default.helper.firstIntoLobby();
                }
            }
            if (!GameEventAdapter_1.default.instance().isOpen()) {
                WeeklyC_1.default.instance().intoLayer();
            }
            DailyTaskMgr_1.default.instance();
            ActivityMgr_1.default.instance();
        }, 500);
    };
    LobbyC.prototype.intoTask = function () {
        TaskC_1.default.instance().intoLayer();
    };
    LobbyC.prototype.intoGame = function () {
        GameC_1.default.instance().intoLayer();
    };
    LobbyC.prototype.addScene = function (parent, sceneID, func) {
        SceneC_1.default.instance().intoLayer(parent, sceneID, func);
    };
    LobbyC.prototype.leftScene = function () {
        SceneMgr_1.default.instance().left();
    };
    LobbyC.prototype.rightScene = function () {
        SceneMgr_1.default.instance().right();
    };
    return LobbyC;
}(mvc_1.BaseController));
exports.default = LobbyC;

cc._RF.pop();