"use strict";
cc._RF.push(module, '9efdbukwb1HxaKv3Pb2Aana', 'zs_xm_sdk');
// Script/sdk/lib/zs_xm_sdk.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var lc_sdk_1 = require("./lc_sdk");
var SDKHelper_1 = require("../sdk/SDKHelper");
var URL = 'https://platform.qwpo2018.com/api/list_config/index?apk_id=';
var zs_xm_sdk = /** @class */ (function (_super) {
    __extends(zs_xm_sdk, _super);
    function zs_xm_sdk() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    zs_xm_sdk.prototype.loadCfg = function (ok, fail) {
        SDKHelper_1.default.sendHttpRequest(URL + this.appId, '', function (msg, data) {
            if (msg) {
                fail(msg);
            }
            else {
                ok(data);
            }
        });
    };
    return zs_xm_sdk;
}(lc_sdk_1.default));
exports.default = zs_xm_sdk;

cc._RF.pop();