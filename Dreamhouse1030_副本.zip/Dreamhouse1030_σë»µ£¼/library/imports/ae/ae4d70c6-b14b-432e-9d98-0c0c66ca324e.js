"use strict";
cc._RF.push(module, 'ae4d7DGsUtDLp2YDAxmyjJO', 'BuildSelectView');
// Script/logic/scene/view/BuildSelectView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../cfw/view");
var event_1 = require("../../../cfw/event");
var Config_1 = require("../../../config/Config");
var SoundMgr_1 = require("../../sound/model/SoundMgr");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BuildSelectView = /** @class */ (function (_super) {
    __extends(BuildSelectView, _super);
    function BuildSelectView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ButtonCancelSprite = null;
        _this.ButtonCancelButton = null;
        _this.ButtonSelectSprite = null;
        _this.ButtonSelectButton = null;
        _this.selectLabelLabel = null;
        _this.adSprite = null;
        _this.RoomWindowArrow_LSprite = null;
        _this.RoomWindowArrow_LButton = null;
        _this.RoomWindowArrow_RSprite = null;
        _this.RoomWindowArrow_RButton = null;
        _this.index = 0;
        return _this;
    }
    BuildSelectView.prototype.onLoad = function () {
        // this.node['_hitTest'] = this.hitTest.bind(this)
        this.index = this.model.getItem();
        this.node.on(cc.Node.EventType.TOUCH_START, this.onMouseDown, this);
        // this.onRoomWindowArrow_RButtonClick();
    };
    BuildSelectView.prototype.hitTest = function (pos) {
        this.hide();
        return false;
    };
    BuildSelectView.prototype.onMouseDown = function (e) {
        // let pos = e.getLocation();
        // // console.log(' onMouseDown pos ',pos)
        // let size = cc.view.getVisibleSize()
        // if (pos.x > size.width / 2) {
        // 	this.onRoomWindowArrow_RButtonClick();
        // } else {
        // 	this.onRoomWindowArrow_LButtonClick();
        // }
        this.hide();
    };
    BuildSelectView.prototype.onDestroy = function () {
    };
    BuildSelectView.prototype.onButtonCancelButtonClick = function () {
        this.hide();
        event_1.GEvent.instance().emit(Config_1.EventName.CHANGE_BUILD_IMG, this.model, this.model.getItem());
    };
    BuildSelectView.prototype.onButtonSelectButtonClick = function () {
        this.hide();
        // this.model.setItem(this.index)
        // GEvent.instance().emit(EventName.CHANGE_BUILD_IMG, this.model, this.model.getItem())
    };
    BuildSelectView.prototype.onRoomWindowArrow_LButtonClick = function () {
        this.index = this.index + 1;
        if (this.index > 3) {
            this.index = 0;
        }
        this.model.setItem(this.index);
        event_1.GEvent.instance().emit(Config_1.EventName.CHANGE_BUILD_IMG, this.model, this.index);
        SoundMgr_1.default.instance().playSound(Config_1.SoundID.sfx_buttonPress);
    };
    BuildSelectView.prototype.onRoomWindowArrow_RButtonClick = function () {
        this.index = this.index - 1;
        if (this.index < 0) {
            this.index = 3;
        }
        this.model.setItem(this.index);
        event_1.GEvent.instance().emit(Config_1.EventName.CHANGE_BUILD_IMG, this.model, this.index);
        SoundMgr_1.default.instance().playSound(Config_1.SoundID.sfx_buttonPress);
    };
    __decorate([
        property({ type: cc.Sprite, displayName: "ButtonCancelSprite" })
    ], BuildSelectView.prototype, "ButtonCancelSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "ButtonCancelButton" })
    ], BuildSelectView.prototype, "ButtonCancelButton", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "ButtonSelectSprite" })
    ], BuildSelectView.prototype, "ButtonSelectSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "ButtonSelectButton" })
    ], BuildSelectView.prototype, "ButtonSelectButton", void 0);
    __decorate([
        property({ type: cc.Label, displayName: "selectLabelLabel" })
    ], BuildSelectView.prototype, "selectLabelLabel", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "adSprite" })
    ], BuildSelectView.prototype, "adSprite", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "RoomWindowArrow_LSprite" })
    ], BuildSelectView.prototype, "RoomWindowArrow_LSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "RoomWindowArrow_LButton" })
    ], BuildSelectView.prototype, "RoomWindowArrow_LButton", void 0);
    __decorate([
        property({ type: cc.Sprite, displayName: "RoomWindowArrow_RSprite" })
    ], BuildSelectView.prototype, "RoomWindowArrow_RSprite", void 0);
    __decorate([
        property({ type: cc.Button, displayName: "RoomWindowArrow_RButton" })
    ], BuildSelectView.prototype, "RoomWindowArrow_RButton", void 0);
    BuildSelectView = __decorate([
        ccclass
    ], BuildSelectView);
    return BuildSelectView;
}(view_1.BaseView));
exports.default = BuildSelectView;

cc._RF.pop();