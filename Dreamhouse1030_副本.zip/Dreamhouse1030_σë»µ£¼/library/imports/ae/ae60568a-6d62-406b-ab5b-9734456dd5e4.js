"use strict";
cc._RF.push(module, 'ae605aKbWJAa6tblzRFbdXk', 'InsertAdMgr');
// Script/sdk/comp/InsertAdMgr.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var event_1 = require("../../cfw/event");
var CMgr_1 = require("../channel-ts/CMgr");
var InsertAdMgr = /** @class */ (function () {
    function InsertAdMgr() {
    }
    InsertAdMgr.isBannerState = function () {
        return this.hideBannerCount <= 0;
    };
    InsertAdMgr.setBannerState = function (f) {
        if (!CMgr_1.default.helper.isVersion()) {
            return false;
        }
        if (!f) {
            this.hideBannerCount++;
            event_1.GEvent.instance().emit(this.OPEN_NATIVE_AD);
        }
        else {
            this.hideBannerCount--;
            if (this.hideBannerCount <= 0) {
                this.hideBannerCount = 0;
                event_1.GEvent.instance().emit(this.CLOSE_NATIVE_AD);
            }
        }
    };
    InsertAdMgr.OPEN_NATIVE_AD = 'OPEN_NATIVE_AD';
    InsertAdMgr.CLOSE_NATIVE_AD = 'CLOSE_NATIVE_AD';
    // static FORCE_CLOSE: boolean = false;
    InsertAdMgr.hideBannerCount = 0;
    return InsertAdMgr;
}());
exports.default = InsertAdMgr;

cc._RF.pop();