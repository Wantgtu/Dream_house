"use strict";
cc._RF.push(module, 'aeba7havJ5FvpHX25CwoyNk', 'TaskC');
// Script/logic/task/TaskC.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var mvc_1 = require("../../cfw/mvc");
var LobbyC_1 = require("../lobby/LobbyC");
var ViewManager_1 = require("../../cfw/tools/ViewManager");
var ModuleConfig_1 = require("../../config/ModuleConfig");
var UIConfig_1 = require("../../config/UIConfig");
var TaskMgr_1 = require("./model/TaskMgr");
var model_1 = require("../../cfw/model");
var Config_1 = require("../../config/Config");
var RedTipMgr_1 = require("../../extention/redtip/RedTipMgr");
var CMgr_1 = require("../../sdk/channel-ts/CMgr");
var TaskC = /** @class */ (function (_super) {
    __extends(TaskC, _super);
    function TaskC() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TaskC.prototype.intoLayer = function () {
        var m = TaskMgr_1.default.instance().getCurTask();
        if (!m) {
            return;
        }
        ViewManager_1.default.pushUIView({
            path: 'prefabs/TaskView',
            moduleID: ModuleConfig_1.ModuleID.PUBLIC,
            uiIndex: UIConfig_1.UIIndex.STACK,
            model: m,
            controller: this,
        });
    };
    TaskC.prototype.playGame = function () {
        LobbyC_1.default.instance().intoGame();
    };
    TaskC.prototype.getTaskReward = function (m, r, pos) {
        var _this = this;
        if (r === void 0) { r = 1; }
        if (m.getState() == model_1.ItemState.CAN_GET) {
            if (r > 1) {
                CMgr_1.default.helper.showRewardAd(0, function (s) {
                    if (s) {
                        _this.addItems(m, r, pos);
                    }
                });
            }
            else {
                this.addItems(m, r, pos);
            }
        }
    };
    TaskC.prototype.addItems = function (task, r, pos) {
        if (r === void 0) { r = 1; }
        if (TaskMgr_1.default.instance().addItems(task, r, pos)) {
            RedTipMgr_1.default.instance().removeRedTip(Config_1.RedTipType.HAS_TASK);
            TaskMgr_1.default.instance().updateTaskID();
            TaskMgr_1.default.instance().updateTaskState();
        }
        // if (BagManager.instance().isEnough(ItemID.GOLD, task.getGold())) {
        //     BagManager.instance().updateItemNum(ItemID.GOLD, -task.getGold())
        //     for (let index = 0; index < r; index++) {
        //         let other = task.getOther();
        //         if (other && other.length > 0) {
        //             for (let index = 0; index < other.length; index++) {
        //                 const foodID = other[index];
        //                 // FoodMgr.instance().addItem(foodID)
        //                 // GridFoodMgr.instance().addItem(foodID)
        //                 BagManager.instance().updateItemNum(foodID, 1)
        //             }
        //         }
        //     }
        //     task.setState(ItemState.GOT)
        //     let exp = task.getExp()
        //     BagManager.instance().updateItemNum(ItemID.EXP, exp, pos)
        //     RedTipMgr.instance().removeRedTip(RedTipType.HAS_TASK)
        //     TaskMgr.instance().updateTaskID()
        //     TaskMgr.instance().updateTaskState()
        // }
    };
    return TaskC;
}(mvc_1.BaseController));
exports.default = TaskC;

cc._RF.pop();