"use strict";
cc._RF.push(module, 'aed2cJ1j3hBdrAI4unIU2uf', 'GuideEventName');
// Script/extention/guide/GuideEventName.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GuideEventName = /** @class */ (function () {
    function GuideEventName() {
    }
    GuideEventName.START = 'guide_start';
    GuideEventName.SET_WIDGET = 'guide_set_widget';
    GuideEventName.SET_FUNC = 'guide_set_func';
    GuideEventName.SHOW = 'guide_show';
    GuideEventName.UPDATE = 'guide_update';
    GuideEventName.FINISH = 'guide_finish';
    // static UPDATE_STEP: string = 'guide_update_step'
    GuideEventName.TRIGER_FUNC = 'guide_triger_func';
    GuideEventName.BUTTON_CLICK = 'BUTTON_CLICK';
    GuideEventName.TOUCH_MOVE = 'TOUCH_MOVE';
    GuideEventName.TOUCH_END = 'TOUCH_END';
    GuideEventName.TOUCH_EVENT = 'TOUCH_EVENT';
    return GuideEventName;
}());
exports.default = GuideEventName;

cc._RF.pop();