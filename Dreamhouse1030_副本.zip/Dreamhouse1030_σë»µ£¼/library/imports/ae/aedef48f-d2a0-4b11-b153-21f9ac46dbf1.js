"use strict";
cc._RF.push(module, 'aedefSP0qBLEbFTIfmsRtvx', 'engine');
// Script/engine/engine.ts

"use strict";
// export class NPCObject {
//     protected node: cc.Node;
//     constructor(n: cc.Node) {
//         this.node = n;
//     }
//     set scaleX(s: number) {
//         this.node.scaleX = s;
//     }
Object.defineProperty(exports, "__esModule", { value: true });
exports.engine = void 0;
//     get scaleX(): number {
//         return this.node.scaleX
//     }
// }
var LocalStorage = /** @class */ (function () {
    function LocalStorage() {
    }
    LocalStorage.prototype.getItem = function (key) {
        return cc.sys.localStorage.getItem(key);
    };
    LocalStorage.prototype.getLength = function () {
        return cc.sys.localStorage.length;
    };
    LocalStorage.prototype.setItem = function (key, value) {
        cc.sys.localStorage.setItem(key, value);
    };
    LocalStorage.prototype.clear = function () {
        cc.sys.localStorage.clear();
    };
    LocalStorage.prototype.removeItem = function (key) {
        cc.sys.localStorage.removeItem(key);
    };
    return LocalStorage;
}());
var AudioEngine = /** @class */ (function () {
    function AudioEngine() {
    }
    AudioEngine.prototype.getMaxAudioInstance = function () {
        return cc.audioEngine.getMaxAudioInstance();
    };
    AudioEngine.prototype.playMusic = function (res, isLoop) {
        return cc.audioEngine.playMusic(res, isLoop);
    };
    AudioEngine.prototype.setFinishCallback = function (audioId, func) {
        cc.audioEngine.setFinishCallback(audioId, func);
    };
    AudioEngine.prototype.pauseMusic = function () {
        cc.audioEngine.pauseMusic();
    };
    AudioEngine.prototype.resumeMusic = function () {
        cc.audioEngine.resumeMusic();
    };
    AudioEngine.prototype.stopMusic = function () {
        cc.audioEngine.stopMusic();
    };
    AudioEngine.prototype.setMusicVolume = function (count) {
        cc.audioEngine.setMusicVolume(count);
    };
    AudioEngine.prototype.isMusicPlaying = function () {
        return cc.audioEngine.isMusicPlaying();
    };
    AudioEngine.prototype.playEffect = function (res, playCount, func) {
        var isLoop = playCount == 0 ? true : false;
        var audioID = cc.audioEngine.playEffect(res, isLoop);
        if (func) {
            this.setFinishCallback(audioID, func);
        }
        return audioID;
    };
    AudioEngine.prototype.pauseEffect = function (audioId) {
        cc.audioEngine.pauseEffect(audioId);
    };
    AudioEngine.prototype.resumeEffect = function (audioId) {
        cc.audioEngine.resumeEffect(audioId);
    };
    AudioEngine.prototype.setEffectsVolume = function (count) {
        cc.audioEngine.setEffectsVolume(count);
    };
    AudioEngine.prototype.stopEffect = function (audioId) {
        cc.audioEngine.stopEffect(audioId);
    };
    AudioEngine.prototype.uncacheAll = function () {
        cc.audioEngine.uncacheAll();
    };
    return AudioEngine;
}());
var engine = /** @class */ (function () {
    function engine() {
    }
    engine.getWritablePath = function () {
        return jsb.fileUtils.getWritablePath();
    };
    engine.writeStringToFile = function (data, filePath) {
        jsb.fileUtils.writeStringToFile(data, filePath);
    };
    engine.isFileExist = function (filePath) {
        return jsb.fileUtils.isFileExist(filePath);
    };
    engine.getStringFromFile = function (filePath) {
        return jsb.fileUtils.getStringFromFile(filePath);
    };
    engine.addChild = function (node, parent) {
        parent.addChild(node);
    };
    /**
     *
     * @param className
     * @param methodName
     * @param parameters
     * @param methodSignature
     */
    engine.callStaticMethod = function (className, methodName, parameters, methodSignature) {
        if (methodSignature === void 0) { methodSignature = "(Ljava/lang/String;)V"; }
        console.log(" JsNativeBridge callStaticMethod ", cc.sys.isNative);
        if (!cc.sys.isNative) {
            return -1;
        }
        console.log(" JsNativeBridge callStaticMethod ", methodName, parameters);
        if (cc.sys.os == cc.sys.OS_IOS) {
            var result = jsb.reflection.callStaticMethod(className, methodName, parameters);
            if (result) {
                console.log("callStaticMethod ios  ", result);
            }
        }
        else {
            console.log(" JsNativeBridge callStaticMethod adroid ");
            var result = jsb.reflection.callStaticMethod(className, methodName, methodSignature, parameters);
            console.log("callStaticMethod result  ", result);
            if (result) {
                return result;
            }
        }
    };
    engine.createCanvas = function () {
        var canvas = document.createElement('canvas');
        console.log(' canvas ', canvas);
        return canvas;
    };
    engine.find = function (name, node) {
        return cc.find(name, node);
    };
    engine.getChildByIndex = function (node, index) {
        return node.children[index];
    };
    engine.findChild = function (name, node) {
        var temp = cc.find(name, node);
        if (temp) {
            return temp;
        }
        else {
            var count = node.children.length;
            for (var index = 0; index < count; index++) {
                var element = node.children[index];
                temp = this.findChild(name, element);
                if (temp) {
                    return temp;
                }
            }
            return null;
        }
    };
    engine.isValid = function (node) {
        return cc.isValid(node);
    };
    engine.getDefaultBundle = function () {
        return cc.resources;
    };
    engine.loadRemote = function (url, callback) {
        cc.assetManager.loadRemote(url, callback);
    };
    engine.loadBundle = function (url, callback) {
        cc.assetManager.loadBundle(url, callback);
    };
    engine.getBundle = function (url) {
        return cc.assetManager.getBundle(url);
    };
    engine.loadScene = function (sceneName, func) {
        cc.director.loadScene(sceneName, function (error, scene) {
            func(error, scene);
        });
    };
    engine.runScene = function (scene) {
        cc.director.runScene(scene);
    };
    engine.instantiate = function (res) {
        return cc.instantiate(res);
    };
    engine.getComponent = function (node, className) {
        return node.getComponent(className);
    };
    engine.getChildByName = function (node, name) {
        return node.getChildByName(name);
    };
    engine.getFrameSize = function () {
        return cc.view.getFrameSize();
    };
    engine.getVisibleSize = function () {
        return cc.view.getVisibleSize();
    };
    engine.getDesignSize = function () {
        return cc.Canvas.instance.designResolution;
    };
    engine.getDesignResolutionSize = function () {
        return cc.view.getDesignResolutionSize();
    };
    engine.frameAspectRatio = function () {
        var fs = this.getFrameSize();
        return fs.width / fs.height;
    };
    engine.designAspectRatio = function () {
        var ds = this.getDesignSize();
        return ds.width / ds.height;
    };
    engine.setNodeWH = function (node) {
        var size = this.getWH();
        var finalW = size.width;
        var finalH = size.height;
        node.width = finalW;
        node.height = finalH;
    };
    engine.getWH = function () {
        var dr = this.getDesignSize();
        // console.log(' dr ', dr)
        var s = this.getFrameSize();
        // console.log(' s ', s)
        var rw = s.width;
        var rh = s.height;
        var finalW = rw;
        var finalH = rh;
        if (this.frameAspectRatio() > this.designAspectRatio()) {
            //!#zh: 是否优先将设计分辨率高度撑满视图高度。 */
            //cvs.fitHeight = true;
            //如果更长，则用定高
            finalH = dr.height;
            finalW = finalH * rw / rh;
        }
        else {
            /*!#zh: 是否优先将设计分辨率宽度撑满视图宽度。 */
            //cvs.fitWidth = true;
            //如果更短，则用定宽
            finalW = dr.width;
            finalH = rh / rw * finalW;
        }
        return cc.size(finalW, finalH);
    };
    engine.resizeUI = function (config) {
        var size = this.getWH();
        // let dr = this.getDesignSize();
        // // console.log(' dr ', dr)
        // var s = this.getFrameSize()
        // // console.log(' s ', s)
        // var rw = s.width;
        // var rh = s.height;
        var finalW = size.width;
        var finalH = size.height;
        cc.view.setDesignResolutionSize(finalW, finalH, cc.ResolutionPolicy.UNKNOWN);
        var cvs = cc.Canvas.instance;
        cvs.node.width = finalW;
        cvs.node.height = finalH;
        // this.setNodeWH(cvs.node)
    };
    Object.defineProperty(engine, "clientScaleX", {
        get: function () {
            return 1;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(engine, "clientScaleY", {
        get: function () {
            return 1;
        },
        enumerable: false,
        configurable: true
    });
    engine.audioEngine = new AudioEngine();
    engine.localStorage = new LocalStorage();
    return engine;
}());
exports.engine = engine;

cc._RF.pop();