"use strict";
cc._RF.push(module, '05652gQyMZE87rss7AI/dCe', 'FoodItemModel');
// Script/logic/game/model/FoodItemModel.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FoodItemModelEnum = void 0;
var cfw_1 = require("../../../cfw/cfw");
var FoodMgr_1 = require("./FoodMgr");
var ModuleConfig_1 = require("../../../config/ModuleConfig");
var model_1 = require("../../../cfw/model");
var event_1 = require("../../../cfw/event");
var Config_1 = require("../../../config/Config");
var MarketMgr_1 = require("../../market/model/MarketMgr");
var FoodItemModelEnum;
(function (FoodItemModelEnum) {
    FoodItemModelEnum[FoodItemModelEnum["name"] = 0] = "name";
    FoodItemModelEnum[FoodItemModelEnum["rare"] = 1] = "rare";
    FoodItemModelEnum[FoodItemModelEnum["ftype"] = 2] = "ftype";
    FoodItemModelEnum[FoodItemModelEnum["state"] = 3] = "state";
    FoodItemModelEnum[FoodItemModelEnum["icon"] = 4] = "icon";
    FoodItemModelEnum[FoodItemModelEnum["nextID"] = 5] = "nextID";
    FoodItemModelEnum[FoodItemModelEnum["scale"] = 6] = "scale";
    FoodItemModelEnum[FoodItemModelEnum["price"] = 7] = "price";
    FoodItemModelEnum[FoodItemModelEnum["outType"] = 8] = "outType";
    FoodItemModelEnum[FoodItemModelEnum["output"] = 9] = "output";
    FoodItemModelEnum[FoodItemModelEnum["outCount"] = 10] = "outCount";
    FoodItemModelEnum[FoodItemModelEnum["time"] = 11] = "time";
    FoodItemModelEnum[FoodItemModelEnum["openPrice"] = 12] = "openPrice";
    FoodItemModelEnum[FoodItemModelEnum["splitRandom"] = 13] = "splitRandom";
    FoodItemModelEnum[FoodItemModelEnum["level"] = 14] = "level";
    FoodItemModelEnum[FoodItemModelEnum["sellPrice"] = 15] = "sellPrice";
    FoodItemModelEnum[FoodItemModelEnum["marketPrice"] = 16] = "marketPrice";
})(FoodItemModelEnum = exports.FoodItemModelEnum || (exports.FoodItemModelEnum = {}));
/**
* 食物表
**/
var FoodItemModel = /** @class */ (function (_super) {
    __extends(FoodItemModel, _super);
    function FoodItemModel() {
        return _super.call(this, FoodItemModel.CLASS_NAME) || this;
    }
    // init(id, data) {
    // 	super.init(id, data)
    // 	let time = this.getTime();
    // 	// console.log(' time =========== ', time, ' this.isTimeFraze() ',this.isTimeFraze())
    // 	if (time <= 0) {
    // 		if (this.isTimeFraze())
    // 			this.setOutCount(this.getCfgValue(FoodItemModelEnum.outCount))
    // 	}
    // }
    FoodItemModel.prototype.getSplitRandom = function () {
        return this.getValue(FoodItemModelEnum.splitRandom);
    };
    FoodItemModel.prototype.getRare = function () {
        return this.getValue(FoodItemModelEnum.rare);
    };
    FoodItemModel.prototype.getSellPrice = function () {
        return this.getValue(FoodItemModelEnum.sellPrice);
    };
    // 名称
    FoodItemModel.prototype.getName = function () {
        var langID = this.getValue(FoodItemModelEnum.name);
        return langID;
    };
    // 类型
    FoodItemModel.prototype.getFType = function () {
        return this.getValue(FoodItemModelEnum.ftype);
    };
    // 图标
    FoodItemModel.prototype.getIcon = function () {
        return 'texture/props';
    };
    FoodItemModel.prototype.getSpriteFrame = function () {
        return this.getValue(FoodItemModelEnum.icon);
    };
    // 缩放
    FoodItemModel.prototype.getScale = function () {
        return this.getValue(FoodItemModelEnum.scale);
    };
    // 价格
    FoodItemModel.prototype.getPrice = function () {
        return this.getValue(FoodItemModelEnum.price);
    };
    // 音效
    // getSound() {
    // 	return this.getValue(FoodItemModelEnum.sound)
    // }
    // 产出
    FoodItemModel.prototype.getOutput = function () {
        return this.getValue(FoodItemModelEnum.output);
    };
    // 产出个数
    FoodItemModel.prototype.getOutCount = function () {
        return this.getValue(FoodItemModelEnum.outCount);
    };
    FoodItemModel.prototype.setOutCount = function (c) {
        this.setValue(FoodItemModelEnum.outCount, c);
        if (c == 0) {
            this.setCDTime();
        }
    };
    FoodItemModel.prototype.getMarketPrice = function () {
        return this.getValue(FoodItemModelEnum.marketPrice);
    };
    FoodItemModel.prototype.getFoodState = function () {
        return this.getValue(FoodItemModelEnum.state);
    };
    FoodItemModel.prototype.setFoodState = function (s) {
        this.setValue(FoodItemModelEnum.state, s);
    };
    FoodItemModel.prototype.getBeBornInitID = function () {
        var type = FoodMgr_1.default.instance().getFoodTypeModel(this.getFType());
        if (type) {
            return type.getBeBornInitID();
        }
        return 0;
    };
    FoodItemModel.prototype.updateFoodState = function () {
        if (this.getFoodState() == model_1.ItemState.NOT_GET) {
            this.setFoodState(model_1.ItemState.GOT);
            event_1.GEvent.instance().emit(Config_1.EventName.CHANGE_FOOD_STATE);
        }
    };
    FoodItemModel.prototype.getNum = function () {
        if (this.num == 0) {
            this.num = 1;
        }
        return _super.prototype.getNum.call(this);
    };
    // getKey() {
    // 	let value = this.getValue(FoodItemModelEnum.marketPrice)
    // 	if (!value) {
    // 		value = Date.now() + this.getID();
    // 		this.setKey(value)
    // 	}
    // 	return value
    // }
    // setKey(k: string) {
    // 	this.setValue(FoodItemModelEnum.marketPrice, k)
    // }
    // cd时间
    FoodItemModel.prototype.getTime = function () {
        return this.getValue(FoodItemModelEnum.time);
    };
    FoodItemModel.prototype.setTime = function (t) {
        this.setValue(FoodItemModelEnum.time, t);
    };
    // 解锁价格
    FoodItemModel.prototype.getOpenPrice = function () {
        return this.getValue(FoodItemModelEnum.openPrice);
    };
    FoodItemModel.prototype.hasNext = function () {
        // console.log(' this.model.getNextID() ',this.model.getNextID())
        return this.getNextID() > 0;
    };
    FoodItemModel.prototype.isMaxLevel = function () {
        return !this.hasNext();
    };
    FoodItemModel.prototype.setCDTime = function () {
        this.setTime(this.getCfgValue(FoodItemModelEnum.time));
    };
    FoodItemModel.prototype.clearCDTime = function () {
        this.setOutCount(this.getCfgValue(FoodItemModelEnum.outCount));
        this.setTime(0);
    };
    FoodItemModel.prototype.canOutput = function () {
        var out = this.getOutput();
        return out && out.length > 0;
    };
    // canDelete() {
    // 	let out: number[] = this.getOutput();
    // 	return out.length <= 0
    // }
    // isTimeFraze() {
    // 	if (this.canOutput() && this.getOutCount() == 0) {
    // 		return true;
    // 	} else {
    // 		return false;
    // 	}
    // }
    FoodItemModel.prototype.canSell = function () {
        return this.getSellPrice() > 0;
    };
    FoodItemModel.prototype.getNextModel = function () {
        var nextID = parseInt(this.getID()) + 1;
        var nextModel = FoodMgr_1.default.instance().getNewFoodItemModel(nextID);
        if (!nextModel) {
            return null;
        }
        if (nextModel.getFType() == this.getFType()) {
            return nextModel;
        }
        return null;
    };
    FoodItemModel.prototype.getLevel = function () {
        return this.getValue(FoodItemModelEnum.level);
    };
    FoodItemModel.prototype.getModuleID = function () {
        return ModuleConfig_1.ModuleID.GAME;
    };
    FoodItemModel.prototype.getNextID = function () {
        return this.getValue(FoodItemModelEnum.nextID);
    };
    FoodItemModel.prototype.getOutType = function () {
        return this.getValue(FoodItemModelEnum.outType);
    };
    FoodItemModel.prototype.isCostEnergy = function () {
        var type = FoodMgr_1.default.instance().getFoodTypeModel(this.getFType());
        if (type) {
            return type.isCostEnergy() || this.getID() == 30024;
        }
        return false;
    };
    FoodItemModel.prototype.isInMarket = function () {
        return MarketMgr_1.default.instance().hasFood(this.getID());
    };
    FoodItemModel.CLASS_NAME = 'FoodItemModel';
    return FoodItemModel;
}(cfw_1.DataModel));
exports.default = FoodItemModel;

cc._RF.pop();