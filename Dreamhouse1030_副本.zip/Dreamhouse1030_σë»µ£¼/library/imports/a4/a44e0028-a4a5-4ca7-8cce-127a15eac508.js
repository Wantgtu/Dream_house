"use strict";
cc._RF.push(module, 'a44e0AopKVMp4zOEnoV6sUI', 'VIvoInsertAd');
// Script/sdk/sdk/vivo/VIvoInsertAd.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseInsertAd_1 = require("../base/BaseInsertAd");
/**
 * https://minigame.vivo.com.cn/documents/#/api/da/interstitial-da
 * 插屏广告实例不能复用，每次需要重新加载时要重新create
 */
var VivoInsertAd = /** @class */ (function (_super) {
    __extends(VivoInsertAd, _super);
    function VivoInsertAd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    VivoInsertAd.prototype.open = function () {
        this.destroy();
        this.create();
        this.show();
    };
    VivoInsertAd.prototype.create = function () {
        console.log(' create insert ad ');
        if (!this.insertAd) {
            this.insertAd = this.sdk.createInterstitialAd({
                posId: this.adUnitID
            });
            this.insertAd.onLoad(this.onLoad.bind(this));
            this.insertAd.onError(this.onError.bind(this));
        }
    };
    return VivoInsertAd;
}(BaseInsertAd_1.default));
exports.default = VivoInsertAd;

cc._RF.pop();