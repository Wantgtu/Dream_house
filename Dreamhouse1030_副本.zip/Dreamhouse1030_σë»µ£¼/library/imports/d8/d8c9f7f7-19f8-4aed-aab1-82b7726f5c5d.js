"use strict";
cc._RF.push(module, 'd8c9ff3GfhK7aqxgrdyb1xd', 'LayerMgr');
// Script/cocos/listview/LayerMgr.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LayerMgr = /** @class */ (function (_super) {
    __extends(LayerMgr, _super);
    function LayerMgr() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.delegate = new cc.Component.EventHandler();
        _this.prefab = null;
        _this.totalCount = 0;
        _this.contents = [];
        return _this;
        // update (dt) {}
    }
    LayerMgr.prototype.start = function () {
        var temp = this.getItem();
        var count = temp.childrenCount;
        for (var index = 0; index < count; index++) {
            var node = new cc.Node();
            var widget = node.addComponent(cc.Widget);
            node.width = this.node.width;
            node.height = this.node.height;
            widget.left = 0;
            widget.right = 0;
            widget.top = 0;
            widget.bottom = 0;
            this.node.addChild(node);
            this.contents[index] = node;
        }
        cc.log(' content count ', this.contents.length);
        this.init();
    };
    LayerMgr.prototype.getItem = function () {
        return cc.instantiate(this.prefab);
    };
    LayerMgr.prototype.init = function () {
        for (var index = 0; index < this.totalCount; index++) {
            var item = this.getItem();
            if (!item) {
                continue;
            }
            this.node.addChild(item);
            var count = item.childrenCount;
            cc.log(' count == ', count);
            if (count > 0) {
                var j = 0;
                var list = item.children;
                while (list.length > 0) {
                    // cc.log(' list.length  11111 ', list.length)
                    var element = list[0];
                    if (element) {
                        element.parent = null;
                        // cc.log(' list.length 2222222 ', list.length)
                        this.contents[j].addChild(element);
                        j++;
                    }
                    else {
                        cc.warn(' element is null ', j);
                        break;
                    }
                }
            }
            else {
            }
            this.delegate.emit([this, index, item]);
        }
    };
    __decorate([
        property({
            type: cc.Component.EventHandler,
            displayName: "内容处理函数"
        })
    ], LayerMgr.prototype, "delegate", void 0);
    __decorate([
        property(cc.Prefab)
    ], LayerMgr.prototype, "prefab", void 0);
    __decorate([
        property
    ], LayerMgr.prototype, "totalCount", void 0);
    LayerMgr = __decorate([
        ccclass
    ], LayerMgr);
    return LayerMgr;
}(cc.Component));
exports.default = LayerMgr;

cc._RF.pop();