"use strict";
cc._RF.push(module, 'd8f26L6zChOAr+FgKO4PMzb', 'BuyPerson');
// Script/logic/buy/model/BuyPerson.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var local_1 = require("../../../cfw/local");
var model_1 = require("../../../cfw/model");
var BagManager_1 = require("../../public/bag/BagManager");
var PersonMgr_1 = require("../../person/model/PersonMgr");
var BuyMgr_1 = require("./BuyMgr");
var Config_1 = require("../../../config/Config");
var event_1 = require("../../../cfw/event");
var FoodMediator_1 = require("../../public/mediator/FoodMediator");
var PersonID = 'PersonID';
var Items = 'Items';
var ItemID = 'ItemID';
var State = 'State';
var ItemNum = 'ItemNum';
var BuyPerson = /** @class */ (function (_super) {
    __extends(BuyPerson, _super);
    function BuyPerson(id) {
        var _this = _super.call(this) || this;
        _this.id = 0;
        _this.items = [];
        _this.delete = 0;
        _this.setID(id);
        _this.data = new local_1.LocalMap('BuyPerson' + id, 0);
        return _this;
    }
    BuyPerson.prototype.hasData = function () {
        return this.data.isHaveData();
    };
    // getID() {
    //     return this.id;
    // }
    BuyPerson.prototype.setPersonID = function (id) {
        this.data.set(PersonID, id);
    };
    BuyPerson.prototype.setDelete = function (id) {
        this.delete = id;
    };
    BuyPerson.prototype.getDelete = function () {
        return this.delete;
    };
    BuyPerson.prototype.getItems = function () {
        return this.data.get(Items);
    };
    BuyPerson.prototype.setItems = function (list) {
        this.data.set(Items, list);
    };
    BuyPerson.prototype.getPersonID = function () {
        return this.data.get(PersonID);
    };
    BuyPerson.prototype.setItemID = function (id) {
        this.data.set(ItemID, id);
    };
    BuyPerson.prototype.setItemNum = function (num) {
        this.data.set(ItemNum, num);
    };
    BuyPerson.prototype.getItemNum = function () {
        // console.error()
        return this.data.get(ItemNum);
    };
    BuyPerson.prototype.getPerson = function () {
        return PersonMgr_1.default.instance().getPersonItemModel(this.getPersonID());
    };
    BuyPerson.prototype.getItemList = function () {
        if (this.items.length == 0) {
            var list = this.getItems();
            for (var index = 0; index < list.length; index++) {
                var element = list[index];
                var item = BagManager_1.default.instance().getNewItemModel(element, 1);
                this.items.push(item);
            }
            FoodMediator_1.default.instance().checkBuyItem(this.items);
        }
        return this.items;
    };
    BuyPerson.prototype.getItemID = function () {
        return this.data.get(ItemID);
    };
    BuyPerson.prototype.getRewardItem = function () {
        var id = this.getItemID();
        var num = this.getItemNum();
        if (!this.rewardItem) {
            this.rewardItem = BagManager_1.default.instance().getNewItemModel(id, num);
        }
        return this.rewardItem;
    };
    BuyPerson.prototype.removeSelf = function () {
        FoodMediator_1.default.instance().removeBuyItemList(this.items);
        BuyMgr_1.default.instance().remove(this);
        this.data.removeSelf();
        FoodMediator_1.default.instance().checkBuyItemList();
    };
    BuyPerson.prototype.getState = function () {
        return this.data.get(State);
    };
    BuyPerson.prototype.setState = function (s) {
        this.data.set(State, s);
        if (s == model_1.ItemState.CAN_GET) {
            // console.log(' BUY_ITEM_FULL ')
            event_1.GEvent.instance().emit(Config_1.EventName.BUY_ITEM_FULL, this.getID());
        }
    };
    return BuyPerson;
}(model_1.BaseItemModel));
exports.default = BuyPerson;

cc._RF.pop();