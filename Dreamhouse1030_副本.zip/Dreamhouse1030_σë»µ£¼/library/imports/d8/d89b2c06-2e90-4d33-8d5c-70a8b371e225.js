"use strict";
cc._RF.push(module, 'd89b2wGLpBNM41ccKizceIl', 'TipView');
// Script/logic/public/tip/view/TipView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../../cfw/view");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var TipView = /** @class */ (function (_super) {
    __extends(TipView, _super);
    function TipView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.back$VButton = null;
        _this.conform$VButton = null;
        _this.content$VLabel = null;
        _this.adSprite = null;
        _this.moneySprite = null;
        return _this;
    }
    TipView.prototype.onEnter = function () {
        this.content$VLabel.string = this.model.text;
        // this.registerButtonByNode(this.conform$VButton, this.onconform$VButtonClick)
        // this.registerButtonByNode(this.back$VButton, this.onback$VButtonClick)
        if (this.model.rightStr && this.conform$VButton) {
            this.conform$VButton.string = this.model.rightStr;
        }
        if (this.model.leftStr && this.back$VButton) {
            this.back$VButton.string = this.model.leftStr;
        }
        this.adSprite.node.active = this.model.isShowAd;
        this.moneySprite.node.active = this.model.isShowAd;
    };
    TipView.prototype.onback$VButtonClick = function () {
        this.hide();
        this.model.callback(0);
    };
    TipView.prototype.onconform$VButtonClick = function () {
        this.hide();
        this.model.callback(1);
    };
    __decorate([
        property(cc.Label)
    ], TipView.prototype, "back$VButton", void 0);
    __decorate([
        property(cc.Label)
    ], TipView.prototype, "conform$VButton", void 0);
    __decorate([
        property(cc.Label)
    ], TipView.prototype, "content$VLabel", void 0);
    __decorate([
        property(cc.Sprite)
    ], TipView.prototype, "adSprite", void 0);
    __decorate([
        property(cc.Sprite)
    ], TipView.prototype, "moneySprite", void 0);
    TipView = __decorate([
        ccclass
    ], TipView);
    return TipView;
}(view_1.BaseView));
exports.default = TipView;

cc._RF.pop();