"use strict";
cc._RF.push(module, '943ec5RNJVIcJ5Lgxcx9C7y', 'ModuleConfig');
// Script/config/ModuleConfig.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModuleConfig = exports.ModuleID = void 0;
//模块id
var ModuleID = /** @class */ (function () {
    function ModuleID() {
    }
    ModuleID.RES = 'res'; //resource 首包资源
    ModuleID.PUBLIC = 'public'; //公共模块
    ModuleID.LOGIN = 'login'; //登陆模块
    ModuleID.GAME = 'game';
    ModuleID.LOBBY = 'lobby'; //大厅模块
    // static PET = 'cat'//宠物模块
    ModuleID.AUDIO = 'audio';
    ModuleID.LOADING = 'loading';
    ModuleID.START = 'start';
    ModuleID.BUILD1 = 'build1';
    ModuleID.BUILD2 = 'build2';
    ModuleID.BUILD3 = 'build3';
    ModuleID.BUILD4 = 'build4';
    ModuleID.BUILD5 = 'build5';
    ModuleID.BUILD6 = 'build6';
    ModuleID.nativeAd = 'nativeAd';
    ModuleID.CRAZY_CLICK = 'crazyClick';
    ModuleID.install = 'install';
    return ModuleID;
}());
exports.ModuleID = ModuleID;
//有分包的模块就有bundle的名字，没有就是使用cc.resource 
exports.ModuleConfig = [
    { name: ModuleID.RES, isBundle: false, bundleName: '' },
    //public
    { name: ModuleID.PUBLIC, isBundle: true, bundleName: ModuleID.PUBLIC },
    //login
    { name: ModuleID.LOGIN, isBundle: false, bundleName: '' },
    //lobby
    { name: ModuleID.LOBBY, isBundle: false, bundleName: '' },
    // { name: ModuleID.PET, isBundle: false, bundleName: 'cat' },
    { name: ModuleID.GAME, isBundle: true, bundleName: ModuleID.GAME },
    { name: ModuleID.AUDIO, isBundle: true, bundleName: ModuleID.AUDIO },
    { name: ModuleID.LOADING, isBundle: false, bundleName: '' },
    { name: ModuleID.BUILD1, isBundle: true, bundleName: ModuleID.BUILD1 },
    { name: ModuleID.BUILD2, isBundle: true, bundleName: ModuleID.BUILD2 },
    { name: ModuleID.BUILD3, isBundle: true, bundleName: ModuleID.BUILD3 },
    { name: ModuleID.BUILD4, isBundle: true, bundleName: ModuleID.BUILD4 },
    { name: ModuleID.BUILD5, isBundle: true, bundleName: ModuleID.BUILD5 },
    { name: ModuleID.BUILD6, isBundle: true, bundleName: ModuleID.BUILD6 },
    { name: ModuleID.START, isBundle: true, bundleName: ModuleID.START },
    { name: ModuleID.nativeAd, isBundle: true, bundleName: ModuleID.nativeAd },
    { name: ModuleID.CRAZY_CLICK, isBundle: true, bundleName: ModuleID.CRAZY_CLICK },
    { name: ModuleID.install, isBundle: true, bundleName: ModuleID.install },
];

cc._RF.pop();