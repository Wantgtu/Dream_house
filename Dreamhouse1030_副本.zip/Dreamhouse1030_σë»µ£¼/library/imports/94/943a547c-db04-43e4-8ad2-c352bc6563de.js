"use strict";
cc._RF.push(module, '943a5R82wRD5IrSw1K8ZWPe', 'CrazyClickC');
// Script/logic/crazyClick/CrazyClickC.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SPECIAL_COUNT = void 0;
var mvc_1 = require("../../cfw/mvc");
var SDKManager_1 = require("../../sdk/sdk/SDKManager");
var module_1 = require("../../cfw/module");
var ModuleConfig_1 = require("../../config/ModuleConfig");
var ViewManager_1 = require("../../cfw/tools/ViewManager");
var UIConfig_1 = require("../../config/UIConfig");
var local_1 = require("../../cfw/local");
var User_1 = require("../user/User");
var Config_1 = require("../../config/Config");
var LevelMgr_1 = require("../level/model/LevelMgr");
var event_1 = require("../../cfw/event");
var RedTipMgr_1 = require("../../extention/redtip/RedTipMgr");
var FoodMgr_1 = require("../game/model/FoodMgr");
var BagManager_1 = require("../public/bag/BagManager");
var ItemC_1 = require("../item/ItemC");
var CMgr_1 = require("../../sdk/channel-ts/CMgr");
// import BaseController from "../../cfw/mvc/BaseController";
// import ModuleManager, { ModuleID } from "../../cfw/module/ModuleManager";
// import SDKManager from "../../sdk/SDKManager";
// import LoadingController from "../loading/LoadingController";
// import LobbyController from "../lobby/LobbyController";
// import UIManager from "../../cfw/ui/UIManager";
exports.SPECIAL_COUNT = 10;
var CrazyClickC = /** @class */ (function (_super) {
    __extends(CrazyClickC, _super);
    function CrazyClickC() {
        var _this = _super.call(this) || this;
        _this.count = new local_1.LocalValue('CrazyClickCMgrcount', 0);
        _this.dayNum = new local_1.LocalValue('CrazyClickCMgrdayNum', 0);
        if (_this.dayNum.getInt() != User_1.default.instance().getLoginDayNum()) {
            _this.count.setValue(0);
            _this.dayNum.setValue(User_1.default.instance().getLoginDayNum());
        }
        _this.costItem = BagManager_1.default.instance().getNewItemModel(Config_1.ItemID.TOKEN, Config_1.FREE_EGG_COUNT);
        event_1.GEvent.instance().on(Config_1.EventName.UPDATE_LEVEL, _this.udpateLevel, _this);
        _this.udpateLevel();
        return _this;
    }
    CrazyClickC.prototype.udpateLevel = function () {
        if (this.isOpen()) {
            RedTipMgr_1.default.instance().addRedTip(Config_1.RedTipType.EGG_OPEN);
        }
    };
    CrazyClickC.prototype.isOpen = function () {
        return LevelMgr_1.default.instance().getLevel() >= Config_1.EGG_OPEN_LEVEL;
    };
    CrazyClickC.prototype.getTip = function () {
        return Config_1.EGG_OPEN_LEVEL + '级之后开启';
    };
    CrazyClickC.prototype.getCount = function () {
        return this.count.getInt();
    };
    CrazyClickC.prototype.updateCount = function () {
        return this.count.updateValue(1);
    };
    // protected witch: number = 0;
    CrazyClickC.prototype.gotoLayer = function (func) {
        var _this = this;
        this.callback = func;
        // this.witch = w;
        var hasSubPackage = SDKManager_1.default.getChannel().hasSubPackage();
        if (hasSubPackage) {
            module_1.ModuleManager.loadBundle(ModuleConfig_1.ModuleID.CRAZY_CLICK, function (r) {
                if (r) {
                    _this.intoLayer();
                }
            });
        }
        else {
            this.intoLayer();
        }
    };
    CrazyClickC.prototype.intoLayer = function () {
        // if (UIManager.instance().hasView('CrazyClickView', UIIndex.STACK)) {
        //     return;
        // }
        ViewManager_1.default.pushUIView({
            path: 'prefabs/CrazyClickView',
            moduleID: ModuleConfig_1.ModuleID.CRAZY_CLICK,
            uiIndex: UIConfig_1.UIIndex.STACK,
            controller: this,
            func: function () {
            }
        });
    };
    CrazyClickC.prototype.next = function () {
        // console.log(' this.witch ', this.witch)
        if (this.callback) {
            this.callback();
            this.callback = null;
        }
        // if (this.witch == 0) {
        //     this.gotoLobby()
        // } else {
        // }
    };
    CrazyClickC.prototype.getResult = function (witch) {
        var count = this.getCount();
        if (count % exports.SPECIAL_COUNT == 0) {
            return FoodMgr_1.default.instance().getItemByRare(5);
        }
        else {
            if (witch == 0) {
                return FoodMgr_1.default.instance().getItemByRareList([1, 2]);
            }
            else {
                return FoodMgr_1.default.instance().getItemByRareList([3, 4]);
            }
        }
    };
    CrazyClickC.prototype.getReward = function (witch) {
        if (witch == 0) {
            if (BagManager_1.default.instance().isItemEnough(this.costItem)) {
                BagManager_1.default.instance().reduceItem(this.costItem);
                event_1.GEvent.instance().emit(CrazyClickC.EGG_RESULT, witch);
            }
            else {
                // ItemC.instance().showBuyEnergyView()
                ItemC_1.default.instance().showBuyTokenView(0);
            }
        }
        else {
            CMgr_1.default.helper.showRewardAd(0, function (r) {
                if (r) {
                    event_1.GEvent.instance().emit(CrazyClickC.EGG_RESULT, witch);
                }
            });
        }
    };
    CrazyClickC.prototype.gotoLobby = function () {
        // UIManager.instance().clear()
        // let hasSubPackage = SDKManager.getChannel().hasSubPackage()
        // if (hasSubPackage) {
        //     LoadingController.instance().intoLayer(ModuleID.LOBBY, [ModuleID.LOBBY, ModuleID.DECORATION, ModuleID.SMALL_GAME])
        // } else {
        //     LobbyController.instance().intoLayer()
        // }
    };
    CrazyClickC.EGG_RESULT = 'EGG_RESULT';
    // private static ins: CrazyClickC;
    // static instance() {
    //     if (!this.ins) {
    //         this.ins = new CrazyClickC()
    //     }
    //     return this.ins;
    // }
    CrazyClickC.step = 0;
    return CrazyClickC;
}(mvc_1.BaseController));
exports.default = CrazyClickC;

cc._RF.pop();