"use strict";
cc._RF.push(module, '94b72AihfpAzJbumnHOtesj', 'GiftBoxView');
// Script/logic/giftbox/view/GiftBoxView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var view_1 = require("../../../cfw/view");
var CMgr_1 = require("../../../sdk/channel-ts/CMgr");
var Utils_1 = require("../../../cfw/tools/Utils");
var GameEventAdapter_1 = require("../../../extention/gevent/GameEventAdapter");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GiftBoxView = /** @class */ (function (_super) {
    __extends(GiftBoxView, _super);
    // 更多参数说明请访问: https://ldc2.layabox.com/doc/?nav=zh-as-2-4-0
    function GiftBoxView() {
        var _this = _super.call(this) || this;
        _this.giftBox = null;
        _this.time = 0;
        return _this;
    }
    GiftBoxView.prototype.onEnable = function () {
    };
    GiftBoxView.prototype.onDisable = function () {
    };
    GiftBoxView.prototype.onEnter = function () {
        this.giftBox.active = false;
        // this.registerButtonByNode(this.giftBox, this.onMouseDown2222)
        var flag = CMgr_1.default.helper.isSwtichOpen();
        if (flag) {
            this.startShedule();
        }
    };
    GiftBoxView.prototype.onButtonClick = function () {
        var flag = CMgr_1.default.helper.isSwtichOpen();
        if (!flag) {
            return;
        }
        this.giftBox.active = false;
        if (this.controller) {
            var pos = this.giftBox.parent.convertToWorldSpaceAR(this.giftBox.getPosition());
            this.controller.giftClick(pos);
        }
    };
    GiftBoxView.prototype.startShedule = function () {
        var _this = this;
        var time = CMgr_1.default.helper.getzs_video_box();
        // console.warn('GiftBoxView startShedule time ', time)
        if (time > 0) {
            cc.tween(this.node).delay(time).call(function () {
                _this.endShedule();
            })
                .start();
            // Laya.Tween.to(this, {}, time * 1000, null, Laya.Handler.create(this, this.endShedule))
        }
    };
    GiftBoxView.prototype.endShedule = function () {
        this.loadAd();
        this.startShedule();
    };
    GiftBoxView.prototype.loadAd = function () {
        // console.log('this.giftBox.active', this.giftBox.active, GameEventAdapter.instance().isOpen())
        if (GameEventAdapter_1.default.instance().isOpen()) {
            return;
        }
        if (!this.giftBox.active) {
            var size = cc.view.getVisibleSize();
            var left = this.giftBox.width / 2;
            var right = size.width - left;
            var x = Utils_1.default.random(left, right);
            this.giftBox.x = x;
            this.giftBox.y = this.giftBox.height / 2;
            this.giftBox.active = true;
        }
        // this.giftBox.active = true;
    };
    GiftBoxView.prototype.updateLogic = function () {
        var flag = CMgr_1.default.helper.isSwtichOpen();
        if (!flag) {
            return;
        }
        if (!this.giftBox.active) {
            return;
        }
        var size = cc.view.getVisibleSize();
        var dt = 16;
        // this.time += dt;
        // if (this.time >= 50) {
        // this.time = 0;
        var speed = dt * 0.08;
        this.giftBox.y -= speed;
        if (this.giftBox.y < -(size.height + this.giftBox.height / 2)) {
            this.giftBox.active = false;
            // this.loadAd()
        }
        // }
    };
    __decorate([
        property(cc.Node)
    ], GiftBoxView.prototype, "giftBox", void 0);
    GiftBoxView = __decorate([
        ccclass
    ], GiftBoxView);
    return GiftBoxView;
}(view_1.BaseView));
exports.default = GiftBoxView;

cc._RF.pop();