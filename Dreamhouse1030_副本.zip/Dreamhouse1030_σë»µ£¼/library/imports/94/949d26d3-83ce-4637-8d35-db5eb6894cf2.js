"use strict";
cc._RF.push(module, '949d2bTg85GN4012162iUzy', 'DevHelper');
// Script/sdk/channel-ts/DevHelper.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseHelper_1 = require("./BaseHelper");
var SDKEvent_1 = require("../sdk/tools/SDKEvent");
var Debug_1 = require("../../cfw/tools/Debug");
var SDKManager_1 = require("../sdk/SDKManager");
var DevHelper = /** @class */ (function (_super) {
    __extends(DevHelper, _super);
    function DevHelper() {
        var _this = _super.call(this) || this;
        SDKEvent_1.default.instance().on(SDKEvent_1.default.REWARD_AD_CLOSE, _this.rewardClose, _this);
        SDKEvent_1.default.instance().on(SDKEvent_1.default.REWARD_AD_OPEN, _this.rewardOpen, _this);
        Debug_1.default.isDebug = false;
        return _this;
    }
    DevHelper.prototype.rewardOpen = function () {
        // AudioMgr.instance().stopMusic()
    };
    DevHelper.prototype.rewardClose = function () {
        // AudioMgr.instance().playMusic(SoundID.LKT_Gameplay_Soundtrack)
    };
    DevHelper.prototype.hasAgreement = function () {
        return true;
    };
    DevHelper.prototype.hasLight = function () {
        return true;
    };
    DevHelper.prototype.isSwtichOpen = function () {
        return false;
    };
    DevHelper.prototype.getzs_video_box = function () {
        return 5;
    };
    DevHelper.prototype.getzs_box_switch = function () {
        return false;
    };
    DevHelper.prototype.getzs_box_show_delay = function () {
        return 1000;
    };
    DevHelper.prototype.isVersion = function () {
        return false;
    };
    DevHelper.prototype.hasInstallApp = function () {
        return false;
    };
    DevHelper.prototype.getzs_native_show_delay = function () {
        return 1000;
    };
    DevHelper.prototype.marketHasType = function (type) {
        if (type == 4) {
            return SDKManager_1.default.getChannel().hasShare();
        }
        // if (type == 2 || type == 3) {
        //     return false
        // }
        return true;
    };
    DevHelper.prototype.canMultyAd = function () {
        return true;
    };
    return DevHelper;
}(BaseHelper_1.default));
exports.default = DevHelper;

cc._RF.pop();