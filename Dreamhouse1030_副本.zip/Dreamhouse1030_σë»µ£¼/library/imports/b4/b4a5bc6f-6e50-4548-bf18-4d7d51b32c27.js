"use strict";
cc._RF.push(module, 'b4a5bxvblBFSL8YTX1Rsywn', 'ButtonDuration');
// Script/cfw/widget/ButtonDuration.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ButtonDuration = /** @class */ (function () {
    function ButtonDuration() {
        this.flag = false;
    }
    ButtonDuration.prototype.canClick = function () {
        var _this = this;
        if (this.flag) {
            return false;
        }
        this.flag = true;
        setTimeout(function () {
            _this.flag = false;
        }, 500);
        return true;
    };
    return ButtonDuration;
}());
exports.default = ButtonDuration;

cc._RF.pop();