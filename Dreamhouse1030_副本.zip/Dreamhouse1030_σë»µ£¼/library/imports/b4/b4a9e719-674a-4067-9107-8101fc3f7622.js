"use strict";
cc._RF.push(module, 'b4a9ecZZ0pAZ5EHgQH8P3Yi', 'G4399Share');
// Script/sdk/sdk/4399/G4399Share.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseShare_1 = require("../../sdk/base/BaseShare");
var SDKConfig_1 = require("../SDKConfig");
var G4399Share = /** @class */ (function (_super) {
    __extends(G4399Share, _super);
    function G4399Share() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    G4399Share.prototype.share = function (site, func) {
        this.callback = func;
        if (this.sdk) {
            this.sdk.share();
        }
        this.callback(SDKConfig_1.ResultState.YES);
    };
    return G4399Share;
}(BaseShare_1.BaseShare));
exports.default = G4399Share;

cc._RF.pop();