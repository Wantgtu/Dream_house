"use strict";
cc._RF.push(module, 'd6043MsSxhOsoMfzWMPB/Ez', 'OVNativeAdC');
// Script/sdk/nativeAd/OVNativeAdC.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var SDKManager_1 = require("../sdk/SDKManager");
var CMgr_1 = require("../channel-ts/CMgr");
var mvc_1 = require("../../cfw/mvc");
var ui_1 = require("../../cfw/ui");
var UIConfig_1 = require("../../config/UIConfig");
var ModuleConfig_1 = require("../../config/ModuleConfig");
var ViewManager_1 = require("../../cfw/tools/ViewManager");
var OVNativeAdC = /** @class */ (function (_super) {
    __extends(OVNativeAdC, _super);
    function OVNativeAdC() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // protected static hideBannerCount: number = 0;
    // static isBannerState() {
    //     return this.hideBannerCount <= 0
    // }
    // static setBannerState(f: boolean) {
    //     if (!f) {
    //         this.hideBannerCount++;
    //         GEvent.instance().emit(OVNativeAdC.OPEN_NATIVE_AD)
    //     } else {
    //         this.hideBannerCount--;
    //         if (this.hideBannerCount <= 0) {
    //             this.hideBannerCount = 0;
    //             GEvent.instance().emit(OVNativeAdC.CLOSE_NATIVE_AD)
    //         }
    //     }
    // }
    OVNativeAdC.prototype.intoLayer = function (isLimit) {
        if (isLimit === void 0) { isLimit = false; }
        if (isLimit) {
            if (!CMgr_1.default.helper.hasNativeLimit()) {
                console.log(' CMgr.helper.hasNativeLimit() ', CMgr_1.default.helper.hasNativeLimit());
                return;
            }
        }
        if (!SDKManager_1.default.getChannel().hasNativeAd()) {
            console.log('OVNativeAdC 没有广告  ');
            return;
        }
        // let flag = UIManager.instance().hasView('NativeAdView', UIIndex.AD_LAYER)
        // if (flag) {
        //     console.log('OVNativeAdC intoLayer  ', flag)
        //     return;
        // }
        if (!CMgr_1.default.helper.isVersion()) {
            return;
        }
        ViewManager_1.default.pushUIView({
            path: 'prefabs/NativeAdView',
            uiIndex: UIConfig_1.UIIndex.AD_LAYER,
            moduleID: ModuleConfig_1.ModuleID.nativeAd,
            model: null,
            controller: this,
        });
        // this.pushView('prefabs/NativeAdView', null, ModuleManager.getLoader(ModuleID.nativeAd), UIIndex.AD_LAYER)
    };
    OVNativeAdC.prototype.showBanner = function () {
        if (!SDKManager_1.default.getChannel().hasNativeAd()) {
            console.log('OVNativeAdC showBanner 没有广告  ');
            return;
        }
        if (!CMgr_1.default.helper.isVersion()) {
            return;
        }
        // let flag = UIManager.instance().hasView('NativeBannerAdView', UIIndex.AD_LAYER)
        // if (flag) {
        //     console.log('OVNativeAdC intoLayer  ', flag)
        //     return;
        // }
        ViewManager_1.default.pushUIView({
            path: 'prefabs/NativeBannerAdView',
            uiIndex: UIConfig_1.UIIndex.AD_LAYER,
            moduleID: ModuleConfig_1.ModuleID.nativeAd,
            model: null,
            controller: this,
        });
        // this.pushView('prefabs/NativeBannerAdView', null, ModuleManager.getLoader(ModuleID.nativeAd), UIIndex.AD_LAYER)
    };
    OVNativeAdC.prototype.hideBanner = function () {
        if (!CMgr_1.default.helper.isVersion()) {
            return;
        }
        if (!SDKManager_1.default.getChannel().hasNativeAd()) {
            console.log('OVNativeAdC showBanner 没有广告  ');
            return;
        }
        ui_1.default.instance().removeView('NativeBannerAdView', UIConfig_1.UIIndex.AD_LAYER);
    };
    // static CLOSE_NATIVE: string = 'CLOSE_NATIVE'
    // static OPEN_NATIVE_AD: string = 'OPEN_NATIVE_AD'
    // static CLOSE_NATIVE_AD: string = 'CLOSE_NATIVE_AD'
    OVNativeAdC.FORCE_CLOSE = false;
    return OVNativeAdC;
}(mvc_1.BaseController));
exports.default = OVNativeAdC;

cc._RF.pop();