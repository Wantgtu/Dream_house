"use strict";
cc._RF.push(module, '593efFKaGJE45Bg4ttyphTQ', 'BuyMgr');
// Script/logic/buy/model/BuyMgr.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var model_1 = require("../../../cfw/model");
var module_1 = require("../../../cfw/module");
var BuyItemModel_1 = require("./BuyItemModel");
var local_1 = require("../../../cfw/local");
var Config_1 = require("../../../config/Config");
var LevelMgr_1 = require("../../level/model/LevelMgr");
var event_1 = require("../../../cfw/event");
var Utils_1 = require("../../../cfw/tools/Utils");
var FoodMgr_1 = require("../../game/model/FoodMgr");
var BuyPerson_1 = require("./BuyPerson");
var TestConfig_1 = require("../../../config/TestConfig");
var Debug_1 = require("../../../cfw/tools/Debug");
var countRandom = [1, 50, 2, 40, 3, 10];
var BUY_PERSON = [1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 16];
/**
* %SheetName%
**/
var BuyMgr = /** @class */ (function (_super) {
    __extends(BuyMgr, _super);
    function BuyMgr() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.buyItemModelMgr = new model_1.ModelManager();
        _this.buyItemList = [];
        return _this;
        // updateItemsState() {
        // 	// console.log(' this.buyItemList.length ', this.buyItemList.length)
        // 	for (let index = 0; index < this.buyItemList.length; index++) {
        // 		const element = this.buyItemList[index];
        // 		element.updateState()
        // 	}
        // }
    }
    BuyMgr.prototype.initData = function () {
        this.buyList = new local_1.LocalList('BuyList', 0);
        this.personIndex = new local_1.LocalValue('personIndex', 1);
        this.buyItemModelMgr.initWithData(module_1.ModuleManager.dataManager.get(BuyItemModel_1.default.CLASS_NAME), BuyItemModel_1.default);
        if (!this.buyList.isHaveData()) {
            this.buyList.push(1);
            this.personIndex.updateValue(1);
        }
        // let value = this.buyList.getValue();
        for (var index = 0; index < this.buyList.size(); index++) {
            var id = this.buyList.get(index);
            this.buyItemList.push(this.getNewBuyPerson(id));
        }
        // this.updateItemsState()
        //test
        if (TestConfig_1.default.CAT_TEST) {
            cc.warn(' init 111');
            this.buyItemList.push(this.addBuyPerson(32));
            cc.warn(' init 22');
        }
        if (TestConfig_1.default.BUY_TEST) {
            var list = this.getBuyItemModelList();
            for (var index = 0; index < list.length; index++) {
                var element = list[index];
                var foods = element.getItemList();
                // Debug.log('foods count ', foods.length)
                for (var i = 0; i < foods.length; i++) {
                    var food = foods[i];
                    // Debug.log(' food.getType() ', food.getType(), food.getID())
                    if (food.getType() != Config_1.ItemType.FOOD) {
                        Debug_1.default.warn(' food id ', food.getID(), element.getID());
                    }
                }
            }
        }
    };
    BuyMgr.prototype.getBuyPerson = function (id) {
        for (var index = 0; index < this.buyItemList.length; index++) {
            var element = this.buyItemList[index];
            if (element.getID() == id) {
                return element;
            }
        }
        return null;
    };
    BuyMgr.prototype.hasPerson = function (perID) {
        for (var index = 0; index < this.buyItemList.length; index++) {
            var element = this.buyItemList[index];
            if (element.getPersonID() == perID) {
                return true;
            }
        }
        return false;
    };
    BuyMgr.prototype.hasSameItem = function (buy) {
        var list = this.buyItemList;
        for (var index = 0; index < list.length; index++) {
            var buyPerson = list[index];
            var items = buy.getItems();
            var buyItems = buyPerson.getItems();
            // if (items.length == buyItems.length) {
            var count = 0;
            for (var i = 0; i < items.length; i++) {
                var itemID = items[i];
                var j = buyItems.indexOf(itemID);
                if (j >= 0) {
                    count++;
                }
            }
            // console.log(' count ', count, ' item count ', items.length)
            if (count >= items.length) {
                return true;
            }
            // }
        }
        return false;
    };
    BuyMgr.prototype.getUnUsePersonID = function () {
        var temp = [];
        // let list = PersonMgr.instance().getPersonItemModelList();
        // let startId = 1
        // let endId = 14
        // for (let perID = startId; perID <= endId; perID++) {
        // 	temp.push(perID)
        // }
        for (var index = 0; index < BUY_PERSON.length; index++) {
            var element = BUY_PERSON[index];
            temp.push(element);
        }
        for (var index = 0; index < temp.length; index++) {
            var r = Utils_1.default.random(0, temp.length);
            var a = temp[0];
            var b = temp[r];
            temp[r] = a;
            temp[0] = b;
        }
        for (var index = 1; index < temp.length; index++) {
            var perID = temp[index];
            var flag = this.hasPerson(perID);
            if (!flag) {
                return perID;
            }
        }
        return -1;
    };
    BuyMgr.prototype.canCreate = function (buy) {
        if (!buy) {
            return false;
        }
        var foods = buy.getItems();
        for (var index = 0; index < foods.length; index++) {
            var foodID = foods[index];
            var food = FoodMgr_1.default.instance().getFoodItemModel(foodID);
            if (food) {
                var beBornID = food.getBeBornInitID();
                // console.log(' beBornID ', beBornID)
                if (beBornID > 0) {
                    var bornFood = FoodMgr_1.default.instance().getFoodItemModel(beBornID);
                    if (bornFood) {
                        // console.log(' bornFood.getFoodState() ', bornFood.getFoodState())
                        if (bornFood.getFoodState() == model_1.ItemState.NOT_GET) {
                            return false;
                        }
                    }
                }
            }
        }
        return !this.hasSameItem(buy);
    };
    BuyMgr.prototype.addBuyPerson = function (foodID) {
        var person = new BuyPerson_1.default(foodID);
        if (!person.hasData()) {
            var data = this.getBuyItemModel(foodID);
            if (data) {
                person.setPersonID(data.getPersonID());
                person.setItems(data.getItems());
                person.setItemID(data.getItemID());
                person.setItemNum(data.getItemNum());
                cc.warn(' addBuyPerson 1 ');
                var deleteID = data.getDelete();
                if (deleteID && deleteID > 0) {
                    person.setDelete(data.getDelete());
                }
                cc.warn(' addBuyPerson 21 ');
            }
            person.setState(model_1.ItemState.NOT_GET);
        }
        cc.warn(' addBuyPerson 3 ');
        return person;
    };
    BuyMgr.prototype.getNewBuyPerson = function (id, foodTypeList) {
        // console.log('getNewBuyPerson  id ', id, 'foodTypeList', foodTypeList)
        var person = new BuyPerson_1.default(id);
        //如果有配置表中有id就直接读取配置表中的数据，
        //如果没有就需要自己处理了
        if (!person.hasData()) {
            var data = this.getUnUseData();
            if (data) {
                // console.log('getNewBuyPerson 11111111111111111 ')
                person.setPersonID(data.getPersonID());
                person.setItems(data.getItems());
                person.setItemID(data.getItemID());
                person.setItemNum(data.getItemNum());
                var deleteID = data.getDelete();
                if (deleteID > 0) {
                    person.setDelete(data.getDelete());
                }
            }
            else {
                var count = this.buyItemModelMgr.size();
                if (id <= count) {
                    //表中的数据没有用完直接返回，不产生
                    return null;
                }
                if (foodTypeList && foodTypeList.length > 0) {
                    var perID = this.getUnUsePersonID();
                    person.setPersonID(perID);
                    var itemList = [];
                    var gold = 0;
                    //需求个数
                    var count_1 = Utils_1.default.getRandomValueByList(countRandom);
                    // console.log('getNewBuyPerson 2222222222222222 count ', count)
                    for (var i = 0; i < count_1; i++) {
                        var type = foodTypeList[Utils_1.default.random(0, foodTypeList.length)];
                        var foodList = FoodMgr_1.default.instance().getFoodIndexData(type);
                        var r = 0;
                        for (var j = 0; j < foodList.length; j++) {
                            var food = foodList[j];
                            var price = food.getPrice();
                            if (price && price.length > 0) {
                                var num = price[0];
                                var ran = price[1];
                                r += ran;
                                var random = Utils_1.default.random(0, 100);
                                if (random <= r) {
                                    itemList.push(food.getID());
                                    gold += num;
                                    break;
                                }
                            }
                        }
                    }
                    person.setItems(itemList);
                    person.setItemID(Config_1.ItemID.GOLD);
                    person.setItemNum(gold);
                }
                else {
                    // console.log('getNewBuyPerson 22222222222222222 ')
                    return null;
                }
            }
            person.setState(model_1.ItemState.NOT_GET);
        }
        return person;
    };
    BuyMgr.prototype.getUnUseData = function () {
        var count = this.buyItemModelMgr.size();
        var i = 0;
        var person = null;
        for (var index = 0; index < count; index++) {
            var element = this.buyItemModelMgr.getByIndex(index);
            if (element.getState() == model_1.ItemState.NOT_GET) {
                if (this.canCreate(element)) {
                    if (element.getID() > 3) {
                        var perID = this.getUnUsePersonID();
                        element.setPersonID(perID);
                        person = element;
                        element.setState(model_1.ItemState.GOT);
                        break;
                    }
                    else {
                        var perID = element.getPersonID();
                        if (!this.hasPerson(perID)) {
                            element.setPersonID(perID);
                            person = element;
                            element.setState(model_1.ItemState.GOT);
                            break;
                        }
                    }
                }
                else {
                    // console.warn(' canCreate false')
                }
                i++;
                if (i > 5) {
                    break;
                }
                // break;
            }
        }
        return person;
    };
    BuyMgr.prototype.getPerson = function (foodTypeList) {
        var id = this.personIndex.getInt();
        var person = this.getNewBuyPerson(id, foodTypeList);
        if (person)
            this.personIndex.updateValue(1);
        return person;
    };
    BuyMgr.prototype.getCount = function () {
        var count = 0;
        var len = this.buyItemList.length;
        // for (let index = 0; index < this.buyItemList.length; index++) {
        // 	const element = this.buyItemList[index];
        // 	if (element.getItemID() == ItemID.GOLD) {
        // 		count++;
        // 	}
        // }
        return len;
    };
    BuyMgr.prototype.audoAddPerson = function (typeList) {
        var lv = LevelMgr_1.default.instance().getPersonNum();
        var len = this.getCount();
        if (len < lv) {
            var sub = lv - len;
            console.log('audoAddPerson sub =========== ', sub);
            for (var index = 0; index < sub; index++) {
                var person = this.getPerson(typeList);
                if (person) {
                    person.setState(model_1.ItemState.ON_GOING);
                    this.add(person);
                    event_1.GEvent.instance().emit(Config_1.EventName.ADD_BUY_ITEM, person);
                }
                // this.curID.updateValue(1)
                // if (this.curID.getInt() < this.buyItemModelMgr.size()) {
                // 	let id = this.curID.getInt();
                // 	let m = this.getBuyItemModel(id);
                // 	this.add(m)
                // }
            }
        }
    };
    BuyMgr.prototype.getBuyItemModel = function (id) { return this.buyItemModelMgr.getByID(id); };
    BuyMgr.prototype.getBuyItemModelList = function () { return this.buyItemModelMgr.getList(); };
    BuyMgr.prototype.getBuyList = function () {
        return this.buyItemList;
    };
    BuyMgr.prototype.remove = function (model) {
        var index = this.buyItemList.indexOf(model);
        if (index >= 0) {
            model.setState(model_1.ItemState.GOT);
            this.buyItemList.splice(index, 1);
            this.buyList.delete(model.getID());
        }
    };
    BuyMgr.prototype.add = function (model) {
        this.buyList.push(model.getID());
        this.buyItemList.push(model);
    };
    return BuyMgr;
}(model_1.BaseModel));
exports.default = BuyMgr;

cc._RF.pop();