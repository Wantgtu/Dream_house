import { BaseModel, ModelManager } from "../../../cfw/model";
import { ModuleManager } from "../../../cfw/module";
%import%
/**
* %SheetName%
**/
export default class %ClassName% extends BaseModel {

	%head%

    initData() {
		%init%
	}
	
	%function%


}