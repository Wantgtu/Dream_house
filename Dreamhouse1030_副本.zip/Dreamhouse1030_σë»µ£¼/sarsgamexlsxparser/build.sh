cd /Users/wen/work/sarsgame/Treehouse/sarsgamexlsxparser

data_path="/Users/wen/work/sarsgame/Treehouse/sarsgamexlsxparser/game/data"
export_path="/Users/wen/work/sarsgame/Treehouse/sarsgamexlsxparser/game/export"
copy_path="/Users/wen/work/sarsgame/Treehouse/Treehouse/assets/resources/data"
node read_all game $data_path $export_path $copy_path