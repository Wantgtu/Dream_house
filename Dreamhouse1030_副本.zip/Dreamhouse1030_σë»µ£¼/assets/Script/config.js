
window.lc_sdk = window.lc_sdk || {};
(function (exports) {
    'use strict';
    exports.data = {
        zs_version: "1.0",
        zs_switch: 1,
    }
}(window.lc_sdk = window.lc_sdk || {}));
