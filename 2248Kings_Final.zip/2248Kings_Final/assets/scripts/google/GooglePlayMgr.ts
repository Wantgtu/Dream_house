import { Game, game, native, sys } from "cc";

const javaClassName = "com/sdk/google/GoogleBillHelper";

const GooglePlayConnectCallBack = "GooglePlayConnectCallBack";
const GooglePlayConsumeCallBack = "GooglePlayConsumeCallBack";
export const GooglePlayMgr = {

    init: () => {
        if (!sys.isNative)
            return;
        native.reflection.callStaticMethod(javaClassName, "init", "()V", null);
        let listener = {};
        listener[GooglePlayConnectCallBack] = "GooglePlayMgr.connectCallBack";
        listener[GooglePlayConsumeCallBack] = "GooglePlayMgr.consumeCallBack";
        native.reflection.callStaticMethod(javaClassName, "setListener", "(Ljava/lang/String;)V", JSON.stringify(listener));

        game.on(Game.EVENT_SHOW, GooglePlayMgr.onResume, GooglePlayMgr);
    },

    onResume: () => {
        native.reflection.callStaticMethod(javaClassName, "onResume", "()V", null);
    },

    buyProduct: (productID) => {
        native.reflection.callStaticMethod(javaClassName, "onQuerySkuDetailsAsync", "(Ljava/lang/String;)V", productID);
    },

    /**
     * 连接谷歌支付服务成功
     */
    connectCallBack: () => {
        GooglePlayMgr.onResume();
    },

    /**
     * 谷歌支付成功回调
     * @param jsonStr {
     *   mJsonobjData.put("packageName", packageName);
     *   mJsonobjData.put("productId", productID);
     *   mJsonobjData.put("token", token);
     *   mJsonobjData.put("orderId", orderid);
     * }
     */
    consumeCallBack: (jsonStr) => {
        let json = JSON.parse(jsonStr);
    },
}

window["GooglePlayMgr"] = GooglePlayMgr;