import { ATAndroidInterstitialJS } from "./Android/ATAndroidIntersitialTS";
import { ATiOSInterstitialJS } from "./iOS/ATiOSIntersitialTS";
import { sys, log } from "cc";
import { ATInterstitialListener } from "./ATInterstitialListener";

var initPlatformBridge = function () {
    if (sys.os === sys.OS.IOS) {
        return ATiOSInterstitialJS;
    } else if (sys.os === sys.OS.ANDROID) {
        return ATAndroidInterstitialJS;
    }
};

var platformBridge = initPlatformBridge();


export const ATInterstitialSDK = {

    UseInterstitialAsInterstitial: "UseInterstitialAsInterstitial",

    ATInterstitialListener: new ATInterstitialListener(),

    loadInterstitial: function (placementId, settings = {}) {

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.loadInterstitial(placementId, JSON.stringify(settings));
        } else {
            log("You must run on Android or iOS.");
        }
    },

    setAdListener: function (listener) {
        var eventJSON = {};
        eventJSON[LoadedCallbackKey] = " ATInterstitialSDK.ATInterstitialListener.onInterstitialAdLoaded",
            eventJSON[LoadFailCallbackKey] = " ATInterstitialSDK.ATInterstitialListener.onInterstitialAdLoadFail",
            eventJSON[PlayStartCallbackKey] = " ATInterstitialSDK.ATInterstitialListener.onInterstitialAdStartPlayingVideo",
            eventJSON[PlayEndCallbackKey] = " ATInterstitialSDK.ATInterstitialListener.onInterstitialAdEndPlayingVideo",
            eventJSON[PlayFailCallbackKey] = " ATInterstitialSDK.ATInterstitialListener.onInterstitialAdFailedToPlayVideo",
            eventJSON[CloseCallbackKey] = " ATInterstitialSDK.ATInterstitialListener.onInterstitialAdClose",
            eventJSON[ClickCallbackKey] = " ATInterstitialSDK.ATInterstitialListener.onInterstitialAdClick",
            eventJSON[ShowCallbackKey] = " ATInterstitialSDK.ATInterstitialListener.onInterstitialAdShow",
            eventJSON[ShowFailCallbackKey] = " ATInterstitialSDK.ATInterstitialListener.onInterstitialAdFailedToShow",
            //added v5.8.10
            eventJSON[BiddingAttempt] = " ATInterstitialSDK.ATInterstitialListener.onAdSourceBiddingAttempt",
            eventJSON[BiddingFilled] = " ATInterstitialSDK.ATInterstitialListener.onAdSourceBiddingFilled",
            eventJSON[BiddingFail] = " ATInterstitialSDK.ATInterstitialListener.onAdSourceBiddingFail",
            eventJSON[Attemp] = " ATInterstitialSDK.ATInterstitialListener.onAdSourceAttemp",
            eventJSON[LoadFilled] = " ATInterstitialSDK.ATInterstitialListener.onAdSourceLoadFilled",
            eventJSON[LoadFail] = " ATInterstitialSDK.ATInterstitialListener.onAdSourceLoadFail"

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.setAdListener(JSON.stringify(eventJSON));
        } else {
            log("You must run on Android or iOS.");
        }

        this.ATInterstitialListener.developerCallback = listener;
    },

    hasAdReady: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.hasAdReady(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return false;
    },

    checkAdStatus: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.checkAdStatus(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return "";
    },

    showAd: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAd(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    showAdInScenario: function (placementId, scenario = "") {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAdInScenario(placementId, scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    entryAdScenario: function (placementId, scenario = "") {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.entryAdScenario(placementId, scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    }


};

const LoadedCallbackKey = "InterstitialLoaded";
const LoadFailCallbackKey = "InterstitialLoadFail";
const PlayStartCallbackKey = "InterstitialPlayStart";
const PlayEndCallbackKey = "InterstitialPlayEnd";
const PlayFailCallbackKey = "InterstitialPlayFail";
const CloseCallbackKey = "InterstitialClose";
const ClickCallbackKey = "InterstitialClick";
const ShowCallbackKey = "InterstitialAdShow";
const ShowFailCallbackKey = "InterstitialAdShowFail";

const BiddingAttempt = "InterstitialBiddingAttempt";
const BiddingFilled = "InterstitialBiddingFilled";
const BiddingFail = "InterstitialBiddingFail";
const Attemp = "InterstitialAttemp";
const LoadFilled = "InterstitialLoadFilled";
const LoadFail = "InterstitialLoadFail";

window["ATInterstitialSDK"] = ATInterstitialSDK;