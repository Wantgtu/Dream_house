import { ATAndroidRewardedVideoAutoAdTS } from "./Android/ATAndroidRewardedVideoAutoTS";
import { ATiOSRewardedVideoAutoAdJS } from "./iOS/ATiOSRewardedAutoVideoTS";
import { sys, log } from "cc";
import { ATRewardedAutoVideoListener } from "./ATRewardedAutoVideoListener";

var initPlatformBridge = function () {
    if (sys.os === sys.OS.IOS) {
        return ATiOSRewardedVideoAutoAdJS;
    } else if (sys.os === sys.OS.ANDROID) {
        return ATAndroidRewardedVideoAutoAdTS;
    }
};

var platformBridge = initPlatformBridge();
export const ATRewardedVideoAutoAdSDK = {
    userIdKey: "userID",
    userDataKey: "media_ext",

    ATRewardedVideoListener: new ATRewardedAutoVideoListener(),

    setAdExtraData: function (placementId, settings = {}) {

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.setAdExtraData(placementId, JSON.stringify(settings));
        } else {
            log("You must run on Android or iOS.");
        }
    },

    addPlacementIds: function (placementIds) {

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.addPlacementIds(JSON.stringify(placementIds));
        } else {
            log("You must run on Android or iOS.");
        }
    },

    removePlacementId: function (placementIds) {

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.removePlacementId(JSON.stringify(placementIds));
        } else {
            log("You must run on Android or iOS.");
        }
    },

    setAdListener: function (listener) {
        var eventJSON = {};
        eventJSON[LoadedCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdLoaded",
            eventJSON[LoadFailCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdFailed",
            eventJSON[PlayStartCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdPlayStart",
            eventJSON[PlayEndCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdPlayEnd",
            eventJSON[PlayFailCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdPlayFailed",
            eventJSON[CloseCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdClosed",
            eventJSON[ClickCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdPlayClicked",
            eventJSON[RewardCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onReward",
            //playAgain listener
            eventJSON[AgainPlayStartCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayStart",
            eventJSON[AgainPlayEndCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayEnd",
            eventJSON[AgainPlayFailCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayFailed",
            eventJSON[AgainClickCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayClicked",
            eventJSON[AgainRewardCallbackKey] = "ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onAgainReward"

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.setAdListener(JSON.stringify(eventJSON));
        } else {
            log("You must run on Android or iOS.");
        }

        this.ATRewardedVideoListener.developerCallback = listener;
    },

    hasAdReady: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.hasAdReady(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return false;
    },

    checkAdStatus: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.checkAdStatus(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return "";
    },

    showAd: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAd(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    showAdInScenario: function (placementId, scenario = "") {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAdInScenario(placementId, scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    entryAdScenario: function (placementId, scenario = "") {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.entryAdScenario(placementId, scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    }

};

const LoadedCallbackKey = "RewardedVideoAutoAdLoaded";
const LoadFailCallbackKey = "RewardedVideoAutoAdLoadFail";
const PlayStartCallbackKey = "RewardedVideoAutoAdPlayStart";
const PlayEndCallbackKey = "RewardedVideoAutoAdPlayEnd";
const PlayFailCallbackKey = "RewardedVideoAutoAdPlayFail";
const CloseCallbackKey = "RewardedVideoAutoAdClose";
const ClickCallbackKey = "RewardedVideoAutoAdClick";
const RewardCallbackKey = "RewardedVideoAutoAdReward";

const AgainPlayStartCallbackKey = "RewardedVideoAutoAdAgainPlayStart";
const AgainPlayEndCallbackKey = "RewardedVideoAutoAdAgainPlayEnd";
const AgainPlayFailCallbackKey = "RewardedVideoAutoAdAgainPlayFail";
const AgainClickCallbackKey = "RewardedVideoAutoAdAgainClick";
const AgainRewardCallbackKey = "RewardedVideoAutoAdAgainReward";

window["ATRewardedVideoAutoAdSDK"] = ATRewardedVideoAutoAdSDK;