import { ATJSSDK } from "./ATJSSDK";

export interface RewardedVideoListener {
	onRewardedVideoAdPlayClicked(placementId: string, callbackInfo: string): void;

	onReward(placementId: string, callbackInfo: string): void;

	onAdSourceBiddingAttempt(placementId: string, callbackInfo: string): void;

	onAdSourceBiddingFilled(placementId: string, callbackInfo: string): void;

	onAdSourceBiddingFail(placementId: string, errorInfo: string, callbackInfo: string): void;

	onAdSourceAttemp(placementId: string, callbackInfo: string): void;

	onAdSourceLoadFilled(placementId: string, callbackInfo: string): void;

	onAdSourceLoadFail(placementId: string, errorInfo: string, callbackInfo: string): void;

	onRewardedVideoAdAgainPlayStart(placementId: string, callbackInfo: string): void;

	onRewardedVideoAdAgainPlayEnd(placementId: string, callbackInfo: string): void;

	onRewardedVideoAdAgainPlayFailed(placementId: string, errorInfo: string, callbackInfo: string): void;

	onRewardedVideoAdAgainPlayClicked(placementId: string, callbackInfo: string): void;

	onAgainReward(placementId: string, callbackInfo: string): void;

	onRewardedVideoAdLoaded(placementId: string): void;

	onRewardedVideoAdFailed(placementId: string, errorInfo: string): void;

	onRewardedVideoAdPlayStart(placementId: string, callbackInfo: string): void;

	onRewardedVideoAdPlayEnd(placementId: string, callbackInfo: string): void;

	onRewardedVideoAdPlayFailed(placementId: string, errorInfo: string, callbackInfo: string): void;

	onRewardedVideoAdClosed(placementId: string, callbackInfo: string): void;
}

export class ATRewardedVideoListener {

	developerCallback: RewardedVideoListener = null;

	onRewardedVideoAdLoaded(placementId) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdLoaded(" + placementId + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdLoaded != null && undefined != this.developerCallback.onRewardedVideoAdLoaded) {
			this.developerCallback.onRewardedVideoAdLoaded(placementId);
		}
	}
	onRewardedVideoAdFailed(placementId, errorInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdFailed(" + placementId + ", " + errorInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdFailed != null && undefined != this.developerCallback.onRewardedVideoAdFailed) {
			this.developerCallback.onRewardedVideoAdFailed(placementId, errorInfo);
		}
	}
	onRewardedVideoAdPlayStart(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdPlayStart(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdPlayStart != null && undefined != this.developerCallback.onRewardedVideoAdPlayStart) {
			this.developerCallback.onRewardedVideoAdPlayStart(placementId, callbackInfo);
		}
	}
	onRewardedVideoAdPlayEnd(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdPlayEnd(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdPlayEnd != null && undefined != this.developerCallback.onRewardedVideoAdPlayEnd) {
			this.developerCallback.onRewardedVideoAdPlayEnd(placementId, callbackInfo);
		}
	}
	onRewardedVideoAdPlayFailed(placementId, errorInfo, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdPlayFailed(" + placementId + ", " + errorInfo + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdPlayFailed != null && undefined != this.developerCallback.onRewardedVideoAdPlayFailed) {
			this.developerCallback.onRewardedVideoAdPlayFailed(placementId, errorInfo, callbackInfo);
		}
	}
	onRewardedVideoAdClosed(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdClosed(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdClosed != null && undefined != this.developerCallback.onRewardedVideoAdClosed) {
			this.developerCallback.onRewardedVideoAdClosed(placementId, callbackInfo);
		}
	}
	onRewardedVideoAdPlayClicked(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdPlayClicked(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdPlayClicked != null && undefined != this.developerCallback.onRewardedVideoAdPlayClicked) {
			this.developerCallback.onRewardedVideoAdPlayClicked(placementId, callbackInfo);
		}
	}
	onReward(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onReward(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onReward != null && undefined != this.developerCallback.onReward) {
			this.developerCallback.onReward(placementId, callbackInfo);
		}
	}
	//added v5.8.10
	onAdSourceBiddingAttempt(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceBiddingAttempt(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onAdSourceBiddingAttempt != null && undefined != this.developerCallback.onAdSourceBiddingAttempt) {
			this.developerCallback.onAdSourceBiddingAttempt(placementId, callbackInfo);
		}
	}
	onAdSourceBiddingFilled(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceBiddingFilled(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onAdSourceBiddingFilled != null && undefined != this.developerCallback.onAdSourceBiddingFilled) {
			this.developerCallback.onAdSourceBiddingFilled(placementId, callbackInfo);
		}
	}
	onAdSourceBiddingFail(placementId, errorInfo, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceBiddingFail(" + placementId + ", " + errorInfo + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onAdSourceBiddingFail != null && undefined != this.developerCallback.onAdSourceBiddingFail) {
			this.developerCallback.onAdSourceBiddingFail(placementId, errorInfo, callbackInfo);
		}
	}
	onAdSourceAttemp(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceAttemp(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onAdSourceAttemp != null && undefined != this.developerCallback.onAdSourceAttemp) {
			this.developerCallback.onAdSourceAttemp(placementId, callbackInfo);
		}
	}
	onAdSourceLoadFilled(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceLoadFilled(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onAdSourceLoadFilled != null && undefined != this.developerCallback.onAdSourceLoadFilled) {
			this.developerCallback.onAdSourceLoadFilled(placementId, callbackInfo);
		}
	}
	onAdSourceLoadFail(placementId, errorInfo, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceLoadFail(" + placementId + ", " + errorInfo + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onAdSourceLoadFail != null && undefined != this.developerCallback.onAdSourceLoadFail) {
			this.developerCallback.onAdSourceLoadFail(placementId, errorInfo, callbackInfo);
		}
	}
	onRewardedVideoAdAgainPlayStart(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayStart(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdAgainPlayStart != null && undefined != this.developerCallback.onRewardedVideoAdAgainPlayStart) {
			this.developerCallback.onRewardedVideoAdAgainPlayStart(placementId, callbackInfo);
		}
	}
	onRewardedVideoAdAgainPlayEnd(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayEnd(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdAgainPlayEnd != null && undefined != this.developerCallback.onRewardedVideoAdAgainPlayEnd) {
			this.developerCallback.onRewardedVideoAdAgainPlayEnd(placementId, callbackInfo);
		}
	}
	onRewardedVideoAdAgainPlayFailed(placementId, errorInfo, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayFailed(" + placementId + ", " + errorInfo + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdAgainPlayFailed != null && undefined != this.developerCallback.onRewardedVideoAdAgainPlayFailed) {
			this.developerCallback.onRewardedVideoAdAgainPlayFailed(placementId, errorInfo, callbackInfo);
		}
	}
	onRewardedVideoAdAgainPlayClicked(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayClicked(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdAgainPlayClicked != null && undefined != this.developerCallback.onRewardedVideoAdAgainPlayClicked) {
			this.developerCallback.onRewardedVideoAdAgainPlayClicked(placementId, callbackInfo);
		}
	}
	onAgainReward(placementId, callbackInfo) {
		ATJSSDK.printLog("ATRewardedVideoSDK.ATRewardedVideoListener.onAgainReward(" + placementId + ", " + callbackInfo + ")");
		if (this.developerCallback != null && this.developerCallback.onAgainReward != null && undefined != this.developerCallback.onAgainReward) {
			this.developerCallback.onAgainReward(placementId, callbackInfo);
		}
	}
}