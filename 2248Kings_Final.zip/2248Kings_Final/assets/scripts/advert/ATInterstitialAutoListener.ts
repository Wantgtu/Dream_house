

export interface InterstitialAutoListener {

    onInterstitialAdLoaded(placementId)

    onInterstitialAdLoadFail(placementId, errorInfo)

    onInterstitialAdShow(placementId, callbackInfo)

    onInterstitialAdStartPlayingVideo(placementId, callbackInfo)

    onInterstitialAdEndPlayingVideo(placementId, callbackInfo)

    onInterstitialAdFailedToPlayVideo(placementId, errorInfo)

    onInterstitialAdFailedToShow(placementId, errorInfo, callbackInfo)

    onInterstitialAdClose(placementId, callbackInfo)

    onInterstitialAdClick(placementId, callbackInfo)
}

export class ATInterstitialAutoListener {
    developerCallback: InterstitialAutoListener;

    onInterstitialAdLoaded(placementId) {
        if (this.developerCallback != null && this.developerCallback.onInterstitialAdLoaded != null && undefined != this.developerCallback.onInterstitialAdLoaded) {
            this.developerCallback.onInterstitialAdLoaded(placementId);
        }
    }

    onInterstitialAdLoadFail(placementId, errorInfo) {
        if (this.developerCallback != null && this.developerCallback.onInterstitialAdLoadFail != null && undefined != this.developerCallback.onInterstitialAdLoadFail) {
            this.developerCallback.onInterstitialAdLoadFail(placementId, errorInfo);
        }
    }

    onInterstitialAdShow(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onInterstitialAdShow != null && undefined != this.developerCallback.onInterstitialAdShow) {
            this.developerCallback.onInterstitialAdShow(placementId, callbackInfo);
        }
    }

    onInterstitialAdStartPlayingVideo(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onInterstitialAdStartPlayingVideo != null && undefined != this.developerCallback.onInterstitialAdStartPlayingVideo) {
            this.developerCallback.onInterstitialAdStartPlayingVideo(placementId, callbackInfo);
        }
    }

    onInterstitialAdEndPlayingVideo(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onInterstitialAdEndPlayingVideo != null && undefined != this.developerCallback.onInterstitialAdEndPlayingVideo) {
            this.developerCallback.onInterstitialAdEndPlayingVideo(placementId, callbackInfo);
        }
    }

    onInterstitialAdFailedToPlayVideo(placementId, errorInfo) {
        if (this.developerCallback != null && this.developerCallback.onInterstitialAdFailedToPlayVideo != null && undefined != this.developerCallback.onInterstitialAdFailedToPlayVideo) {
            this.developerCallback.onInterstitialAdFailedToPlayVideo(placementId, errorInfo);
        }
    }

    onInterstitialAdFailedToShow(placementId, errorInfo, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onInterstitialAdFailedToShow != null && undefined != this.developerCallback.onInterstitialAdFailedToShow) {
            this.developerCallback.onInterstitialAdFailedToShow(placementId, errorInfo, callbackInfo);
        }
    }

    onInterstitialAdClose(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onInterstitialAdClose != null && undefined != this.developerCallback.onInterstitialAdClose) {
            this.developerCallback.onInterstitialAdClose(placementId, callbackInfo);
        }
    }

    onInterstitialAdClick(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onInterstitialAdClick != null && undefined != this.developerCallback.onInterstitialAdClick) {
            this.developerCallback.onInterstitialAdClick(placementId, callbackInfo);
        }
    }
}
