import { ATJSSDK } from "./ATJSSDK";

export interface RewardedAutoVideoListener {
    onRewardedVideoAdPlayClicked(placementId: string, callbackInfo: string): void;

    onReward(placementId: string, callbackInfo: string): void;

    onAdSourceBiddingAttempt(placementId: string, callbackInfo: string): void;

    onAdSourceBiddingFilled(placementId: string, callbackInfo: string): void;

    onAdSourceBiddingFail(placementId: string, errorInfo: string, callbackInfo: string): void;

    onAdSourceAttemp(placementId: string, callbackInfo: string): void;

    onAdSourceLoadFilled(placementId: string, callbackInfo: string): void;

    onAdSourceLoadFail(placementId: string, errorInfo: string, callbackInfo: string): void;

    onRewardedVideoAdAgainPlayStart(placementId: string, callbackInfo: string): void;

    onRewardedVideoAdAgainPlayEnd(placementId: string, callbackInfo: string): void;

    onRewardedVideoAdAgainPlayFailed(placementId: string, errorInfo: string, callbackInfo: string): void;

    onRewardedVideoAdAgainPlayClicked(placementId: string, callbackInfo: string): void;

    onAgainReward(placementId: string, callbackInfo: string): void;

    onRewardedVideoAdLoaded(placementId: string): void;

    onRewardedVideoAdFailed(placementId: string, errorInfo: string): void;

    onRewardedVideoAdPlayStart(placementId: string, callbackInfo: string): void;

    onRewardedVideoAdPlayEnd(placementId: string, callbackInfo: string): void;

    onRewardedVideoAdPlayFailed(placementId: string, errorInfo: string, callbackInfo: string): void;
	
    onRewardedVideoAdClosed(placementId: string, callbackInfo: string): void;
}

export class ATRewardedAutoVideoListener {

    developerCallback: RewardedAutoVideoListener;

    onRewardedVideoAdLoaded(placementId) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdLoaded(" + placementId + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdLoaded != null && undefined != this.developerCallback.onRewardedVideoAdLoaded) {
            this.developerCallback.onRewardedVideoAdLoaded(placementId);
        }
    }
    onRewardedVideoAdFailed(placementId, errorInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdFailed(" + placementId + ", " + errorInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdFailed != null && undefined != this.developerCallback.onRewardedVideoAdFailed) {
            this.developerCallback.onRewardedVideoAdFailed(placementId, errorInfo);
        }
    }
    onRewardedVideoAdPlayStart(placementId, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdPlayStart(" + placementId + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdPlayStart != null && undefined != this.developerCallback.onRewardedVideoAdPlayStart) {
            this.developerCallback.onRewardedVideoAdPlayStart(placementId, callbackInfo);
        }
    }
    onRewardedVideoAdPlayEnd(placementId, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdPlayEnd(" + placementId + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdPlayEnd != null && undefined != this.developerCallback.onRewardedVideoAdPlayEnd) {
            this.developerCallback.onRewardedVideoAdPlayEnd(placementId, callbackInfo);
        }
    }
    onRewardedVideoAdPlayFailed(placementId, errorInfo, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdPlayFailed(" + placementId + ", " + errorInfo + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdPlayFailed != null && undefined != this.developerCallback.onRewardedVideoAdPlayFailed) {
            this.developerCallback.onRewardedVideoAdPlayFailed(placementId, errorInfo, callbackInfo);
        }
    }
    onRewardedVideoAdClosed(placementId, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdClosed(" + placementId + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdClosed != null && undefined != this.developerCallback.onRewardedVideoAdClosed) {
            this.developerCallback.onRewardedVideoAdClosed(placementId, callbackInfo);
        }
    }
    onRewardedVideoAdPlayClicked(placementId, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdPlayClicked(" + placementId + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdPlayClicked != null && undefined != this.developerCallback.onRewardedVideoAdPlayClicked) {
            this.developerCallback.onRewardedVideoAdPlayClicked(placementId, callbackInfo);
        }
    }
    onReward(placementId, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onReward(" + placementId + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onReward != null && undefined != this.developerCallback.onReward) {
            this.developerCallback.onReward(placementId, callbackInfo);
        }
    }
    onRewardedVideoAdAgainPlayStart(placementId, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayStart(" + placementId + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdAgainPlayStart != null && undefined != this.developerCallback.onRewardedVideoAdAgainPlayStart) {
            this.developerCallback.onRewardedVideoAdAgainPlayStart(placementId, callbackInfo);
        }
    }
    onRewardedVideoAdAgainPlayEnd(placementId, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayEnd(" + placementId + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdAgainPlayEnd != null && undefined != this.developerCallback.onRewardedVideoAdAgainPlayEnd) {
            this.developerCallback.onRewardedVideoAdAgainPlayEnd(placementId, callbackInfo);
        }
    }
    onRewardedVideoAdAgainPlayFailed(placementId, errorInfo, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayFailed(" + placementId + ", " + errorInfo + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdAgainPlayFailed != null && undefined != this.developerCallback.onRewardedVideoAdAgainPlayFailed) {
            this.developerCallback.onRewardedVideoAdAgainPlayFailed(placementId, errorInfo, callbackInfo);
        }
    }
    onRewardedVideoAdAgainPlayClicked(placementId, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayClicked(" + placementId + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onRewardedVideoAdAgainPlayClicked != null && undefined != this.developerCallback.onRewardedVideoAdAgainPlayClicked) {
            this.developerCallback.onRewardedVideoAdAgainPlayClicked(placementId, callbackInfo);
        }
    }
    onAgainReward(placementId, callbackInfo) {
        ATJSSDK.printLog("ATRewardedVideoAutoAdSDK.ATRewardedVideoListener.onAgainReward(" + placementId + ", " + callbackInfo + ")");
        if (this.developerCallback != null && this.developerCallback.onAgainReward != null && undefined != this.developerCallback.onAgainReward) {
            this.developerCallback.onAgainReward(placementId, callbackInfo);
        }
    }
}