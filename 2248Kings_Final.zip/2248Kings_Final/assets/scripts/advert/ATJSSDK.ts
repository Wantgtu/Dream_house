
import { ATAndroidJS } from "./Android/ATAndroidJS"
import { ATiOSJS } from "./iOS/ATiOSJS";
import { _decorator, log, sys } from 'cc';
import { ATWeiXinJS } from "./WeiXin/ATWeiXinJS";
import { ATByteDanceJS } from "./ByteDance/ATByteDanceJS";

var isDebugLog = false;

var initPlatformBridge = function () {
    if (sys.platform === sys.Platform.IOS) {
        return ATiOSJS;
    } else if (sys.platform === sys.Platform.ANDROID) {
        return ATAndroidJS;
    } else if (sys.platform === sys.Platform.WECHAT_GAME) {
        return ATWeiXinJS;
    } else if (sys.platform === sys.Platform.BYTEDANCE_MINI_GAME) {
        return ATByteDanceJS;
    }
};

var platformBridge = initPlatformBridge();

export const ATJSSDK = {

    kATUserLocationUnknown: 0,
    kATUserLocationInEU: 1,
    kATUserLocationOutOfEU: 2,


    PERSONALIZED: 0,
    NONPERSONALIZED: 1,
    UNKNOWN: 2,


    //for android and ios
    OS_VERSION_NAME: "os_vn",
    OS_VERSION_CODE: "os_vc",
    APP_PACKAGE_NAME: "package_name",
    APP_VERSION_NAME: "app_vn",
    APP_VERSION_CODE: "app_vc",

    BRAND: "brand",
    MODEL: "model",
    DEVICE_SCREEN_SIZE: "screen",
    MNC: "mnc",
    MCC: "mcc",

    LANGUAGE: "language",
    TIMEZONE: "timezone",
    USER_AGENT: "ua",
    ORIENTATION: "orient",
    NETWORK_TYPE: "network_type",

    //for android
    INSTALLER: "it_src",
    ANDROID_ID: "android_id",
    GAID: "gaid",
    MAC: "mac",
    IMEI: "imei",
    OAID: "oaid",

    //for ios
    IDFA: "idfa",
    IDFV: "idfv",

    ATSDKListener: {
        userLocationCallback: null,

        getUserLocationCallback: function (userLocation) {
            if (undefined != this.userLocationCallback && this.userLocationCallback != null) {
                this.userLocationCallback(userLocation);
            }
        }
    },

    //游戏初始化调用
    initSDK: function (appId, appKey) {

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.initSDK(appId, appKey);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    initCustomMap: function (customMap) {
        if (undefined != platformBridge && platformBridge != null) {
            if (undefined != customMap && customMap != null) {
                platformBridge.initCustomMap(JSON.stringify(customMap));
            }
        } else {
            log("You must run on Android or iOS.");
        }
    },

    setPlacementCustomMap: function (placmentId, customMap) {
        if (undefined != platformBridge && platformBridge != null) {
            if (undefined != customMap && customMap != null) {
                platformBridge.setPlacementCustomMap(placmentId, JSON.stringify(customMap));
            }
        } else {
            log("You must run on Android or iOS.");
        }
    },

    setGDPRLevel: function (level) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.setGDPRLevel(level);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    getGDPRLevel: function () {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.getGDPRLevel();
        } else {
            log("You must run on Android or iOS.");
        }
        return this.UNKNOWN;
    },

    getUserLocation: function (userLocationCallback) {
        this.ATSDKListener.userLocationCallback = userLocationCallback;
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.getUserLocation(GetUserLocationJsCallback);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    showGDPRAuth: function () {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showGDPRAuth();
        } else {
            log("You must run on Android or iOS.");
        }
    },

    setLogDebug: function (debug) {
        isDebugLog = debug;
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.setLogDebug(debug);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    printLog: function (msg) {
        if (undefined != msg && null != msg && isDebugLog && platformBridge != null) {
            if (undefined != platformBridge && platformBridge != null) {
                platformBridge.printJsLog(msg);
            } else {
                log("You must run on Android or iOS.");
            }

        }
    },

    printLogWithParams: function (tag, methodName, placementId, callbackInfo, errorInfo) {
        this.printLog(tag + "::" + methodName + "()" + "\nplacementId=" + placementId + "\ncallbackInfo=" + callbackInfo + "\nerrorInfo=" + errorInfo);
    },

    deniedUploadDeviceInfo: function (deniedInfo) {
        if (undefined != platformBridge && platformBridge != null) {

            if (deniedInfo != null) {
                var length = deniedInfo.length;
                var deniedInfoString = "";
                for (var i = 0; i < length; i++) {
                    var info = deniedInfo[i];
                    if (i == 0) {
                        deniedInfoString = info;
                    } else {
                        deniedInfoString = deniedInfoString + "," + info;
                    }
                }

                log("test__" + deniedInfoString)

                platformBridge.deniedUploadDeviceInfo(deniedInfoString);
            }

        } else {
            log("You must run on Android or iOS.");
        }
    },

};

const GetUserLocationJsCallback = " ATJSSDK.ATSDKListener.getUserLocationCallback";

window["ATJSSDK"] = ATJSSDK;
