

export interface NativeListener {
    onNativeAdLoaded(placementId): void;
    onNativeAdLoadFail(placementId, errorInfo): void;
    onNativeAdShow(placementId, callbackInfo): void;
    onNativeAdClick(placementId, callbackInfo): void;
    onNativeAdVideoStart(placementId): void;
    onNativeAdVideoEnd(placementId): void;
    onNativeAdCloseButtonTapped(placementId, callbackInfo): void;
    //added v5.8.10
    onAdSourceBiddingAttempt(placementId, callbackInfo): void;
    onAdSourceBiddingFilled(placementId, callbackInfo): void;
    onAdSourceBiddingFail(placementId, errorInfo, callbackInfo): void;
    onAdSourceAttemp(placementId, callbackInfo): void;
    onAdSourceLoadFilled(placementId, callbackInfo): void;
    onAdSourceLoadFail(placementId, errorInfo, callbackInfo): void;
}

export class ATNativeListener {

    developerCallback: NativeListener;

    onNativeAdLoaded(placementId) {
        if (this.developerCallback != null && this.developerCallback.onNativeAdLoaded != null && undefined != this.developerCallback.onNativeAdLoaded) {
            this.developerCallback.onNativeAdLoaded(placementId);
        }
    }

    onNativeAdLoadFail(placementId, errorInfo) {
        if (this.developerCallback != null && this.developerCallback.onNativeAdLoadFail != null && undefined != this.developerCallback.onNativeAdLoadFail) {
            this.developerCallback.onNativeAdLoadFail(placementId, errorInfo);
        }
    }

    onNativeAdShow(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onNativeAdShow != null && undefined != this.developerCallback.onNativeAdShow) {
            this.developerCallback.onNativeAdShow(placementId, callbackInfo);
        }
    }

    onNativeAdClick(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onNativeAdClick != null && undefined != this.developerCallback.onNativeAdClick) {
            this.developerCallback.onNativeAdClick(placementId, callbackInfo);
        }
    }

    onNativeAdVideoStart(placementId) {
        if (this.developerCallback != null && this.developerCallback.onNativeAdVideoStart != null && undefined != this.developerCallback.onNativeAdVideoStart) {
            this.developerCallback.onNativeAdVideoStart(placementId,);
        }
    }

    onNativeAdVideoEnd(placementId) {
        if (this.developerCallback != null && this.developerCallback.onNativeAdVideoEnd != null && undefined != this.developerCallback.onNativeAdVideoEnd) {
            this.developerCallback.onNativeAdVideoEnd(placementId);
        }
    }

    onNativeAdCloseButtonTapped(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onNativeAdCloseButtonTapped != null && undefined != this.developerCallback.onNativeAdCloseButtonTapped) {
            this.developerCallback.onNativeAdCloseButtonTapped(placementId, callbackInfo);
        }
    }
    //added v5.8.10
    onAdSourceBiddingAttempt(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onAdSourceBiddingAttempt != null && undefined != this.developerCallback.onAdSourceBiddingAttempt) {
            this.developerCallback.onAdSourceBiddingAttempt(placementId, callbackInfo);
        }
    }
    onAdSourceBiddingFilled(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onAdSourceBiddingFilled != null && undefined != this.developerCallback.onAdSourceBiddingFilled) {
            this.developerCallback.onAdSourceBiddingFilled(placementId, callbackInfo);
        }
    }
    onAdSourceBiddingFail(placementId, errorInfo, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onAdSourceBiddingFail != null && undefined != this.developerCallback.onAdSourceBiddingFail) {
            this.developerCallback.onAdSourceBiddingFail(placementId, errorInfo, callbackInfo);
        }
    }
    onAdSourceAttemp(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onAdSourceAttemp != null && undefined != this.developerCallback.onAdSourceAttemp) {
            this.developerCallback.onAdSourceAttemp(placementId, callbackInfo);
        }
    }
    onAdSourceLoadFilled(placementId, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onAdSourceLoadFilled != null && undefined != this.developerCallback.onAdSourceLoadFilled) {
            this.developerCallback.onAdSourceLoadFilled(placementId, callbackInfo);
        }
    }
    onAdSourceLoadFail(placementId, errorInfo, callbackInfo) {
        if (this.developerCallback != null && this.developerCallback.onAdSourceLoadFail != null && undefined != this.developerCallback.onAdSourceLoadFail) {
            this.developerCallback.onAdSourceLoadFail(placementId, errorInfo, callbackInfo);
        }
    }

}