import { ATAndroidBannerTS } from "./Android/ATAndroidBannerTS";
import { ATiOSBannerJS } from "./iOS/ATiOSBannerTS";
import { sys, log } from "cc";
import { ATBannerListener } from "./ATBannerListener";

var initPlatformBridge = function () {
    if (sys.os === sys.OS.IOS) {
        return ATiOSBannerJS;
    } else if (sys.os === sys.OS.ANDROID) {
        return ATAndroidBannerTS;
    }
};

var platformBridge = initPlatformBridge();


export const ATBannerSDK = {
    kATBannerAdLoadingExtraBannerAdSizeStruct: "banner_ad_size_struct",
    kATBannerAdShowingPositionTop: "top",
    kATBannerAdShowingPositionBottom: "bottom",

    kATBannerAdInlineAdaptiveWidth: "inline_adaptive_width",
    kATBannerAdInlineAdaptiveOrientation: "inline_adaptive_orientation",
    kATBannerAdInlineAdaptiveOrientationCurrent: 0,
    kATBannerAdInlineAdaptiveOrientationPortrait: 1,
    kATBannerAdInlineAdaptiveOrientationLandscape: 2,

    kATBannerAdAdaptiveWidth: "adaptive_width",
    kATBannerAdAdaptiveOrientation: "adaptive_orientation",
    kATBannerAdAdaptiveOrientationCurrent: 0,
    kATBannerAdAdaptiveOrientationPortrait: 1,
    kATBannerAdAdaptiveOrientationLandscape: 2,


    ATBannerListener: new ATBannerListener(),

    loadBanner: function (placementId, settings = {}) {

        if (undefined != platformBridge && platformBridge != null) {

            if (settings.hasOwnProperty(ATBannerSDK.kATBannerAdLoadingExtraBannerAdSizeStruct)) {
                var loadAdSize = settings[ATBannerSDK.kATBannerAdLoadingExtraBannerAdSizeStruct];
                settings["width"] = loadAdSize["width"];
                settings["height"] = loadAdSize["height"];
            }

            platformBridge.loadBanner(placementId, JSON.stringify(settings));
        } else {
            log("You must run on Android or iOS.");
        }
    },

    setAdListener: function (listener) {
        var eventJSON = {};
        eventJSON[LoadedCallbackKey] = "ATBannerSDK.ATBannerListener.onBannerAdLoaded",
            eventJSON[LoadFailCallbackKey] = "ATBannerSDK.ATBannerListener.onBannerAdLoadFail",
            eventJSON[CloseCallbackKey] = "ATBannerSDK.ATBannerListener.onBannerAdCloseButtonTapped",
            eventJSON[ClickCallbackKey] = "ATBannerSDK.ATBannerListener.onBannerAdClick",
            eventJSON[ShowCallbackKey] = "ATBannerSDK.ATBannerListener.onBannerAdShow",
            eventJSON[RefreshCallbackKey] = "ATBannerSDK.ATBannerListener.onBannerAdAutoRefresh",
            eventJSON[RefreshFailCallbackKey] = "ATBannerSDK.ATBannerListener.onBannerAdAutoRefreshFail",
            //added v5.8.10
            eventJSON[BiddingAttempt] = "ATBannerSDK.ATBannerListener.onAdSourceBiddingAttempt",
            eventJSON[BiddingFilled] = "ATBannerSDK.ATBannerListener.onAdSourceBiddingFilled",
            eventJSON[BiddingFail] = "ATBannerSDK.ATBannerListener.onAdSourceBiddingFail",
            eventJSON[Attemp] = "ATBannerSDK.ATBannerListener.onAdSourceAttemp",
            eventJSON[LoadFilled] = "ATBannerSDK.ATBannerListener.onAdSourceLoadFilled",
            eventJSON[LoadFail] = "ATBannerSDK.ATBannerListener.onAdSourceLoadFail"

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.setAdListener(JSON.stringify(eventJSON));
        } else {
            log("You must run on Android or iOS.");
        }

        this.ATBannerListener.developerCallback = listener;
    },

    hasAdReady: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.hasAdReady(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return false;
    },

    checkAdStatus: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.checkAdStatus(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return "";
    },

    showAdInPosition: function (placementId, position) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAdInPosition(placementId, position);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    showAdInPositionAndScenario: function (placementId, position, scenario) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAdInPositionAndScenario(placementId, position, scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    showAdInRectangle: function (placementId, showAdRect) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAdInRectangle(placementId, JSON.stringify(showAdRect));
        } else {
            log("You must run on Android or iOS.");
        }
    },

    showAdInRectangleAndScenario: function (placementId, showAdRect, scenario) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAdInRectangleAndScenario(placementId, JSON.stringify(showAdRect), scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    removeAd: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.removeAd(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    reShowAd: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.reShowAd(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    hideAd: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.hideAd(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    createLoadAdSize: function (width, height) {
        var loadAdSize = {};
        loadAdSize["width"] = width;
        loadAdSize["height"] = height;
        return loadAdSize;
    },

    createShowAdRect: function (x, y, width, height) {
        var adRect = {};
        adRect["x"] = x;
        adRect["y"] = y;
        adRect["width"] = width;
        adRect["height"] = height;
        return adRect;
    }


};

const LoadedCallbackKey = "BannerLoaded";
const LoadFailCallbackKey = "BannerLoadFail";
const CloseCallbackKey = "BannerCloseButtonTapped";
const ClickCallbackKey = "BannerClick";
const ShowCallbackKey = "BannerShow";
const RefreshCallbackKey = "BannerRefresh";
const RefreshFailCallbackKey = "BannerRefreshFail";

const BiddingAttempt = "BannerBiddingAttempt";
const BiddingFilled = "BannerBiddingFilled";
const BiddingFail = "BannerBiddingFail";
const Attemp = "BannerAttemp";
const LoadFilled = "BannerLoadFilled";
const LoadFail = "BannerLoadFail";

window["ATBannerSDK"] = ATBannerSDK;