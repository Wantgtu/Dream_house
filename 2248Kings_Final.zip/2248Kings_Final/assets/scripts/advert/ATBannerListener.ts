
export interface BannerListener {

	onBannerAdLoaded(placementId)

	onBannerAdLoadFail(placementId, errorInfo)

	onBannerAdShow(placementId, callbackInfo)

	onBannerAdClick(placementId, callbackInfo)

	onBannerAdAutoRefresh(placementId, callbackInfo)

	onBannerAdAutoRefreshFail(placementId, errorInfo)

	onBannerAdCloseButtonTapped(placementId, callbackInfo)
	//added v5.8.10
	onAdSourceBiddingAttempt(placementId, callbackInfo)
	onAdSourceBiddingFilled(placementId, callbackInfo)
	onAdSourceBiddingFail(placementId, errorInfo, callbackInfo)
	onAdSourceAttemp(placementId, callbackInfo)
	onAdSourceLoadFilled(placementId, callbackInfo)
	onAdSourceLoadFail(placementId, errorInfo, callbackInfo)
}

export class ATBannerListener {
	developerCallback: BannerListener

	onBannerAdLoaded(placementId) {
		if (this.developerCallback != null && this.developerCallback.onBannerAdLoaded != null && undefined != this.developerCallback.onBannerAdLoaded) {
			this.developerCallback.onBannerAdLoaded(placementId);
		}
	}

	onBannerAdLoadFail(placementId, errorInfo) {
		if (this.developerCallback != null && this.developerCallback.onBannerAdLoadFail != null && undefined != this.developerCallback.onBannerAdLoadFail) {
			this.developerCallback.onBannerAdLoadFail(placementId, errorInfo);
		}
	}

	onBannerAdShow(placementId, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onBannerAdShow != null && undefined != this.developerCallback.onBannerAdShow) {
			this.developerCallback.onBannerAdShow(placementId, callbackInfo);
		}
	}

	onBannerAdClick(placementId, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onBannerAdClick != null && undefined != this.developerCallback.onBannerAdClick) {
			this.developerCallback.onBannerAdClick(placementId, callbackInfo);
		}
	}

	onBannerAdAutoRefresh(placementId, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onBannerAdAutoRefresh != null && undefined != this.developerCallback.onBannerAdAutoRefresh) {
			this.developerCallback.onBannerAdAutoRefresh(placementId, callbackInfo);
		}
	}

	onBannerAdAutoRefreshFail(placementId, errorInfo) {
		if (this.developerCallback != null && this.developerCallback.onBannerAdAutoRefreshFail != null && undefined != this.developerCallback.onBannerAdAutoRefreshFail) {
			this.developerCallback.onBannerAdAutoRefreshFail(placementId, errorInfo);
		}
	}

	onBannerAdCloseButtonTapped(placementId, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onBannerAdCloseButtonTapped != null && undefined != this.developerCallback.onBannerAdCloseButtonTapped) {
			this.developerCallback.onBannerAdCloseButtonTapped(placementId, callbackInfo);
		}
	}
	//added v5.8.10
	onAdSourceBiddingAttempt(placementId, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onAdSourceBiddingAttempt != null && undefined != this.developerCallback.onAdSourceBiddingAttempt) {
			this.developerCallback.onAdSourceBiddingAttempt(placementId, callbackInfo);
		}
	}
	onAdSourceBiddingFilled(placementId, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onAdSourceBiddingFilled != null && undefined != this.developerCallback.onAdSourceBiddingFilled) {
			this.developerCallback.onAdSourceBiddingFilled(placementId, callbackInfo);
		}
	}
	onAdSourceBiddingFail(placementId, errorInfo, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onAdSourceBiddingFail != null && undefined != this.developerCallback.onAdSourceBiddingFail) {
			this.developerCallback.onAdSourceBiddingFail(placementId, errorInfo, callbackInfo);
		}
	}
	onAdSourceAttemp(placementId, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onAdSourceAttemp != null && undefined != this.developerCallback.onAdSourceAttemp) {
			this.developerCallback.onAdSourceAttemp(placementId, callbackInfo);
		}
	}
	onAdSourceLoadFilled(placementId, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onAdSourceLoadFilled != null && undefined != this.developerCallback.onAdSourceLoadFilled) {
			this.developerCallback.onAdSourceLoadFilled(placementId, callbackInfo);
		}
	}
	onAdSourceLoadFail(placementId, errorInfo, callbackInfo) {
		if (this.developerCallback != null && this.developerCallback.onAdSourceLoadFail != null && undefined != this.developerCallback.onAdSourceLoadFail) {
			this.developerCallback.onAdSourceLoadFail(placementId, errorInfo, callbackInfo);
		}
	}

}