import { ATAndroidRewardedVideoJS } from "./Android/ATAndroidRewardedVideoTS";
import { ATiOSRewardedVideoTS } from "./iOS/ATiOSRewardedVideoTS";
import { log, sys } from "cc";
import { ATRewardedVideoListener, RewardedVideoListener } from "./ATRewardedVideoListener";
import { ATWeiXinRewardedVideoTS } from "./WeiXin/ATWeiXinRewardedVideoTS";
import { ATByteDanceRewardedVideoTS } from "./ByteDance/ATByteDanceRewardedVideoTS";

var initPlatformBridge = function () {
    if (sys.platform === sys.Platform.IOS) {
        return ATiOSRewardedVideoTS;
    } else if (sys.platform === sys.Platform.ANDROID) {
        return ATAndroidRewardedVideoJS;
    } else if (sys.platform === sys.Platform.WECHAT_GAME) {
        return ATWeiXinRewardedVideoTS;
    } else if (sys.platform === sys.Platform.BYTEDANCE_MINI_GAME) {
        return ATByteDanceRewardedVideoTS;
    }
};

var platformBridge = initPlatformBridge();


export const ATRewardedVideoSDK = {
    userIdKey: "userID",
    userDataKey: "media_ext",

    ATRewardedVideoListener: new ATRewardedVideoListener(),

    //加载激励视频广告调用
    loadRewardedVideo: function (placementId, settings = {}) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.loadRewardedVideo(placementId, JSON.stringify(settings));
        } else {
            log("You must run on Android or iOS.");
        }
    },

    //设置激励视频回调
    setAdListener: function (listener: RewardedVideoListener) {
        var eventJSON = {};
        eventJSON[LoadedCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdLoaded",
            eventJSON[LoadFailCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdFailed",
            eventJSON[PlayStartCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdPlayStart",
            eventJSON[PlayEndCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdPlayEnd",
            eventJSON[PlayFailCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdPlayFailed",
            eventJSON[CloseCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdClosed",
            eventJSON[ClickCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdPlayClicked",
            eventJSON[RewardCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onReward",
            //added v5.8.10
            eventJSON[BiddingAttempt] = "ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceBiddingAttempt",
            eventJSON[BiddingFilled] = "ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceBiddingFilled",
            eventJSON[BiddingFail] = "ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceBiddingFail",
            eventJSON[Attemp] = "ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceAttemp",
            eventJSON[LoadFilled] = "ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceLoadFilled",
            eventJSON[LoadFail] = "ATRewardedVideoSDK.ATRewardedVideoListener.onAdSourceLoadFail",
            //added v5.8.10 playAgain listener
            eventJSON[AgainPlayStartCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayStart",
            eventJSON[AgainPlayEndCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayEnd",
            eventJSON[AgainPlayFailCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayFailed",
            eventJSON[AgainClickCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onRewardedVideoAdAgainPlayClicked",
            eventJSON[AgainRewardCallbackKey] = "ATRewardedVideoSDK.ATRewardedVideoListener.onAgainReward"

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.setAdListener(JSON.stringify(eventJSON));
        } else {
            log("You must run on Android or iOS.");
        }

        this.ATRewardedVideoListener.developerCallback = listener;
    },

    //广告是否准备好
    hasAdReady: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.hasAdReady(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return false;
    },

    checkAdStatus: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.checkAdStatus(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return "";
    },

    //播放已经加载好的广告
    showAd: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAd(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    showAdInScenario: function (placementId, scenario = "") {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAdInScenario(placementId, scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    entryAdScenario: function (placementId, scenario = "") {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.entryAdScenario(placementId, scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    },
    testMethod: function () {
        log("testing You must run on Android or iOS.");
    }

};

const LoadedCallbackKey = "RewardedVideoLoaded";
const LoadFailCallbackKey = "RewardedVideoLoadFail";
const PlayStartCallbackKey = "RewardedVideoPlayStart";
const PlayEndCallbackKey = "RewardedVideoPlayEnd";
const PlayFailCallbackKey = "RewardedVideoPlayFail";
const CloseCallbackKey = "RewardedVideoClose";
const ClickCallbackKey = "RewardedVideoClick";
const RewardCallbackKey = "RewardedVideoReward";

const BiddingAttempt = "RewardedVideoBiddingAttempt";
const BiddingFilled = "RewardedVideoBiddingFilled";
const BiddingFail = "RewardedVideoBiddingFail";
const Attemp = "RewardedVideoAttemp";
const LoadFilled = "RewardedVideoLoadFilled";
const LoadFail = "RewardedVideoLoadFail";

const AgainPlayStartCallbackKey = "RewardedVideoAgainPlayStart";
const AgainPlayEndCallbackKey = "RewardedVideoAgainPlayEnd";
const AgainPlayFailCallbackKey = "RewardedVideoAgainPlayFail";
const AgainClickCallbackKey = "RewardedVideoAgainClick";
const AgainRewardCallbackKey = "RewardedVideoAgainReward";

window["ATRewardedVideoSDK"] = ATRewardedVideoSDK;