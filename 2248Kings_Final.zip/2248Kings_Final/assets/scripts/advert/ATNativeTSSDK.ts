import { Component, log, sys } from "cc";
import { ATiOSNativeTS } from "./iOS/ATiOSNativeTS"
import { ATAndroidNativeTS } from "./Android/ATAndroidNativeTS"
import { ATNativeListener } from "./ATNativeListener";
var initPlatformBridge = function () {
    if (sys.os === sys.OS.IOS) {
        return ATiOSNativeTS;
    } else if (sys.os === sys.OS.ANDROID) {
        return ATAndroidNativeTS;
    }
};

var platformBridge = initPlatformBridge();

export const ATNativeTSSDK = {
    ATNativeListener: new ATNativeListener(),

    loadNative: function (placementId, settings = {}) {

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.loadNative(placementId, JSON.stringify(settings));
        } else {
            log("You must run on Android or iOS.");
        }
    },

    setAdListener: function (listener) {
        var eventJSON = {};
        eventJSON[LoadedCallbackKey] = "ATNativeTSSDK.ATNativeListener.onNativeAdLoaded",
            eventJSON[LoadFailCallbackKey] = "ATNativeTSSDK.ATNativeListener.onNativeAdLoadFail",
            eventJSON[CloseCallbackKey] = "ATNativeTSSDK.ATNativeListener.onNativeAdCloseButtonTapped",
            eventJSON[ClickCallbackKey] = "ATNativeTSSDK.ATNativeListener.onNativeAdClick",
            eventJSON[ShowCallbackKey] = "ATNativeTSSDK.ATNativeListener.onNativeAdShow",
            eventJSON[VideoStartKey] = "ATNativeTSSDK.ATNativeListener.onNativeAdVideoStart",
            eventJSON[VideoEndKey] = "ATNativeTSSDK.ATNativeListener.onNativeAdVideoEnd",
            //added v5.8.10
            eventJSON[BiddingAttempt] = "ATNativeTSSDK.ATNativeListener.onAdSourceBiddingAttempt",
            eventJSON[BiddingFilled] = "ATNativeTSSDK.ATNativeListener.onAdSourceBiddingFilled",
            eventJSON[BiddingFail] = "ATNativeTSSDK.ATNativeListener.onAdSourceBiddingFail",
            eventJSON[Attemp] = "ATNativeTSSDK.ATNativeListener.onAdSourceAttemp",
            eventJSON[LoadFilled] = "ATNativeTSSDK.ATNativeListener.onAdSourceLoadFilled",
            eventJSON[LoadFail] = "ATNativeTSSDK.ATNativeListener.onAdSourceLoadFail"

        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.setAdListener(JSON.stringify(eventJSON));
        } else {
            log("You must run on Android or iOS.");
        }

        this.ATNativeListener.developerCallback = listener;
    },

    hasAdReady: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.hasAdReady(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return false;
    },

    checkAdStatus: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            return platformBridge.checkAdStatus(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
        return "";
    },

    showAd: function (placementId, adViewProperty) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAd(placementId, JSON.stringify(adViewProperty.getAdViewProperty()));
        } else {
            log("You must run on Android or iOS.");
        }
    },

    showAdInScenario: function (placementId, adViewProperty, scenario = "") {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.showAdInScenario(placementId, JSON.stringify(adViewProperty.getAdViewProperty()), scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    entryAdScenario: function (placementId, scenario = "") {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.entryAdScenario(placementId, scenario);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    removeAd: function (placementId) {
        if (undefined != platformBridge && platformBridge != null) {
            platformBridge.removeAd(placementId);
        } else {
            log("You must run on Android or iOS.");
        }
    },

    createLoadAdSize: function (width, height) {
        var loadAdSize = {};
        loadAdSize["width"] = width;
        loadAdSize["height"] = height;
        return loadAdSize;
    },

};

export class AdViewProperty extends Component {

    parent = null
    appIcon = null
    mainImage = null
    title = null
    desc = null
    adLogo = null
    cta = null
    rating = null
    dislike = null

    createItemViewProperty(x, y, width, height, backgroundColor, textColor, textSize, isCustomClick = false) {
        var itemProperty = {};
        itemProperty["x"] = x;
        itemProperty["y"] = y;
        itemProperty["width"] = width;
        itemProperty["height"] = height;
        itemProperty["backgroundColor"] = backgroundColor;
        itemProperty["textColor"] = textColor;
        itemProperty["textSize"] = textSize;
        itemProperty["isCustomClick"] = isCustomClick;

        return itemProperty;
    }

    getAdViewProperty() {
        var nativeViewProperty = {};

        if (this.parent != null) {
            nativeViewProperty["parent"] = this.parent;
        }

        if (this.appIcon != null) {
            nativeViewProperty["icon"] = this.appIcon;
        }

        if (this.mainImage != null) {
            nativeViewProperty["mainImage"] = this.mainImage;
        }

        if (this.title != null) {
            nativeViewProperty["title"] = this.title;
        }

        if (this.desc != null) {
            nativeViewProperty["desc"] = this.desc;
        }

        if (this.adLogo != null) {
            nativeViewProperty["adLogo"] = this.adLogo;
        }

        if (this.cta != null) {
            nativeViewProperty["cta"] = this.cta;
        }

        if (this.rating != null) {
            nativeViewProperty["rating"] = this.rating;
        }

        if (this.dislike != null) {
            nativeViewProperty["dislike"] = this.dislike;
        }

        return nativeViewProperty;
    }
}

const LoadedCallbackKey = "NativeLoaded";
const LoadFailCallbackKey = "NativeLoadFail";
const CloseCallbackKey = "NativeCloseButtonTapped";
const ClickCallbackKey = "NativeClick";
const ShowCallbackKey = "NativeShow";
const VideoStartKey = "NativeVideoStart";
const VideoEndKey = "NativeVideoEnd";
const BiddingAttempt = "NativeBiddingAttempt";
const BiddingFilled = "NativeBiddingFilled";
const BiddingFail = "NativeBiddingFail";
const Attemp = "NativeAttemp";
const LoadFilled = "NativeLoadFilled";
const LoadFail = "NativeLoadFail";
window["ATNativeTSSDK"] = ATNativeTSSDK;