import { log, _decorator } from 'cc';
import g_GameMgr from '../../common/GameMgr';
import { rewardType } from "../../common/EnumType";
const { ccclass, property } = _decorator;

import { windowsBase } from "../Base/windowsBase";

@ccclass
export class AdGoldLayer extends windowsBase {

    OnClickVideo() {
        g_GameMgr.GetAdvertisementMgr().SetRewardType(rewardType.addMoney);

        super.OnClickVideo();
    }
}