﻿import { _decorator, Prefab, Node, NodePool, instantiate, tween, Vec3, find } from 'cc';
const { ccclass, property } = _decorator;
import g_GameMgr from '../../common/GameMgr';
import { windowsBase } from "../Base/windowsBase";
import { blockBase } from '../Base/blockBase';
import { game } from '../Controller/game';

@ccclass
export class maxBlockLayer extends windowsBase {

    @property(Prefab)
    block: Prefab = null;
    @property(Node)
    creBlock: Node = null;
    blockPool: NodePool;
    blockList: Node[] = [];

    start() {
        this.blockPool = new NodePool();
        for (let i = 0; i < 3; i++) {
            let block = instantiate(this.block);
            this.blockPool.put(block);
        }
    }

    /** 展示突破动画
    * @param maxPower 突破后可生成最大值，2的多少次幂
    */
    ShowAction(maxPower: number) {
        for (let i = 0; i < 3; i++) {
            let block: Node = null;
            if (this.blockPool.size() > 0) {
                block = this.blockPool.get();
            } else {
                block = instantiate(this.block);
            }
            let blockTS = block.getComponent(blockBase);
            let color = g_GameMgr.GetGameDataMgr().GetColorByID(maxPower - 1 + i);
            blockTS.InitBlock(-1, -1, maxPower - 1 + i, color);
            block.parent = this.creBlock;
            this.blockList.push(block);
            if (i == 0) {
                blockTS.CreBigNode();
                block.setPosition((i + 1) * 200, 20);
                tween(block)
                    .delay(0.1)
                    .call(() => {
                        blockTS.CreShadeNode();
                    })
                    .to(0.2, { position: new Vec3(-200, 0, 0) })
                    .start();
            } else if (i == 1) {
                blockTS.CreShadeNode();
                block.setPosition((i + 1) * 200, 0);
                tween(block)
                    .delay(0.1)
                    .to(0.2, { position: new Vec3(0, 20, 0) })
                    .call(() => {
                        this.scheduleOnce(() => {
                            blockTS.CreBigNode();
                        }, 0.2)
                    })
                    .start();
            } else {
                blockTS.CreShadeNode();
                block.setPosition((i + 1) * 200, 0);
                tween(block)
                    .delay(0.1)
                    .to(0.2, { position: new Vec3(200, 0, 0) })
                    .start();
            }

        }
    }

    OnClick() {
        for (let i = 0; i < 3; i++) {
            let block = this.blockList[i];
            let blockTS = block.getComponent(blockBase);
            blockTS.CreShadeNode();
            block.setPosition(800, 0);
            this.blockPool.put(block);
        }
        this.OnClickClose();

        let minPower1 = g_GameMgr.GetGameDataMgr().GetMinPower();
        let minPower2 = g_GameMgr.GetGameDataMgr().RefreshPowerAndMaxValue();
        if (minPower1 < minPower2) {
            let gameNode = find("Canvas/Game");
            let gameTS = gameNode.getComponent(game);
            gameTS.ShowMinBlockLayer();
        }
    }
}