import { _decorator, Node, Label, Vec2, log, Button } from 'cc';
const { ccclass, property } = _decorator;
import g_GameMgr from '../../common/GameMgr';
import { My2DArray } from "../../common/My2DArray";
import { lastInterFace, rewardType } from "../../common/EnumType";
import { windowsBase } from "../Base/windowsBase";
import { blockBase } from '../Base/blockBase';

@ccclass
export class doubleLayer extends windowsBase {

    @property(Node)
    bigBlock: Node = null;
    @property(Node)
    shadeBlock: Node = null;
    @property(Node)
    shade: Node = null;
    @property(Button)
    videoButton: Button = null;
    @property(Label)
    lb_curGold: Label | null = null;
    touchBlockGrid: Vec2 | null = null;//合成的位置，翻倍的位置

    RefreshValue(touchBlockGrid: Vec2) {
        this.ShowVideoButton(g_GameMgr.GetAdvertisementMgr().IsReady());
        this.touchBlockGrid = touchBlockGrid;
        let maxValue = g_GameMgr.GetGameDataMgr().GetCurMaxValue();
        let color1 = g_GameMgr.GetGameDataMgr().GetColorByID(maxValue);
        let color2 = g_GameMgr.GetGameDataMgr().GetColorByID(maxValue - 1);
        let curGold = g_GameMgr.GetLocalDataMgr().GetGoldByLocalData();
        this.lb_curGold.string = g_GameMgr.GetGameDataMgr().SpecialValueString(curGold);

        let bigBlockTS = this.bigBlock.getComponent(blockBase);
        bigBlockTS.CreBigNode();
        bigBlockTS.InitBlock(-1, -1, maxValue, color1);

        let shadeBlockTS = this.shadeBlock.getComponent(blockBase);
        shadeBlockTS.CreShadeNode();
        shadeBlockTS.InitBlock(-1, -1, maxValue - 1, color2);
    }

    ShowVideoButton(bool: boolean) {
        this.shade.active = !bool;
        this.videoButton.enabled = bool;
    }

    OnClickVideo() {
        g_GameMgr.GetAdvertisementMgr().SetRewardType(rewardType.addMoney);
        if (g_GameMgr.GetLocalDataMgr().GetOpenVideoByLocalData()) {
            if (g_GameMgr.GetAdvertisementMgr().IsReady()) {
                g_GameMgr.GetAdvertisementMgr().ShowAd();
                this.OpenUpdate();
            } else {
                g_GameMgr.GetAdvertisementMgr().SetRewardType(rewardType.addMoney);
                log("广告没准备好");
            }
        } else {
            this.OpenUpdate();
            this.scheduleOnce(() => {
                g_GameMgr.GetAdvertisementMgr().OnReward();
            }, 0.5);
        }
    }

    OnClickPay() {
        if (g_GameMgr.GetGoldMgr().IsGoldEnough(100)) {
            g_GameMgr.GetGoldMgr().AddOrSubGold(-100);
            let curGold = g_GameMgr.GetLocalDataMgr().GetGoldByLocalData();
            this.lb_curGold.string = curGold.toString();

            let block = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(this.touchBlockGrid.y, this.touchBlockGrid.x);
            let blockTS = block.getComponent("blockBase");
            let maxValue = g_GameMgr.GetGameDataMgr().GetMaxValue();
            let color = g_GameMgr.GetGameDataMgr().GetColorByID(maxValue);
            blockTS.DoubleEffect(this.touchBlockGrid.x, this.touchBlockGrid.y, maxValue, color);
            g_GameMgr.GetGameDataMgr().blockDataList.setValue(this.touchBlockGrid.y, this.touchBlockGrid.x, maxValue);
            let blockDataList: My2DArray = g_GameMgr.GetGameDataMgr().blockDataList;
            g_GameMgr.GetLocalDataMgr().SetblockDataToLocalData(blockDataList);
        } else {
            g_GameMgr.GetGameDataMgr().lastInterFace = lastInterFace.doubleLayer;
        }

        this.OnClickClose();

    }
}
