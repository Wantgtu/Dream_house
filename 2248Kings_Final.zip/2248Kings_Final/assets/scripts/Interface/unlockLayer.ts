import { _decorator, Prefab, Node, Label, NodePool, instantiate, tween, Vec3, log, find, Button } from 'cc';
const { ccclass, property } = _decorator;
import g_GameMgr from '../../common/GameMgr';

import { rewardType } from "../../common/EnumType";
import { windowsBase } from "../Base/windowsBase";
import { blockBase } from '../Base/blockBase';
import { game } from '../Controller/game';

@ccclass
export class unlockLayer extends windowsBase {

    @property(Prefab)
    block: Prefab = null;
    @property(Node)
    creBlock: Node = null;
    @property(Node)
    pointerNode: Node = null;
    @property(Node)
    shade: Node = null;

    @property(Button)
    videoButton: Button = null;

    @property(Label)
    lb_gold: Label | null = null;
    @property(Label)
    lb_multiple: Label | null = null;
    @property({ tooltip: "箭头加速度" })
    pointerAddSpeed: number = 0;
    @property({ tooltip: "箭头初始速度" })
    pointerInitSpeed: number = 0;

    blockPool: NodePool;
    blockList: Node[] = [];
    maxValue: number = 0;
    pointerDir: number = 1;
    b_update: boolean = false;
    pointerSpeed: number = 0;

    start() {
        this.blockPool = new NodePool();
        for (let i = 0; i < 3; i++) {
            let block = instantiate(this.block);
            this.blockPool.put(block);
        }
    }

    /** 展示突破动画
    * @param maxValue 突破后的最大值，2的多少次幂
    */
    ShowAction(maxValue: number) {
        this.maxValue = maxValue;
        for (let i = 0; i < 3; i++) {
            let block: Node = null;
            if (this.blockPool.size() > 0) {
                block = this.blockPool.get();
            } else {
                block = instantiate(this.block);
            }
            let blockTS = block.getComponent(blockBase);
            let color = g_GameMgr.GetGameDataMgr().GetColorByID(maxValue - 1 + i);
            blockTS.InitBlock(-1, -1, maxValue - 1 + i, color);
            block.parent = this.creBlock;
            this.blockList.push(block);
            if (i == 0) {
                blockTS.CreBigNode();
                block.setPosition((i + 1) * 200, 20);
                tween(block)
                    .delay(0.1)
                    .call(() => {
                        blockTS.CreShadeNode();
                    })
                    .to(0.2, { position: new Vec3(-200, 0, 0) })
                    .start();
            } else if (i == 1) {
                blockTS.CreShadeNode();
                block.setPosition((i + 1) * 200, 0);
                tween(block)
                    .delay(0.1)
                    .to(0.2, { position: new Vec3(0, 20, 0) })
                    .call(() => {
                        this.scheduleOnce(() => {
                            blockTS.CreBigNode();
                        }, 0.2)
                    })
                    .start();
            } else {
                blockTS.CreShadeNode();
                block.setPosition((i + 1) * 200, 0);
                tween(block)
                    .delay(0.1)
                    .to(0.2, { position: new Vec3(200, 0, 0) })
                    .start();
            }
        }
    }

    ShowVideoButton(bool: boolean) {
        this.shade.active = !bool;
        this.videoButton.enabled = bool;
    }

    OnClickVideo() {
        this.b_update = false;
        let gold = Number(this.lb_gold.string.slice(1));
        let multiple = Number(this.lb_multiple.string);
        let money = gold * multiple;
        g_GameMgr.GetAdvertisementMgr().SetRewardMoney(money);
        g_GameMgr.GetAdvertisementMgr().SetRewardType(rewardType.timesMoney);
        if (g_GameMgr.GetLocalDataMgr().GetOpenVideoByLocalData()) {
            if (g_GameMgr.GetAdvertisementMgr().IsReady()) {
                g_GameMgr.GetAdvertisementMgr().ShowAd();
                this.OpenUpdate();
            } else {
                g_GameMgr.GetAdvertisementMgr().SetRewardType(rewardType.addMoney);
                log("广告没准备好");
            }
        } else {
            this.OpenUpdate();
            this.scheduleOnce(() => {
                g_GameMgr.GetAdvertisementMgr().OnReward();
            }, 0.5);
        }
    }

    OnClickClose() {
        super.OnClickClose();
        let gameNode = find("Canvas/Game");
        let gameTS = gameNode.getComponent(game);
        if (g_GameMgr.GetAdvertisementMgr().GetRewardType() == rewardType.addMoney) {
            let gold = Number(this.lb_gold.string.slice(1));
            g_GameMgr.GetGoldMgr().AddOrSubGold(gold);
            gameTS.ShowAddMoneyEffect(gold);
        }

        for (let i = 0; i < 3; i++) {
            let block = this.blockList[i];
            let blockTS = block.getComponent(blockBase);
            blockTS.CreShadeNode();
            block.setPosition(800, 0);
            this.blockPool.put(block);
        }
        this.pointerNode.setPosition(-230, 0);
        this.pointerDir = 1;
        this.b_update = false;

        if (this.maxValue >= 9) {
            let maxPower = this.maxValue - 4;//当前可生成最大值
            gameTS.ShowMaxBlockLayer(maxPower);
        }
    }

    OpenUpdate() {
        this.b_update = true;
    }

    update(dt) {
        if (!this.b_update) {
            return;
        }
        this.ShowVideoButton(g_GameMgr.GetAdvertisementMgr().IsReady());
        let pos = this.pointerNode.getPosition();
        if (pos.x >= 230 || pos.x <= -230) {
            if (pos.x > 230) {
                this.pointerDir = -1;
            } else {
                this.pointerDir = 1;
            }
            this.pointerSpeed = this.pointerInitSpeed;
        }
        if (pos.x > 0) {
            this.pointerSpeed += (-this.pointerAddSpeed) * this.pointerDir;
        } else {
            this.pointerSpeed += this.pointerAddSpeed * this.pointerDir;
        }

        let move = dt * this.pointerSpeed * this.pointerDir;
        let moveX = pos.x + move;
        this.pointerNode.setPosition(moveX, pos.y);
        if (Math.abs(moveX) <= 50) {
            this.lb_multiple.string = "10";
        } else if (Math.abs(moveX) <= 130) {
            this.lb_multiple.string = "8";
        } else if (Math.abs(moveX) <= 190) {
            this.lb_multiple.string = "6";
        } else if (Math.abs(moveX) <= 230) {
            this.lb_multiple.string = "3";
        }
    }
}