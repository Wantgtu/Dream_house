﻿import { _decorator, Node, sys, find } from 'cc';
const { ccclass, property } = _decorator;
import g_GameMgr from '../../common/GameMgr';
import { windowsBase } from "../Base/windowsBase";
import { game } from '../Controller/game';

@ccclass
export class mainLayer extends windowsBase {

    b_openVoice: boolean = true;//声音
    b_openShock: boolean = true;//振动
    b_openVideo: boolean = true;

    @property(Node)
    nd_voice_close: Node = null;
    @property(Node)
    nd_shock_close: Node = null;
    @property(Node)
    nd_ad_close: Node = null;

    RefreshValue() {
        this.b_openVoice = g_GameMgr.GetLocalDataMgr().GetOpenVoiceByLocalData() ? true : false;
        this.b_openShock = g_GameMgr.GetLocalDataMgr().GetOpenShockByLocalData() ? true : false;
        this.b_openVideo = g_GameMgr.GetLocalDataMgr().GetOpenVideoByLocalData() ? true : false;
        this.ShowButtonState();
        g_GameMgr.GetSounMgr().SetISOpenSound(this.b_openVoice);
        g_GameMgr.GetVibrateMgr().SetISOpenVibrate(this.b_openShock);

    }

    SetLocalData() {
        g_GameMgr.GetLocalDataMgr().SetMenuDataToLocalData(this.b_openVoice, this.b_openShock, this.b_openVideo);
    }

    ShowButtonState() {
        this.nd_voice_close.active = !this.b_openVoice;
        this.nd_shock_close.active = !this.b_openShock;
        this.nd_ad_close.active = !this.b_openVideo;
    }

    OnClickVoice() {
        this.b_openVoice = !this.b_openVoice;
        g_GameMgr.GetSounMgr().SetISOpenSound(this.b_openVoice);
        this.SetLocalData();
        this.ShowButtonState();
        g_GameMgr.GetSounMgr().PlaySound("button");
    }

    OnClickShock() {
        this.b_openShock = !this.b_openShock;
        g_GameMgr.GetVibrateMgr().SetISOpenVibrate(this.b_openShock);
        this.SetLocalData();
        this.ShowButtonState();
        g_GameMgr.GetSounMgr().PlaySound("button");
    }

    OnClickVideoOpen() {
        let gameNode = find("Canvas/Game");
        let gameTS = gameNode.getComponent(game);
        gameTS.ShowShopLayer();
        this.OnClickClose();
    }

    OnClickReset() {
        let gameNode = find("Canvas/Game");
        let gameTS = gameNode.getComponent(game);
        gameTS.SetSumScoreLB(0);
        g_GameMgr.GetLocalDataMgr().RemoveAllLocalData();
        g_GameMgr.GetGameDataMgr().SetSumScore(-1);
        g_GameMgr.GetGameDataMgr().InitBlockDataList();
        g_GameMgr.GetGameDataMgr().RecoveryAllBlockNode();
        g_GameMgr.GetGameDataMgr().CreaterAllBlockByData();
        sys.localStorage.setItem("refresh", "100");
        sys.localStorage.setItem("delete", " 100");
        sys.localStorage.setItem("exchange", "100");
        gameTS.SetItemLBGold("refresh", 100);
        gameTS.SetItemLBGold("delete", 100);
        gameTS.SetItemLBGold("exchange", 100);
        this.OnClickClose();
    }
}