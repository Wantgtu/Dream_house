import { _decorator, Node, find } from 'cc';
const { ccclass, property } = _decorator;
import g_GameMgr from '../../common/GameMgr';
import { windowsBase } from "../Base/windowsBase";
import { containerCtr } from '../Controller/containerCtr';
import { blockBase } from '../Base/blockBase';

@ccclass
export class minBlockLayer extends windowsBase {

    @property(Node)
    bigBlock: Node = null;
    @property(Node)
    shadeBlock: Node = null;

    RefreshValue() {
        let maxValue = g_GameMgr.GetGameDataMgr().GetCurMaxValue();
        let minPower = Math.floor((maxValue - 9) / 2 + 1);//当前可生成最小值,next值
        let color1 = g_GameMgr.GetGameDataMgr().GetColorByID(minPower - 1);
        let color2 = g_GameMgr.GetGameDataMgr().GetColorByID(minPower);

        let bigBlockTS = this.bigBlock.getComponent(blockBase);
        bigBlockTS.CreBigNode();
        bigBlockTS.InitBlock(-1, -1, minPower - 1, color1);

        let shadeBlockTS = this.shadeBlock.getComponent(blockBase);
        shadeBlockTS.CreShadeNode();
        shadeBlockTS.InitBlock(-1, -1, minPower, color2);
    }

    OnClickClose() {
        super.OnClickClose();
        let containerCtrNode = find("Canvas/Game/BlockContainer");
        let containerCtrTS = containerCtrNode.getComponent(containerCtr);
        containerCtrTS.DestroyAllMinValueBlock();
    }
}