import { _decorator, Node, Button, Label, log } from 'cc';
import g_GameMgr from '../../common/GameMgr';
import { windowsBase } from "../Base/windowsBase";
import { lastInterFace, rewardType } from "../../common/EnumType";
import { game } from '../Controller/game';
const { ccclass, property } = _decorator;

@ccclass
export class storeLayer extends windowsBase {

    @property(Button)
    buy: Button | null = null;
    @property(Button)
    video: Button | null = null;

    @property(Node)
    buyShade: Node | null = null;
    @property(Node)
    videoShade: Node | null = null;


    @property(Label)
    lb_countDown: Label | null = null;

    b_canWatchVideo = true;
    time: number = 0;
    countDownTime: number = 60;


    start() {
        this.RefreshValue();
    }

    RefreshValue() {
        this.countDownTime = g_GameMgr.GetLocalDataMgr().GetCountDownTime();
        if (this.countDownTime == 0) {
            this.SetISCanSeeVideo(true);
            g_GameMgr.GetAdvertisementMgr().SetTimeOver(true);
        } else {
            this.SetISCanSeeVideo(false);
            g_GameMgr.GetAdvertisementMgr().SetTimeOver(false);
        }
        if (!g_GameMgr.GetLocalDataMgr().GetOpenVideoByLocalData()) {
            this.SetCanNotBuyAdFreeButton();
        }
    }

    OnClickVideo() {
        if (g_GameMgr.GetLocalDataMgr().GetOpenVideoByLocalData()) {//是否购买了免广告
            if (g_GameMgr.GetAdvertisementMgr().IsReady() && g_GameMgr.GetAdvertisementMgr().GetTimeOver()) {//广告是否准备好
                g_GameMgr.GetAdvertisementMgr().ShowAd();
                // this.openUpdate();
            } else {
                g_GameMgr.GetAdvertisementMgr().SetRewardType(rewardType.addMoney);
                log("广告没准备好");
            }
        } else {
            this.openUpdate();
            this.scheduleOnce(() => {
                g_GameMgr.GetAdvertisementMgr().OnReward();
            }, 0.5);
        }
    }

    OnClickBuy() {
        if (1) {
            this.PayReward();
        }
    }

    OnClickClose() {
        if (g_GameMgr.GetGameDataMgr().lastInterFace == lastInterFace.doubleLayer) {
            g_GameMgr.GetGameDataMgr().lastInterFace = lastInterFace.none;
            let gameTS = this.node.parent.getComponent(game);
            gameTS.ShowDoubleLayer();
        }
        super.OnClickClose();
    }

    //免广告奖励
    PayReward() {
        g_GameMgr.GetLocalDataMgr().SetISOpenVideoToLocalData(false);
        this.SetCanNotBuyAdFreeButton();
    }

    //开启倒计时
    openUpdate() {
        g_GameMgr.GetAdvertisementMgr().SetTimeOver(false);
        g_GameMgr.GetLocalDataMgr().SetCountDownTime(60);
        this.SetISCanSeeVideo(false);
    }

    SetCanNotBuyAdFreeButton() {
        this.buy.enabled = false;
        this.buyShade.active = true;
    }

    SetISCanSeeVideo(bool: boolean) {
        this.b_canWatchVideo = bool;
        this.video.enabled = bool;
        if (bool) {
            this.lb_countDown.node.active = false;
            this.videoShade.active = false;
        } else {
            this.lb_countDown.node.active = true;
            this.videoShade.active = true;
            this.countDownTime = g_GameMgr.GetLocalDataMgr().GetCountDownTime();
        }
    }

    update(deltaTime: number) {
        if (this.b_canWatchVideo) {
            return;
        }
        this.time += deltaTime;
        let lb: string = "";
        if (this.time >= 1) {
            this.time -= 1;
            this.countDownTime -= 1;
            if (this.countDownTime < 0) {
                g_GameMgr.GetAdvertisementMgr().SetTimeOver(true);
                this.SetISCanSeeVideo(true);
                return
            }
            g_GameMgr.GetLocalDataMgr().SetCountDownTime(this.countDownTime);
            let minute = Math.floor(this.countDownTime / 60);
            let second = this.countDownTime % 60;
            if (minute < 2) {
                lb = "0";
            }
            lb += `${minute}:`;
            if (second < 2) {
                lb += "0";
            }
            lb += `${second} left`;
            this.lb_countDown.string = lb;
        }
    }
}

