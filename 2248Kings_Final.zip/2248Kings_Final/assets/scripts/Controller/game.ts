﻿import { _decorator, Component, Node, AudioSource, error, find, instantiate, Label, log, Prefab, UIOpacity, Vec2, Animation, Button } from 'cc';
import g_GameMgr from '../../common/GameMgr';

import { effectActioin, rewardType } from "../../common/EnumType";
import { colorData } from "../../common/EnumType"
import { blockBase } from '../Base/blockBase';
import { doubleLayer } from '../Interface/doubleLayer';
import { mainLayer } from '../Interface/mainLayer';
import { maxBlockLayer } from '../Interface/maxBlockLayer';
import { minBlockLayer } from '../Interface/minBlockLayer';
import { unlockLayer } from '../Interface/unlockLayer';
import { touchCtr } from './touchCtr';
import { storeLayer } from '../Interface/storeLayer';
import { effectCtr } from './effectCtr';
import { TenjinSDKMgr } from '../tenjin/TenjinSDKMgr';

const { ccclass, property } = _decorator;
@ccclass('game')
export class game extends Component {
    colorData: colorData;
    b_openVibrate: boolean = true;

    @property(Label)
    lb_sumScore: Label | null = null;
    @property(Label)
    lb_maxScore: Label | null = null;
    @property(Label)
    lb_gold: Label | null = null;
    @property(Label)
    lb_refresh: Label | null = null;
    @property(Label)
    lb_delete: Label | null = null;
    @property(Label)
    lb_exchange: Label | null = null;

    @property(Prefab)
    unlockPrefab: Prefab = null;
    @property(Prefab)
    maxBlockPrefab: Prefab = null;
    @property(Prefab)
    minBlockPrefab: Prefab = null;
    @property(Prefab)
    doubleLayerPrefab: Prefab = null;
    @property(Prefab)
    mainLayerPrefab: Prefab = null;
    @property(Prefab)
    AdGoldPrefab: Prefab = null;
    @property(Prefab)
    storePrefab: Prefab = null;
    @property(Prefab)
    addMoneyEffectPrefab: Prefab = null;

    @property(Node)
    sumBlock: Node = null;
    @property(Node)
    clearEffect: Node = null;
    @property(Node)
    effect: Node = null;
    @property(Node)
    addMoneyEffect: Node = null;
    @property(Node)
    chooseEffect1: Node = null;
    @property(Node)
    chooseEffect2: Node = null;

    @property(Button)
    addMoneyButton: Button = null;
    @property(Button)
    menuButton: Button = null;


    @property(AudioSource)
    _audioSource: AudioSource = null!;

    unlockLayer: Node;
    maxBlockLayer: Node;
    minBlockLayer: Node;
    doubleLayer: Node;
    mainLayer: Node;
    // AdGoldLayer: Node;
    storeLayer: Node;

    onLoad() {
        const audioSource = this.node.getComponent(AudioSource)!;

        this._audioSource = audioSource;

        g_GameMgr.InitAllMgr();

        // 将节点封装到管理器中
        g_GameMgr.GetSounMgr().init(this._audioSource);

        TenjinSDKMgr.init("AXEH9SYCSMECRCBZTP7EZUVQHEIYSKKS");
    }

    start() {

        g_GameMgr.GetGameDataMgr().InitGameData()

        this.SetSumScoreLB(g_GameMgr.GetGameDataMgr().GetSumScore());
        this.SetMaxScoreLB(Number(g_GameMgr.GetLocalDataMgr().GetMaxScoreByLocalData()));
        this.SetLBGold();
        this.SetItemLBGold("refresh", g_GameMgr.GetLocalDataMgr().GetGoldByItemName("refresh"));
        this.SetItemLBGold("delete", g_GameMgr.GetLocalDataMgr().GetGoldByItemName("delete"));
        this.SetItemLBGold("exchange", g_GameMgr.GetLocalDataMgr().GetGoldByItemName("exchange"));

        this.addMoneyEffect = instantiate(this.addMoneyEffectPrefab);
        this.addMoneyEffect.parent = this.effect;
        this.addMoneyEffect.active = false;

        this.unlockLayer = instantiate(this.unlockPrefab);
        this.unlockLayer.parent = this.node;
        this.unlockLayer.setPosition(800, 0);

        this.maxBlockLayer = instantiate(this.maxBlockPrefab);
        this.maxBlockLayer.parent = this.node;
        this.maxBlockLayer.setPosition(800, 0);

        this.minBlockLayer = instantiate(this.minBlockPrefab);
        this.minBlockLayer.parent = this.node;
        this.minBlockLayer.setPosition(800, 0);

        this.doubleLayer = instantiate(this.doubleLayerPrefab);
        this.doubleLayer.parent = this.node;
        this.doubleLayer.setPosition(800, 0);

        this.mainLayer = instantiate(this.mainLayerPrefab);
        this.mainLayer.parent = this.node;
        this.mainLayer.setPosition(800, 0);
        let mainLayerTS = this.mainLayer.getComponent(mainLayer);
        mainLayerTS.RefreshValue();

        // this.AdGoldLayer = instantiate(this.AdGoldPrefab);
        // this.AdGoldLayer.parent = this.node;
        // this.AdGoldLayer.setPosition(800, 0);

        this.storeLayer = instantiate(this.storePrefab);
        this.storeLayer.parent = this.node;
        this.storeLayer.setPosition(800, 0);

        this.effect.setSiblingIndex(99);
    }

    SetSumScoreLB(value: number) {
        this.lb_sumScore.string = value ? g_GameMgr.GetGameDataMgr().SpecialValueString(value) : "0";
    }

    SetMaxScoreLB(value: number) {
        this.lb_maxScore.string = value ? g_GameMgr.GetGameDataMgr().SpecialValueString(value) : "0";
    }

    SetSumBlock(active: boolean, touchBlockGridList?: Vec2[]) {
        if (!active) {
            this.sumBlock.active = false;
            this.lb_sumScore.node.getComponent(UIOpacity).opacity = 255;
            return;
        }
        this.sumBlock.active = true;
        this.lb_sumScore.node.getComponent(UIOpacity).opacity = 0;
        let sumValue = 0;
        for (let i = 0; i < touchBlockGridList.length; i++) {
            let grid = touchBlockGridList[i];
            let value = g_GameMgr.GetGameDataMgr().blockDataList.getValue(grid.y, grid.x);
            sumValue += Math.pow(2, value);
        }
        let id = Math.ceil(Math.log2(sumValue));
        let color = g_GameMgr.GetGameDataMgr().GetColorByID(id);
        let blockTS = this.sumBlock.getComponent(blockBase);
        blockTS.InitBlock(-1, -1, id, color);
    }

    SetLBGold() {
        this.lb_gold.string = g_GameMgr.GetGameDataMgr().SpecialValueString(g_GameMgr.GetGoldMgr().GetGold());
    }

    SetItemLBGold(item: string, gold: number) {
        if (item != "refresh" && item != "delete" && item != "exchange") {
            error("没有该道具");
            return null;
        }
        if (item == "refresh") {
            this.lb_refresh.string = g_GameMgr.GetGameDataMgr().SpecialValueString(gold);
        } else if (item == "delete") {
            this.lb_delete.string = g_GameMgr.GetGameDataMgr().SpecialValueString(gold);
        } else if (item == "exchange") {
            this.lb_exchange.string = g_GameMgr.GetGameDataMgr().SpecialValueString(gold);
        }
    }

    OnClickVideo() {
        let touhchLayerNode = find("Canvas/Game/BlockContainer/touchLayer")
        let touchCtrTS = touhchLayerNode.getComponent(touchCtr);
        touchCtrTS.InitCtrData(true);
        g_GameMgr.GetSounMgr().PlaySound("button");
        g_GameMgr.GetAdvertisementMgr().SetRewardType(rewardType.addMoney);
        this.ShowShopLayer();
    }

    OnClickRefresh() {
        g_GameMgr.GetSounMgr().PlaySound("button");
        let touhchLayerNode = find("Canvas/Game/BlockContainer/touchLayer")
        let touchCtrTS = touhchLayerNode.getComponent(touchCtr);
        if (!touchCtrTS.b_canTouch) {
            return;
        }
        touchCtrTS.InitCtrData(true);
        if (g_GameMgr.GetGoldMgr().IsGoldEnough(g_GameMgr.GetLocalDataMgr().GetGoldByItemName("refresh"))) {
            g_GameMgr.GetGoldMgr().AddOrSubGold(- g_GameMgr.GetLocalDataMgr().GetGoldByItemName("refresh"));
            g_GameMgr.GetLocalDataMgr().SetGoldByItemName("refresh");
            this.SetLBGold();
            this.SetItemLBGold("refresh", g_GameMgr.GetLocalDataMgr().GetGoldByItemName("refresh"));
            g_GameMgr.GetGameDataMgr().RandomAllBlock();
        }
    }

    OnClickDelete() {
        g_GameMgr.GetSounMgr().PlaySound("button");
        let touhchLayerNode = find("Canvas/Game/BlockContainer/touchLayer")
        let touchCtrTS = touhchLayerNode.getComponent(touchCtr);
        let effectCtrNode = find("Canvas/Game/BlockContainer/effect");
        let effectCtrTS = effectCtrNode.getComponent(effectCtr);
        if (!touchCtrTS.b_canTouch) {
            return;
        }
        touchCtrTS.InitCtrData(true);
        if (g_GameMgr.GetGoldMgr().IsGoldEnough(g_GameMgr.GetLocalDataMgr().GetGoldByItemName("delete"))) {
            touchCtrTS.setIsDestroy();
            effectCtrTS.CloseAllBlockChooseEffect();
            let b_destroy = touchCtrTS.b_destroy;
            this.ShowOrCloseChooseEffect(1, b_destroy);
            this.ShowOrCloseChooseEffect(2, false);
            this.ShowShade(b_destroy);
            log(`点击是否摧毁格子 b_destroy:${b_destroy}`);
        }
    }

    OnClickExChange() {
        g_GameMgr.GetSounMgr().PlaySound("button");
        let touhchLayerNode = find("Canvas/Game/BlockContainer/touchLayer")
        let touchCtrTS = touhchLayerNode.getComponent(touchCtr);
        let effectCtrNode = find("Canvas/Game/BlockContainer/effect");
        let effectCtrTS = effectCtrNode.getComponent(effectCtr);

        if (!touchCtrTS.b_canTouch) {
            return;
        }
        touchCtrTS.InitCtrData(true);
        if (g_GameMgr.GetGoldMgr().IsGoldEnough(g_GameMgr.GetLocalDataMgr().GetGoldByItemName("exchange"))) {
            touchCtrTS.setIsChange();
            effectCtrTS.CloseAllBlockChooseEffect();
            let b_exChange = touchCtrTS.b_exChange;
            this.ShowOrCloseChooseEffect(2, b_exChange);
            this.ShowOrCloseChooseEffect(1, false);
            this.ShowShade(b_exChange);
            log(`点击是否交换格子 b_exChange:${b_exChange}`);
        }
    }

    ShowShade(show: boolean) {
        // this.shade.active = show;
        this.addMoneyButton.enabled = !show;
        this.menuButton.enabled = !show;
    }

    /** 
     * *    显示或关闭选中动画
    * @param chooseNum 1:delete 2:exchange
    * @param show 是否显示动画
    * @constructor
    */
    ShowOrCloseChooseEffect(chooseNum: number, show: boolean) {
        if (chooseNum == 1) {
            let anim = this.chooseEffect1.getComponent(Animation);
            this.chooseEffect1.active = show;
            if (show) {
                anim.play("choose2");
            } else {
                anim.stop();
            }
        } else if (chooseNum == 2) {
            let anim = this.chooseEffect2.getComponent(Animation);
            this.chooseEffect2.active = show;
            if (show) {
                anim.play("choose2");
            } else {
                anim.stop();
            }
        }
    }

    ShowAddMoneyEffect(money: number) {
        g_GameMgr.GetVibrateMgr().vibrate(1.0);
        this.addMoneyEffect.active = true;
        let lb_addMoney = this.addMoneyEffect.getChildByName("lb").getComponent(Label);
        lb_addMoney.string = "+" + money.toString();
        let anim = this.addMoneyEffect.getComponent(Animation);
        anim.play("reward");
        this.scheduleOnce(() => {
            this.SetLBGold();
            g_GameMgr.GetSounMgr().PlaySound("reward");
        }, effectActioin.addMoneyTime);
    }

    /**显示突破界面 */
    ShowUnlockLayer(maxValue) {
        let unlockLayerTS = this.unlockLayer.getComponent(unlockLayer);
        if (unlockLayerTS.IsShowLayer()) {
            return;
        }
        unlockLayerTS.ShowLayer();
        unlockLayerTS.ShowAction(maxValue);
        unlockLayerTS.OpenUpdate();
    }

    /**显示可生成最大值界面 */
    ShowMaxBlockLayer(maxPower) {
        let maxBlockLayerTS = this.maxBlockLayer.getComponent(maxBlockLayer);
        if (maxBlockLayerTS.IsShowLayer()) {
            return;
        }
        maxBlockLayerTS.ShowLayer();
        maxBlockLayerTS.ShowAction(maxPower);
    }

    /**显示可生成最小值界面 */
    ShowMinBlockLayer() {
        let minBlockLayerTS = this.minBlockLayer.getComponent(minBlockLayer);
        if (minBlockLayerTS.IsShowLayer()) {
            return;
        }
        minBlockLayerTS.ShowLayer();
        minBlockLayerTS.RefreshValue();
    }

    /**显示翻倍界面 */
    ShowDoubleLayer(touchBlockGrid?: Vec2) {
        let doubleLayerTS = this.doubleLayer.getComponent(doubleLayer);
        if (doubleLayerTS.IsShowLayer()) {
            return;
        }
        doubleLayerTS.ShowLayer();
        if (touchBlockGrid) {
            doubleLayerTS.RefreshValue(touchBlockGrid);
        }
    }

    /**显示主菜单界面 */
    ShowMainLayer() {
        g_GameMgr.GetSounMgr().PlaySound("button");
        let mainLayerTS = this.mainLayer.getComponent(mainLayer);
        if (mainLayerTS.IsShowLayer()) {
            return;
        }
        mainLayerTS.ShowLayer();
        let touhchLayerNode = find("Canvas/Game/BlockContainer/touchLayer")
        let touchCtrTS = touhchLayerNode.getComponent(touchCtr);
        touchCtrTS.InitCtrData(true);
    }

    /**显示是否看广告弹窗 */
    // ShowAdGoldLayer() {
    //     let AdGoldLayerTS = this.AdGoldLayer.getComponent(AdGoldLayer);
    //     AdGoldLayerTS.ShowLayer();
    // }

    /**显示商店弹窗 */
    ShowShopLayer() {
        let storeLayerTS = this.storeLayer.getComponent(storeLayer);
        if (storeLayerTS.IsShowLayer()) {
            return;
        }
        storeLayerTS.ShowLayer();
        storeLayerTS.RefreshValue();
    }

    CloseCountDownTime(bool: boolean) {
        let storeLayerTS = this.storeLayer.getComponent(storeLayer);
        storeLayerTS.SetISCanSeeVideo(bool);
    }

    OpenADUpdate() {
        let storeLayerTS = this.storeLayer.getComponent(storeLayer);
        storeLayerTS.openUpdate();
    }

    CloseLayer(layerName: string) {
        if (layerName == "unlockLayer") {
            let unlockLayerTS = this.unlockLayer.getComponent(unlockLayer);
            unlockLayerTS.OnClickClose();
        } else if (layerName == "maxBlockLayer") {
            let maxBlockLayerTS = this.maxBlockLayer.getComponent(maxBlockLayer);
            maxBlockLayerTS.OnClickClose();
        } else if (layerName == "minBlockLayer") {
            let minBlockLayerTS = this.minBlockLayer.getComponent(minBlockLayer);
            minBlockLayerTS.OnClickClose();
        } else if (layerName == "doubleLayer") {
            let doubleLayerTS = this.doubleLayer.getComponent(doubleLayer);
            doubleLayerTS.OnClickClose();
        } else if (layerName == "mainLayer") {
            let mainLayerTS = this.mainLayer.getComponent(mainLayer);
            mainLayerTS.OnClickClose();
        }
        // else if (layerName == "AdGoldLayer") {
        //     let AdGoldLayerTS = this.AdGoldLayer.getComponent(AdGoldLayer);
        //     AdGoldLayerTS.OnClickClose();
        // } 
        else if (layerName == "storeLayer") {
            let storeLayerTS = this.storeLayer.getComponent(storeLayer);
            storeLayerTS.OnClickClose();
        }
    }
}

