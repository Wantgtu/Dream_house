﻿import { _decorator, Component, Prefab, NodePool, Vec2, error, find, instantiate, log, tween, UITransform, Vec3, warn, Node } from 'cc';
const { ccclass, property } = _decorator;
import g_GameMgr from '../../common/GameMgr';
import { clearEffect } from "../../common/EnumType";
import { My2DArray } from "../../common/My2DArray";
import { blockBase } from '../Base/blockBase';
import { effectCtr } from './effectCtr';
import { game } from './game';

@ccclass
export class containerCtr extends Component {
    @property(Prefab)
    blockPrefab: Prefab = null;
    @property(Node)
    blockContainer: Node | null = null;
    
    @property({ tooltip: "格子下落的速度" })
    blockDownSpeed: number = 0;

    blockSize: number = 0;//格子图片的边长
    blockSpaceW: number = 0;//格子之间的空隙
    blockSpaceH: number = 0;
    blockPool: NodePool;
    downBlockNodeList: My2DArray;//生成的未掉落方块暂存于此

    start() {
        this.blockPool = new NodePool();
        for (let i = 0; i < g_GameMgr.GetGameDataMgr().containerRow * g_GameMgr.GetGameDataMgr().containerCol; i++) {
            let block = instantiate(this.blockPrefab);
            this.blockPool.put(block);
        }
        let block = instantiate(this.blockPrefab);
        this.blockSize = block.getComponent(UITransform).contentSize.width;
        let uiTrans = this.blockContainer.getComponent(UITransform);
        this.blockSpaceW = (uiTrans.contentSize.width - this.blockSize * 6) / 5;
        this.blockSpaceH = (uiTrans.contentSize.height - this.blockSize * 9) / 8;
        this.downBlockNodeList = new My2DArray(9 + 1, 6, null);
    }

    createBlock(gx: number, gy: number, value: number, color: string) {
        let block: Node = null;
        if (this.blockPool.size() > 0) {
            block = this.blockPool.get();
        } else {
            block = instantiate(this.blockPrefab);
        }
        this.blockContainer.addChild(block);
        let blockBaseTS = block.getComponent(blockBase);
        blockBaseTS.InitBlock(gx, gy, value, color);
        return block;
    }

    /**格子坐标转坐标 */
    GridToPos(gx: number, gy: number): Vec3 {
        let uiTrans = this.blockContainer.getComponent(UITransform);
        let offsetX = uiTrans.contentSize.width / 2;//偏移值
        let offsetY = uiTrans.contentSize.height / 2;
        let blockSize = this.blockSize;
        let blockSpaceW = this.blockSpaceW;
        let blockSpaceH = this.blockSpaceH;

        let px = (blockSize + blockSpaceW) * (gx + 1) - (blockSize * 0.5 + blockSpaceW) - offsetX;
        let py = 0;
        if (gy < 0) {
            py = this.GetNewDownBlockValueY(-gy);
        } else {
            py = uiTrans.contentSize.height - ((blockSize + blockSpaceH) * (gy + 1) - (blockSize * 0.5 + blockSpaceH)) - offsetY;
        }

        return new Vec3(px, py, 0);
    }

    /**获取新生成未下落的方块的y值 */
    GetNewDownBlockValueY(num: number) {
        let topPosY = this.GridToPos(0, 0).y;
        return topPosY + (this.blockSpaceH + this.blockSize) * num;
    }

    /**坐标转格子坐标 */
    PosToGrid(px: number, py: number): Vec3 {
        let uiTrans = this.blockContainer.getComponent(UITransform);
        let offsetX = uiTrans.contentSize.width / 2;
        let offsetY = uiTrans.contentSize.height / 2;
        let blockSize = this.blockSize;
        let blockSpaceW = this.blockSpaceW;
        let blockSpaceH = this.blockSpaceH;

        let gx = (px + (blockSize * 0.5 + blockSpaceW) + offsetX) / (blockSize + blockSpaceW) - 1;
        let gy = (uiTrans.contentSize.height - py - offsetY + (blockSize * 0.5 + blockSpaceH)) / (blockSize + blockSpaceH) - 1;
        return new Vec3(gx, gy, 0);
    }

    /**根据格子坐标获取值 */
    GetValueByGrid(gx: number, gy: number) {
        let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(gy, gx);
        if (blockNode) {
            let blockBaseTS = blockNode.getComponent(blockBase);
            return blockBaseTS.GetValue();
        }
        error(`cannot find value in Grid(${gx},${gy})`);
    }

    /**根据格子坐标获取是否被触碰过 */
    GetIsTouchByGrid(gx: number, gy: number) {
        let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(gy, gx);
        if (blockNode) {
            let blockBaseTS = blockNode.getComponent(blockBase);
            return blockBaseTS.GetIsTouch();
        }
        error(`cannot find b_touch in Grid(${gx},${gy})`);
    }

    //通过格子坐标设置是否被触碰
    SetIsTouchByGrid(gx: number, gy: number, bool: boolean) {
        let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(gy, gx);
        if (blockNode) {
            let blockBaseTS = blockNode.getComponent(blockBase);
            if (!blockBaseTS.SetIsTouch(bool)) {
                log(`set grid(${gx},${gy}) block b_touch to ${bool}`);
            }
        }
    }

    /**遍历所有格子获取碰到格子的格子坐标*/
    GetTouchGridInAllBlock(touchPos: Vec3) {
        let containerRow = g_GameMgr.GetGameDataMgr().containerRow;//y
        let containerCol = g_GameMgr.GetGameDataMgr().containerCol;//x
        for (let y = 0; y < containerRow; y++) {
            for (let x = 0; x < containerCol; x++) {
                let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(y, x);
                let blockBaseTS = blockNode.getComponent(blockBase);
                if (blockBaseTS.TouchInBlock(touchPos)) {
                    return new Vec2(x, y);
                }
            }
        }
        return null;
    }

    /**判断触点在九个格子中，获取格子坐标*/
    GetTouchInNineCell(gx: number, gy: number, touchPos: Vec3) {
        let containerRow = g_GameMgr.GetGameDataMgr().containerRow;//y
        let containerCol = g_GameMgr.GetGameDataMgr().containerCol;//x
        for (let y = 0; y < containerRow; y++) {
            for (let x = 0; x < containerCol; x++) {
                if (y > gy + 1 || y < gy - 1 || x > gx + 1 || x < gx - 1) {
                    continue;
                }
                let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(y, x);
                let blockBaseTS = blockNode.getComponent(blockBase);
                if (blockBaseTS.TouchInBlock(touchPos)) {
                    return new Vec2(x, y);
                }
            }
        }
        return null;
    }

    /**销毁某个方块 */
    DestroyOneBlock(gx: number, gy: number) {
        let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(gy, gx);
        this.blockPool.put(blockNode);
        g_GameMgr.GetGameDataMgr().blockNodeList.setValue(gy, gx, null);
    }

    /**销毁所有值小于当前能生成的最小值的方块 */
    DestroyAllMinValueBlock() {
        let maxValue = g_GameMgr.GetGameDataMgr().GetCurMaxValue();
        let minPower = Math.floor((maxValue - 10 - 1) / 2 + 2);
        let containerRow = g_GameMgr.GetGameDataMgr().containerRow;//y
        let containerCol = g_GameMgr.GetGameDataMgr().containerCol;//x
        let b_down = false;
        let blockPosList: Vec3[] = [];
        let colorList: string[] = [];
        for (let y = 0; y < containerRow; y++) {
            for (let x = 0; x < containerCol; x++) {
                let value = g_GameMgr.GetGameDataMgr().blockDataList.getValue(y, x);
                if (value < minPower) {
                    b_down = true;
                    let pos = this.GridToPos(x, y);
                    let block = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(y, x);
                    let blockTS = block.getComponent(blockBase);
                    let color = blockTS.GetColor();

                    this.DestroyOneBlock(x, y);
                    blockPosList.push(pos);
                    colorList.push(color);
                }
            }
        }
        if (b_down) {
            let effectCtrNode = find("Canvas/Game/BlockContainer/effect");
            let effectCtrTS = effectCtrNode.getComponent(effectCtr);
            effectCtrTS.ShowDestoryEffect(blockPosList, colorList);

            this.scheduleOnce(() => {
                effectCtrTS.RecoveryDestoryEffectNode();
                this.BlockCreateAndDownPrePare();
            }, clearEffect.destoryTime);
        }
    }

    /**消除并合成方块 */
    ClearBlockAndCreSumBlock(touchBlockGrid: Vec2) {
        let containerRow = g_GameMgr.GetGameDataMgr().containerRow;//y
        let containerCol = g_GameMgr.GetGameDataMgr().containerCol;//x
        let sumValue = 0;//合成的值
        for (let y = 0; y < containerRow; y++) {
            for (let x = 0; x < containerCol; x++) {
                let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(y, x);
                let blockBaseTS = blockNode.getComponent(blockBase);
                if (blockBaseTS.GetIsTouch()) {
                    blockBaseTS.SetIsTouch(false);//被对象池回收，并不会修改节点的相关值，必须手动修改
                    sumValue += Math.pow(2, blockBaseTS.GetValue());
                    this.blockPool.put(blockNode);
                    g_GameMgr.GetGameDataMgr().blockNodeList.setValue(y, x, null);
                }
            }
        }
        let id = Math.ceil(Math.log2(sumValue));
        let maxValue = g_GameMgr.GetGameDataMgr().GetCurMaxValue();
        let gameNode = find("Canvas/Game");
        let gameTS = gameNode.getComponent(game);
        let color = g_GameMgr.GetGameDataMgr().GetColorByID(id);

        g_GameMgr.GetGameDataMgr().SetSumScore(id);
        g_GameMgr.GetLocalDataMgr().SetScoreToLocalData(g_GameMgr.GetGameDataMgr().GetSumScore());
        gameTS.SetSumScoreLB(g_GameMgr.GetGameDataMgr().GetSumScore());
        gameTS.SetMaxScoreLB(Number(g_GameMgr.GetLocalDataMgr().GetMaxScoreByLocalData()));

        this.scheduleOnce(() => {
            let effectCtrNode = find("Canvas/Game/BlockContainer/effect");
            let effectCtrTS = effectCtrNode.getComponent(effectCtr);
            effectCtrTS.RecoveryClearEffectNode();

            let node = this.createBlock(touchBlockGrid.x, touchBlockGrid.y, id, color);
            node.setPosition(this.GridToPos(touchBlockGrid.x, touchBlockGrid.y));
            g_GameMgr.GetGameDataMgr().blockNodeList.setValue(touchBlockGrid.y, touchBlockGrid.x, node);
            this.BlockCreateAndDownPrePare();

            if (maxValue >= 10 && id + 1 == maxValue) {
                gameTS.ShowDoubleLayer(touchBlockGrid);
            }
        }, clearEffect.actionTime);
    }

    /**方块生成与下落准备 */
    BlockCreateAndDownPrePare() {
        let containerRow = g_GameMgr.GetGameDataMgr().containerRow;//y
        let containerCol = g_GameMgr.GetGameDataMgr().containerCol;//x
        let b_changeData = false;//数据是否修改
        let isHaveNull = false;//这列有没有被消掉的
        let haveNullNum = 0;
        let nullList: Vec2[] = [];
        let needDownblockList: Vec2[] = [];
        for (let x = 0; x < containerCol; x++) {
            isHaveNull = false;
            haveNullNum = 0;
            nullList = [];
            needDownblockList = [];
            for (let y = containerRow - 1; y >= 0; y--) {
                if (g_GameMgr.GetGameDataMgr().blockNodeList.getValue(y, x) == null) {
                    isHaveNull = true;
                    haveNullNum += 1;
                    nullList.push(new Vec2(x, y));
                }
            }
            if (isHaveNull) {
                b_changeData = true;
                let targetLocationList: Vec2[] = [];
                for (let y = nullList[0].y; y >= 0; y--) {
                    targetLocationList.push(new Vec2(x, y));
                    if (g_GameMgr.GetGameDataMgr().blockNodeList.getValue(y, x) != null) {
                        needDownblockList.push(new Vec2(x, y));
                    }
                }
                for (let i = 1; i <= haveNullNum; i++) {
                    let id = g_GameMgr.GetGameDataMgr().RandomInRange();//随机获取
                    let color = g_GameMgr.GetGameDataMgr().GetColorByID(id);
                    let node = this.createBlock(x, -i, id, color);
                    node.setPosition(this.GridToPos(x, -i));
                    this.downBlockNodeList.setValue(i, x, node);//暂存与容器中
                    needDownblockList.push(new Vec2(x, -i));
                }
                this.BlockDownAction(targetLocationList, needDownblockList, x);
            }
        }

        if (b_changeData) {
            g_GameMgr.GetGameDataMgr().SetAllBlockDataByNodeList();
            g_GameMgr.GetGameDataMgr().ShowMaxBlock();
            let blockDataList: My2DArray = g_GameMgr.GetGameDataMgr().blockDataList;
            g_GameMgr.GetLocalDataMgr().SetblockDataToLocalData(blockDataList);
        } else {
            warn(`g_GameDataMgr.blockNodeList 没有找到空值`);
        }
    }

    /**方块下落
    * @param targetLocationList 下落目标位置
    * @param needDownblockList 未下落方块位置
    * @param x 第几列
    */
    BlockDownAction(targetLocationList: Vec2[], needDownblockList: Vec2[], gx?: number) {
        if (targetLocationList.length != needDownblockList.length) {
            error(`下落出现未知错误 targetLocationList.length${targetLocationList.length} needDownblockList.length${needDownblockList.length}`);
            return;
        }
        let x = gx ? gx : targetLocationList[0].x || needDownblockList[0].x;
        for (let i = 0; i < needDownblockList.length; i++) {
            let targetGrid = targetLocationList[i];
            let endPos = this.GridToPos(x, targetGrid.y);
            let blockNodeGrid = needDownblockList[i];
            let startPos = this.GridToPos(x, blockNodeGrid.y);
            let actionTime = (startPos.y - endPos.y) / this.blockDownSpeed;//下落动作所花的时间
            let node: Node = null;
            if (blockNodeGrid.y < 0) {
                node = this.downBlockNodeList.getValue(-blockNodeGrid.y, x);
                let blockBaseTS = node.getComponent(blockBase);
                blockBaseTS.SetVecInContainer(x, targetGrid.y);
                g_GameMgr.GetGameDataMgr().blockNodeList.setValue(targetGrid.y, x, null);
                g_GameMgr.GetGameDataMgr().blockNodeList.setValue(targetGrid.y, x, node);
                tween(node)
                    .to(actionTime, { position: endPos })
                    .start();
            } else {
                node = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(blockNodeGrid.y, x);
                g_GameMgr.GetGameDataMgr().blockNodeList.setValue(targetGrid.y, x, node);
                tween(node)
                    .to(actionTime, { position: endPos })
                    .start();
            }
        }
        this.downBlockNodeList = new My2DArray(9 + 1, 6, null);
    }

    //变大
    PlayTouchAction(touchGrid: Vec2) {
        g_GameMgr.GetSounMgr().playBiggerSound();
        let containerRow = g_GameMgr.GetGameDataMgr().containerRow;//y
        let containerCol = g_GameMgr.GetGameDataMgr().containerCol;//x
        for (let y = 0; y < containerRow; y++) {
            for (let x = 0; x < containerCol; x++) {
                if (touchGrid.x == x && touchGrid.y == y) {
                    let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(y, x);
                    let blockBaseTS = blockNode.getComponent(blockBase);
                    blockBaseTS.PlayAction();
                }
            }
        }
    }

    /** 刷新动画，数据blockDataList随机后调用*/
    RandomRefreshAction() {
        let containerRow = g_GameMgr.GetGameDataMgr().containerRow;//y
        let containerCol = g_GameMgr.GetGameDataMgr().containerCol;//x
        for (let y = 0; y < containerRow; y++) {
            for (let x = 0; x < containerCol; x++) {
                let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(y, x);
                let blcokTS = blockNode.getComponent(blockBase);
                let value = g_GameMgr.GetGameDataMgr().blockDataList.getValue(y, x);//随机后的值
                let color = g_GameMgr.GetGameDataMgr().GetColorByID(value);
                tween(blockNode)
                    .to(0.5, { position: new Vec3(0, 0, 0) })
                    .by(0.5, { angle: -360 })
                    .call(() => {
                        blcokTS.InitBlock(x, y, value, color);
                        g_GameMgr.GetGameDataMgr().ShowMaxBlock();
                    })
                    .to(0.5, { position: this.GridToPos(x, y) })
                    .start();
            }
        }
    }
}