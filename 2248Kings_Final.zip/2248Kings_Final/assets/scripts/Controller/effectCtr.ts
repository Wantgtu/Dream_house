import { _decorator, Component, Prefab, NodePool, Node, Vec2, Color, error, instantiate, Tween, tween, Vec3, Animation } from 'cc';
const { ccclass, property } = _decorator;
import { clearEffect, effectActioin } from "../../common/EnumType";
import { effectBase } from '../Base/effectBase';

@ccclass
export class effectCtr extends Component {

    @property(Prefab)
    clearEffectPrefab: Prefab = null;
    @property(Prefab)
    destoryEffectPrefab: Prefab = null;
    @property(Prefab)
    hammerPrefab: Prefab = null;
    @property(Prefab)
    choosePrefab: Prefab = null;

    clearEffectPool: NodePool;
    clearEffectNodeList: Node[] = [];
    destoryEffectPool: NodePool;
    destoryEffectNodeList: Node[] = [];
    chooseNodelist: Node[] = [];
    // showChoosePosList: Vec3[] = [];
    nd_hammer: Node | null = null;

    start() {
        this.node.setSiblingIndex(99);
        this.clearEffectPool = new NodePool();
        this.destoryEffectPool = new NodePool();
        for (let i = 0; i < 6 * 9; i++) {
            let effect = instantiate(this.clearEffectPrefab);
            let effect2 = instantiate(this.destoryEffectPrefab);
            this.clearEffectPool.put(effect);
            this.destoryEffectPool.put(effect2);
        }

        this.nd_hammer = instantiate(this.hammerPrefab);
        this.nd_hammer.parent = this.node;
        this.nd_hammer.setPosition(new Vec3(0, 0, 0));
        this.nd_hammer.active = false;

        for (let i = 0; i < 2; i++) {
            let node = instantiate(this.choosePrefab);
            node.parent = this.node;
            node.setPosition(new Vec3(0, 0, 0));
            node.active = false;
            this.chooseNodelist.push(node);
        }
    }

    ShowHammerEffect(blockPos: Vec3, color: string) {
        this.nd_hammer.active = true;
        this.nd_hammer.setPosition(blockPos);
        let anim1 = this.nd_hammer.getComponent(Animation);
        anim1.play("delete");

        let effect: Node = null;
        if (this.clearEffectPool.size() > 0) {
            effect = this.clearEffectPool.get();
        } else {
            effect = instantiate(this.clearEffectPrefab);
        }
        effect.parent = this.node;
        effect.setPosition(blockPos);
        this.nd_hammer.setSiblingIndex(99);
        this.clearEffectNodeList.push(effect);

        let effectTS = effect.getComponent(effectBase);
        let anim2 = effect.getComponent(Animation);
        effectTS.SetColor(color);
        anim2.play("blockDestory2");

        this.scheduleOnce(() => {
            this.nd_hammer.active = false;
        }, effectActioin.hammerTime);
    }

    //播放或关闭格子选中动画
    ShowOrCloseBlockChooseEffect(pos: Vec3, isChoose: boolean) {
        if (isChoose) {
            for (var i = 0; i < this.chooseNodelist.length; i++) {
                if (this.chooseNodelist[i].getPosition().strictEquals(new Vec3(0, 0, 0))) {
                    this.chooseNodelist[i].active = true;
                    this.chooseNodelist[i].setPosition(pos);
                    let anim = this.chooseNodelist[i].getComponent(Animation);
                    anim.play("choose");
                    return;
                }
            }
        } else {
            for (var i = 0; i < this.chooseNodelist.length; i++) {
                if (this.chooseNodelist[i].getPosition().strictEquals(pos)) {
                    let anim = this.chooseNodelist[i].getComponent(Animation);
                    anim.stop();
                    this.chooseNodelist[i].setPosition(new Vec3(0, 0, 0));
                    this.chooseNodelist[i].active = false;
                }
            }
        }
    }

    CloseAllBlockChooseEffect() {
        for (let i = 0; i < this.chooseNodelist.length; i++) {
            let anim = this.chooseNodelist[i].getComponent(Animation);
            anim.stop();
            this.chooseNodelist[i].setPosition(new Vec3(0, 0, 0));
            this.chooseNodelist[i].active = false;
        }
    }

    ShowClearEffct(touchBlockPosList: Vec3[], colorList: string[], targetColor: Color) {
        if (touchBlockPosList.length != colorList.length) {
            error(`touchBlockPosList.length${touchBlockPosList.length} != colorList.length${colorList.length}`);
            return;
        }
        for (let i = 0; i < touchBlockPosList.length; i++) {
            let effect: Node = null;
            if (this.clearEffectPool.size() > 0) {
                effect = this.clearEffectPool.get();
            } else {
                effect = instantiate(this.clearEffectPrefab);
            }
            effect.parent = this.node;
            effect.setPosition(touchBlockPosList[i]);
            this.clearEffectNodeList.push(effect);

            let effectTS = effect.getComponent(effectBase);
            let anim = effect.getComponent(Animation);
            effectTS.SetColor(colorList[i]);
            if (i == touchBlockPosList.length - 1) {
                anim.play("blockBoom2");
            } else {
                anim.play("blockBoom");
            }
        }
        let length = this.clearEffectNodeList.length;
        let moveTime = clearEffect.moveTime / (length - 1);//每段移动时间
        for (let i = 0; i < length; i++) {
            let num = length - (i + 1);//移动几段位置
            if (num > 1) {
                let tweenList: Tween<Node>[] = [];
                for (let j = i + 1; j < length; j++) {
                    let action = tween(this.clearEffectNodeList[i]).to(moveTime, { position: touchBlockPosList[j] });
                    tweenList.push(action);
                }
                tween(this.clearEffectNodeList[i])
                    .delay(clearEffect.biggerTime)
                    .call(() => {
                        let effectBaseTs = this.clearEffectNodeList[i].getComponent(effectBase);
                        effectBaseTs.ChangeColorAction(targetColor);
                    })
                    .sequence(...tweenList)
                    .start();
                //.call要放在.sequence前，不然报错？？？
            }
        }

        tween(this.clearEffectNodeList[length - 2])
            .delay(clearEffect.biggerTime)
            .call(() => {
                this.clearEffectNodeList[length - 2].getComponent(effectBase).ChangeColorAction(targetColor);
            })
            .to(moveTime, { position: touchBlockPosList[length - 1] })
            .start();
        tween(this.clearEffectNodeList[length - 1])
            .delay(clearEffect.biggerTime)
            .call(() => {
                this.clearEffectNodeList[length - 1].getComponent(effectBase).ChangeColorAction(targetColor);
            })
            .start()
    }

    ShowDestoryEffect(blockPosList: Vec3[], colorList: string[]) {
        if (blockPosList.length != colorList.length) {
            error(`blockPosList.length${blockPosList.length} != colorList.length${colorList.length}`);
            return;
        }
        for (let i = 0; i < blockPosList.length; i++) {
            let effect: Node = null;
            if (this.destoryEffectPool.size() > 0) {
                effect = this.destoryEffectPool.get();
            } else {
                effect = instantiate(this.destoryEffectPrefab);
            }
            effect.parent = this.node;
            effect.setPosition(blockPosList[i]);
            this.destoryEffectNodeList.push(effect);

            let effectTS = effect.getComponent(effectBase);
            let anim = effect.getComponent(Animation);
            effectTS.SetColor(colorList[i]);
            anim.play("blockDestory");
        }
    }

    RecoveryClearEffectNode() {
        for (let i = 0; i < this.clearEffectNodeList.length; i++) {
            this.clearEffectNodeList[i].setPosition(9999, 9999);
            this.clearEffectPool.put(this.clearEffectNodeList[i]);
        }
        this.clearEffectNodeList = [];
    }

    RecoveryDestoryEffectNode() {
        for (let i = 0; i < this.destoryEffectNodeList.length; i++) {
            this.destoryEffectNodeList[i].setPosition(9999, 9999);
            this.destoryEffectPool.put(this.destoryEffectNodeList[i]);
        }
        this.destoryEffectNodeList = [];
    }

}