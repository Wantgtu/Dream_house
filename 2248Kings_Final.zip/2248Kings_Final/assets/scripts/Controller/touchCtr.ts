﻿import { _decorator, Component, Prefab, Vec2, NodePool, Node, Camera, director, EventTouch, find, instantiate, log, Sprite, UITransform, v3, Vec3, Game, tween } from 'cc';
const { ccclass, property } = _decorator;
import g_GameMgr from '../../common/GameMgr';
import g_CommonTool from "../../common/CommonTool";
import { game } from './game';

import { scaleAction, clearEffect, effectActioin } from "../../common/EnumType"
import { containerCtr } from './containerCtr';
import { blockBase } from '../Base/blockBase';
import { effectCtr } from './effectCtr';

@ccclass
export class touchCtr extends Component {

    @property(Prefab)
    linePrefab: Prefab = null;

    @property({ tooltip: "连线超过多少条时奖励金币" })
    lineNum: number = 0;
    @property({ tooltip: "奖励多少金币" })
    addMoney: number = 0;

    b_canTouch: boolean = true;//能否触摸
    b_Touch: boolean = false;//是否触碰到格子
    b_destroy: boolean = false;//是否摧毁格子
    b_exChange: boolean = false;//是否交换格子
    touchBlockGrid: Vec2;//最后碰过的格子坐标，未加入容器，最后合成的位置
    touchBlockGridList: Vec2[] = [];//碰过的格子坐标
    linePool: NodePool;
    lineNodeList: Node[] = [];
    lineNodeListIndex: number = 0;
    beforeMaxValue: Number = 0;//消除之前的最大值

    start() {
        this.linePool = new NodePool();
        for (let i = 0; i < 6 * 9 - 1; i++) {
            let line = instantiate(this.linePrefab);
            this.linePool.put(line);
        }
        this.node.on(Node.EventType.TOUCH_START, this.touchStart, this)
        this.node.on(Node.EventType.TOUCH_MOVE, this.touchMove, this)
        this.node.on(Node.EventType.TOUCH_END, this.touchEnd, this)
        this.node.on(Node.EventType.TOUCH_CANCEL, this.touchEnd, this)
    }

    setIsDestroy() {
        this.b_destroy = !this.b_destroy;
        this.b_exChange = false;
        this.touchBlockGridList = [];
    }

    setIsChange() {
        this.b_exChange = !this.b_exChange;
        this.b_destroy = false;
        this.touchBlockGridList = [];
    }

    touchStart(event: EventTouch) {
        if (!this.b_canTouch) {
            return;
        }
        this.InitCtrData(true);

        let gameNode = find("Canvas/Game");
        let gameTS = gameNode.getComponent(game);
        let containerCtrNode = find("Canvas/Game/BlockContainer");
        let containerCtrTS = containerCtrNode.getComponent(containerCtr);
        let effectCtrNode = find("Canvas/Game/BlockContainer/effect");
        let effectCtrTS = effectCtrNode.getComponent(effectCtr);

        let location = event.getLocation();
        let camera = director.getScene().getComponentInChildren(Camera);
        let worldPos = camera.screenToWorld(v3(location.x, location.y));
        let gridPos = containerCtrNode.getComponent(UITransform).convertToNodeSpaceAR(worldPos);
        let touchBlockGrid = containerCtrTS.GetTouchGridInAllBlock(gridPos);//触碰到格子的格子坐标

        if (!touchBlockGrid) {//有没有碰到格子
            this.b_Touch = false;
            return;
        }

        if (this.b_destroy) {//是否摧毁格子
            this.b_destroy = false;
            this.b_Touch = false;
            gameTS.ShowOrCloseChooseEffect(1, false);
            gameTS.ShowShade(this.b_destroy);
            let maxValue = g_GameMgr.GetGameDataMgr().GetMaxValue();
            let value = g_GameMgr.GetGameDataMgr().blockDataList.getValue(touchBlockGrid.y, touchBlockGrid.x);
            if (value >= maxValue) {
                return;
            }
            let color = g_GameMgr.GetGameDataMgr().GetColorByID(value);
            let pos = containerCtrTS.GridToPos(touchBlockGrid.x, touchBlockGrid.y);

            containerCtrTS.DestroyOneBlock(touchBlockGrid.x, touchBlockGrid.y);
            effectCtrTS.ShowHammerEffect(pos, color);
            this.scheduleOnce(() => {
                effectCtrTS.RecoveryClearEffectNode();
                containerCtrTS.BlockCreateAndDownPrePare();
            }, clearEffect.destoryTime2 + effectActioin.hammerTime);

            g_GameMgr.GetGoldMgr().AddOrSubGold(- g_GameMgr.GetLocalDataMgr().GetGoldByItemName("delete"));
            g_GameMgr.GetLocalDataMgr().SetGoldByItemName("delete");
            gameTS.SetLBGold();
            gameTS.SetItemLBGold("delete", g_GameMgr.GetLocalDataMgr().GetGoldByItemName("delete"));
            return;
        }

        if (this.b_exChange) {
            let list = [];
            let push: boolean = true;
            for (let i = 0; i < this.touchBlockGridList.length; i++) {
                if (this.touchBlockGridList[i].x == touchBlockGrid.x && this.touchBlockGridList[i].y == touchBlockGrid.y) {
                    effectCtrTS.ShowOrCloseBlockChooseEffect(containerCtrTS.GridToPos(touchBlockGrid.x, touchBlockGrid.y), false);
                    push = false;
                } else {
                    list.push(this.touchBlockGridList[i]);
                }
            }
            if (push) {
                effectCtrTS.ShowOrCloseBlockChooseEffect(containerCtrTS.GridToPos(touchBlockGrid.x, touchBlockGrid.y), true);
                this.touchBlockGridList.push(touchBlockGrid);
            } else {
                this.touchBlockGridList = list;
                return;
            }

            // containerCtrTS.PlayTouchAction(touchBlockGrid);//变大
            if (this.touchBlockGridList.length > 1) {
                this.b_exChange = false;
                let firstNodeGrid = this.touchBlockGridList[0];
                let secondNodeGrid = this.touchBlockGridList[1];
                let firstNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(firstNodeGrid.y, firstNodeGrid.x);
                let secondNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(secondNodeGrid.y, secondNodeGrid.x);
                let firstNodeTS = firstNode.getComponent(blockBase);
                let secondNodeTS = secondNode.getComponent(blockBase);
                let firstNodePos = firstNode.getPosition();
                let secondNodePos = secondNode.getPosition();

                g_GameMgr.GetGameDataMgr().blockNodeList.setValue(firstNodeGrid.y, firstNodeGrid.x, secondNode);
                g_GameMgr.GetGameDataMgr().blockNodeList.setValue(secondNodeGrid.y, secondNodeGrid.x, firstNode);
                firstNodeTS.SetVecInContainer(secondNodeGrid.x, secondNodeGrid.y);
                secondNodeTS.SetVecInContainer(firstNodeGrid.x, firstNodeGrid.y);
                g_GameMgr.GetGameDataMgr().SetAllBlockDataByNodeList();
                this.touchBlockGridList = [];

                this.scheduleOnce(() => {
                    tween(firstNode)
                        .parallel(
                            tween(firstNode).to(effectActioin.exchangeTime, { position: secondNodePos }),
                            tween(firstNode).by(effectActioin.exchangeTime, { angle: -360 })
                        )
                        .start();
                    tween(secondNode)
                        .parallel(
                            tween(secondNode).to(effectActioin.exchangeTime, { position: firstNodePos }),
                            tween(secondNode).by(effectActioin.exchangeTime, { angle: -360 })
                        )
                        .start();
                    effectCtrTS.CloseAllBlockChooseEffect();
                }, effectActioin.exchangeTime);

                g_GameMgr.GetGoldMgr().AddOrSubGold(- g_GameMgr.GetLocalDataMgr().GetGoldByItemName("exchange"));
                g_GameMgr.GetLocalDataMgr().SetGoldByItemName("exchange");
                gameTS.SetLBGold();
                gameTS.ShowShade(this.b_exChange);
                gameTS.SetItemLBGold("exchange", g_GameMgr.GetLocalDataMgr().GetGoldByItemName("exchange"));
                gameTS.ShowOrCloseChooseEffect(2, false);
            }
            this.b_Touch = false;
            return;
        }

        this.b_Touch = true;
        this.touchBlockGrid = touchBlockGrid;
        this.touchBlockGridList.push(touchBlockGrid);

        let line = this.getOrCreNode();
        let touchBlockPos = containerCtrTS.GridToPos(touchBlockGrid.x, touchBlockGrid.y);//触碰到格子的坐标
        this.creOrSetConnection(touchBlockPos, touchBlockPos, line);//创建新连线

        log(`点击格子的格子坐标 touchBlockGrid:${touchBlockGrid}`)
        log(`触碰到格子的坐标 touchBlockGrid:${touchBlockPos}`)

        containerCtrTS.PlayTouchAction(touchBlockGrid);//变大
    }

    touchMove(event) {
        if (!this.b_canTouch) {
            return;
        }
        if (!this.b_Touch) {
            return;
        }
        if (!this.touchBlockGrid) {
            return;
        }
        let containerCtrNode = find("Canvas/Game/BlockContainer");
        let containerCtrTS = containerCtrNode.getComponent(containerCtr);
        let startPos = containerCtrTS.GridToPos(this.touchBlockGrid.x, this.touchBlockGrid.y);
        let pos = event.getLocation();
        let camera = director.getScene().getComponentInChildren(Camera);
        let worldPos = camera.screenToWorld(v3(pos.x, pos.y));
        let touchPos = containerCtrNode.getComponent(UITransform).convertToNodeSpaceAR(worldPos);
        let touchBlockGrid = containerCtrTS.GetTouchInNineCell(this.touchBlockGrid.x, this.touchBlockGrid.y, touchPos);
        if (touchBlockGrid) {//在九个格子中
            if (this.touchBlockGrid.x == touchBlockGrid.x && this.touchBlockGrid.y == touchBlockGrid.y) {
                this.creOrSetConnection(startPos, touchPos);
                return;
            }
            if (this.touchBlockGridList[this.touchBlockGridList.length - 1].x == touchBlockGrid.x
                && this.touchBlockGridList[this.touchBlockGridList.length - 1].y == touchBlockGrid.y) {//连回上一个取消连线
                containerCtrTS.SetIsTouchByGrid(this.touchBlockGrid.x, this.touchBlockGrid.y, false);
                let length = this.lineNodeList.length
                this.lineNodeList[length - 1].setPosition(9999, 9999);
                this.lineNodeList[length - 1].getComponent(UITransform).width = 0;
                this.lineNodeList[length - 1].angle = 0;//被对象池回收，并不会修改节点的相关值，必须手动修改
                this.linePool.put(this.lineNodeList[length - 1]);
                this.lineNodeList.pop();
                if (length > 1) {
                    this.lineNodeList[length - 2].setPosition(9999, 9999);
                    this.lineNodeList[length - 2].getComponent(UITransform).width = 0;
                    this.lineNodeList[length - 2].angle = 0;//被对象池回收，并不会修改节点的相关值，必须手动修改
                    this.linePool.put(this.lineNodeList[length - 2]);
                    this.lineNodeList.pop();
                }
                containerCtrTS.PlayTouchAction(this.touchBlockGrid);//变大
                this.lineNodeListIndex = this.lineNodeListIndex - 1 < 0 ? 0 : this.lineNodeListIndex - 1;
                this.touchBlockGrid = this.touchBlockGridList[this.touchBlockGridList.length - 1];
                if (this.touchBlockGridList[0].x != this.touchBlockGrid.x || this.touchBlockGridList[0].y != this.touchBlockGrid.y) {//特殊情况第一格不要删掉
                    this.touchBlockGridList.pop();
                }
                this.CreSumBlock(this.touchBlockGridList, this.touchBlockGrid);//创建上方显示的合成值

                let line = this.getOrCreNode();
                let touchBlockPos = containerCtrTS.GridToPos(touchBlockGrid.x, touchBlockGrid.y);//触碰到格子的坐标
                this.creOrSetConnection(touchBlockPos, touchBlockPos, line);//创建新连线
                // g_GameMgr.GetSounMgr().SubConnectionSoundNum();  
                return;
            }
            let curValue = containerCtrTS.GetValueByGrid(this.touchBlockGrid.x, this.touchBlockGrid.y);//上一个值
            let touchValue = containerCtrTS.GetValueByGrid(touchBlockGrid.x, touchBlockGrid.y);//碰到的值
            if ((touchValue == curValue || (touchValue == curValue + 1 && this.lineNodeListIndex > 0))
                && (!containerCtrTS.GetIsTouchByGrid(touchBlockGrid.x, touchBlockGrid.y))) {//判断是否能连
                let endPos = containerCtrTS.GridToPos(touchBlockGrid.x, touchBlockGrid.y);
                let line = this.getOrCreNode();
                let touchBlockPos = containerCtrTS.GridToPos(touchBlockGrid.x, touchBlockGrid.y);//触碰到格子的坐标

                containerCtrTS.PlayTouchAction(touchBlockGrid);//变大
                containerCtrTS.SetIsTouchByGrid(this.touchBlockGrid.x, this.touchBlockGrid.y, true);
                containerCtrTS.SetIsTouchByGrid(touchBlockGrid.x, touchBlockGrid.y, true);

                if (this.touchBlockGridList[0].x != this.touchBlockGrid.x || this.touchBlockGridList[0].y != this.touchBlockGrid.y) {//特殊情况第一格不要存俩次
                    this.touchBlockGridList.push(this.touchBlockGrid);
                }
                this.touchBlockGrid = touchBlockGrid;
                this.creOrSetConnection(startPos, endPos);//固定连线
                this.CreSumBlock(this.touchBlockGridList, this.touchBlockGrid);//创建上方显示的合成值
                this.creOrSetConnection(touchBlockPos, touchBlockPos, line);//创建新连线
                this.lineNodeListIndex += 1;
            } else {
                this.creOrSetConnection(startPos, touchPos);
            }
        } else {
            this.creOrSetConnection(startPos, touchPos);
        }
    }

    touchEnd(event) {
        if (!this.b_canTouch) {
            return;
        }
        if (!this.b_Touch) {
            return;
        }
        if (!this.touchBlockGrid) {
            return;
        }
        this.b_Touch = false;
        let containerCtrNode = find("Canvas/Game/BlockContainer");
        let containerCtrTS = containerCtrNode.getComponent(containerCtr);
        let gameNode = find("Canvas/Game");
        let gameTS = gameNode.getComponent(game);
        gameTS.SetSumBlock(false);

        if (this.lineNodeListIndex > 0) {
            if (this.lineNodeListIndex >= this.lineNum) {
                g_GameMgr.GetGoldMgr().AddOrSubGold(this.addMoney);
                this.scheduleOnce(() => {
                    gameTS.ShowAddMoneyEffect(this.addMoney);
                }, clearEffect.actionTime);
            }
            this.b_canTouch = false;
            this.beforeMaxValue = g_GameMgr.GetGameDataMgr().GetCurMaxValue();
            this.scheduleOnce(() => {//每次操作间隔，判断是否突破
                this.b_canTouch = true;
                let maxValue2 = g_GameMgr.GetGameDataMgr().GetCurMaxValue();
                if (this.beforeMaxValue < maxValue2) {//&& maxValue2 >= 9
                    gameTS.ShowUnlockLayer(maxValue2);
                }
            }, clearEffect.operation);
            if (this.touchBlockGrid != this.touchBlockGridList[0]) {
                this.ShowClearEffect(this.touchBlockGridList, this.touchBlockGrid);
                containerCtrTS.ClearBlockAndCreSumBlock(this.touchBlockGrid);
            }

            if (this.lineNodeListIndex <= 2) {
                g_GameMgr.GetSounMgr().PlaySound("compose");
            } else if (this.lineNodeListIndex <= 5) {
                g_GameMgr.GetSounMgr().PlaySound("compose1");
            } else if (this.lineNodeListIndex <= 8) {
                g_GameMgr.GetSounMgr().PlaySound("compose2");
            } else {
                g_GameMgr.GetSounMgr().playBiggerSound();
                g_GameMgr.GetSounMgr().playBiggerSound();
                g_GameMgr.GetSounMgr().playBiggerSound();
            }
        } else {//若松开时一条线也没有要把第一个的b_touch设为false
            containerCtrTS.SetIsTouchByGrid(this.touchBlockGrid.x, this.touchBlockGrid.y, false);
        }

        this.InitCtrData();
        this.touchBlockGridList = [];
    }

    InitCtrData(setTouch: boolean = false) {
        if (setTouch) {
            let containerRow = g_GameMgr.GetGameDataMgr().containerRow;//y
            let containerCol = g_GameMgr.GetGameDataMgr().containerCol;//x
            for (let y = 0; y < containerRow; y++) {
                for (let x = 0; x < containerCol; x++) {
                    let blockNode = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(y, x);
                    let blockBaseTS = blockNode.getComponent(blockBase);
                    blockBaseTS.SetIsTouch(false);
                }
            }
        }

        // if (this.lineNodeList.length > 1) {
        //     g_GameMgr.GetSounMgr().reSetConnectionSoundNum();
        // }

        // //消除连线
        for (let i = 0; i < this.lineNodeList.length; i++) {
            let line = this.lineNodeList[i];
            line.setPosition(9999, 9999);
            line.getComponent(UITransform).width = 0;
            line.angle = 0;//被对象池回收，并不会修改节点的相关值，必须手动修改
            this.linePool.put(this.lineNodeList[i]);
        }
        this.touchBlockGrid = null;
        
        this.lineNodeListIndex = 0;
        this.lineNodeList = [];

    }

    getOrCreNode() {
        let line: Node = null;
        if (this.linePool.size() > 0) {
            line = this.linePool.get();
        } else {
            line = instantiate(this.linePrefab);
        }
        line.parent = this.node;
        this.lineNodeList.push(line);
        return line;
    }

    ShowClearEffect(touchBlockGridList: Vec2[], touchBlockGrid: Vec2) {
        let gridList: Vec2[] = [];
        let posList: Vec3[] = [];
        let colorList: string[] = [];
        let sumValue = 0;//合成的值
        let containerCtrNode = find("Canvas/Game/BlockContainer");
        let containerCtrTS = containerCtrNode.getComponent(containerCtr);
        for (let i = 0; i < touchBlockGridList.length; i++) {
            gridList.push(touchBlockGridList[i]);
        }
        gridList.push(touchBlockGrid);
        for (let i = 0; i < gridList.length; i++) {
            posList.push(containerCtrTS.GridToPos(gridList[i].x, gridList[i].y));
            let node = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(gridList[i].y, gridList[i].x);
            let blockTS = node.getComponent(blockBase);
            sumValue += Math.pow(2, blockTS.GetValue());
            colorList.push(blockTS.GetColor());
        }
        let id = Math.ceil(Math.log2(sumValue));
        let color = g_CommonTool.ColorOfString(g_GameMgr.GetGameDataMgr().GetColorByID(id));
        let effectCtrNode = find("Canvas/Game/BlockContainer/effect");
        let effectCtrTS = effectCtrNode.getComponent(effectCtr);
        effectCtrTS.ShowClearEffct(posList, colorList, color);
    }

    /**创建上方显示的合成值 */
    CreSumBlock(touchBlockGridList: Vec2[], touchBlockGrid: Vec2) {
        let gameNode = find("Canvas/Game");
        let gameTS = gameNode.getComponent(game);
        if (touchBlockGridList[0].x == touchBlockGrid.x && touchBlockGridList[0].y == touchBlockGrid.y) {//连回只剩一个时，没有连线，取消合成值显示
            gameTS.SetSumBlock(false);
        } else {
            let list: Vec2[] = [];
            for (let i = 0; i < touchBlockGridList.length; i++) {
                list.push(touchBlockGridList[i]);
            }
            list.push(touchBlockGrid);
            gameTS.SetSumBlock(true, list);
        }
    }

    /**创建或设置连线，line存在时创建 */
    creOrSetConnection(strPos: Vec3, endPos: Vec3, line?: Node) {
        let Sx = strPos.x;
        let Sy = strPos.y;
        let Ex = endPos.x;
        let Ey = endPos.y;

        if (!line) {
            line = this.lineNodeList[this.lineNodeListIndex];
            let pos = new Vec3((Sx + Ex) / 2, (Sy + Ey) / 2, 0);
            line.setPosition(pos);
        }

        let width = Math.sqrt((Ex - Sx) * (Ex - Sx) + (Ey - Sy) * (Ey - Sy));
        if (!width) {
            return;
        }
        line.getComponent(UITransform).width = width;

        let angle: number = 0;
        if ((Sx - Ex) * (Sy - Ey) > 0) {
            angle = 360 * Math.atan(Math.abs(Sy - Ey) / Math.abs(Sx - Ex)) / (2 * Math.PI);
        } else {
            angle = 180 - (360 * Math.atan(Math.abs(Sy - Ey) / Math.abs(Sx - Ex)) / (2 * Math.PI));
        }
        line.angle = angle;

        let touchBlockGrid = this.touchBlockGrid;
        let block = g_GameMgr.GetGameDataMgr().blockNodeList.getValue(touchBlockGrid.y, touchBlockGrid.x);
        let blockTS = block.getComponent(blockBase);
        let color: string = blockTS.GetColor();
        line.getComponent(Sprite).color = g_CommonTool.ColorOfString(color);
    }
}