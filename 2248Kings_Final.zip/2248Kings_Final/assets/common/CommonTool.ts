import { _decorator, Color, Asset, error, assetManager } from 'cc';

class CommonTool {

    ColorOfString(color: string): Color {
        if (color == null || color.length != 7) {
            return null;
        }
        let value = color.toLowerCase();
        if (value.charAt(0) != "#") {
            return;
        }
        value = value.slice(1);
        let r = parseInt(value[0] + value[1], 16);
        let g = parseInt(value[2] + value[3], 16);
        let b = parseInt(value[4] + value[5], 16);
        return new Color(r, g, b, 255);
    }

    //创建异步下载资源对象
    /**
    * 创建异步加载
    * @param resPath
    * @param resType
    * @param retainRes 是否记录资源
    * @constructor
    */
    CreateLoadPromise<T extends Asset>(resPath: string, resType: typeof Asset, retainRes = true): Promise<T> {
        let promiseFunc = (resolve: Function, reject: Function) => { //创建异步函数
            assetManager.resources.load(resPath, resType, (error: Error, loadData: T) => {//加载资源
                if (error) {
                    reject(error);
                    return
                }
                resolve(loadData);
            });
        };
        return new Promise<T>(promiseFunc);//返回异步对象
    }

    // 转化表为字典(横排)
    TransformTextData(tableName: string, textData: any) {
        let textDataList = textData.split("\n");
        let lineCount = textDataList.length;
        if (!lineCount) {
            error("配置数据为空(%s) 没有配置数据", tableName);
            return null;
        }
        let lineNum = -1;
        let fieldNameList = null;
        let fieldCount = null;
        let tableDataDict: any = [];
        for (let index_i = 0; index_i < lineCount; index_i++) {
            let textLineDataStr = textDataList[index_i];
            textLineDataStr = textLineDataStr.replace(/(\s*$)/g, "");//去除空格
            if (!textLineDataStr) {//读到最后一行，跳出//空行跳过
                continue
            }
            lineNum += 1;
            let textLineDataList = textLineDataStr.split("\t");
            //如果是key行,记录key数据
            if (lineNum === 1) {
                fieldNameList = textLineDataList;
                fieldCount = fieldNameList.length;
            } else if (lineNum > 1) {
                let rowCount = textLineDataList.length;
                if (rowCount != fieldCount) {
                    error("读取数据失败(%s),第(%s)行, 配置数据:%s 配置列数(%s)!=需求列数(%s)"
                        , tableName, lineNum, JSON.stringify(textLineDataList), rowCount, fieldCount);
                    return null;
                }
                let rowKey = textLineDataList[0];
                let rowDataDict: any = {};
                for (var index_j = 0; index_j < fieldCount; index_j++) {
                    let value = textLineDataList[index_j].trim();
                    let fieldName = fieldNameList[index_j].trim();
                    try {
                        value = this.GetTransformValue(tableName, fieldName, value, lineNum);
                    } catch (error) {
                        error("GetTransformValue(%s,%s)(%s), error:%s", tableName, fieldName, value, error.stack);
                        //throw new Error("Read Open Fail:" + tablePath);
                        value = undefined;
                    }
                    rowDataDict[fieldName] = value;
                }
                tableDataDict[rowKey - 1] = rowDataDict;
            }
        }
        return tableDataDict
    }

    /**
    * 获取value转化后的值
    */
    // else if (fieldName.endsWith("List") && typeof (valueStr) == "string") {
    //     return valueStr.split(";");
    // }
    GetTransformValue(tableName: string, fieldName: string, valueStr: any, lineNum) {
        let startStr = valueStr[0];
        let endStr = valueStr[valueStr.length - 1];
        let LowerValueStr = valueStr.toLowerCase();
        if (LowerValueStr === "false") {
            return false
        } else if (LowerValueStr === "true") {
            return true
        }
        if (startStr === "[" && endStr === "]") {//如果是列表
            try {
                return JSON.parse(valueStr);
            } catch (e) {
                error("转换数组配置错误(%s,%s)(%s)  第(%s)行", tableName, fieldName, valueStr, lineNum);
                return valueStr;
            }
        } else if (startStr === "{" && endStr === "}") {
            try {
                return JSON.parse(valueStr);
            } catch (e) {
                error("转换数组配置错误(%s,%s)(%s)  第(%s)行", tableName, fieldName, valueStr, lineNum);
                return valueStr;
            }
        }
        else if (valueStr.indexOf("return") != -1) {
            return new Function(valueStr);
        } else {
            if (valueStr == "") {
                return valueStr
            }
            //去整
            //如果不是纯数字,则为字符串
            else if (isNaN(valueStr)) {
                return valueStr
            } else {
                return Number(valueStr)
            }
        }
    }
}
var g_CommonTool = new CommonTool();
export default g_CommonTool;