import { _decorator, AudioClip } from 'cc';

export interface colorData {
    id: number;//对应ID
    color: string;//格子颜色 “#FFFFFF”
    fontColor: string;//字体颜色（#FFFFFF）
}

export interface soundTextData {
    id: number;//对应ID
    soundName: string;//音效名
    path: string;//路径
}

export interface soundData {
    id: number;
    name: string,
    soundData: AudioClip,
}

export enum rewardType {
    addMoney = 0,//默认，加金币
    timesMoney = 1,//按倍数获取金币
}

export class scaleAction {
    static readonly time = 0.3;//放大总时间
    static readonly scale = 0.2;//增大几倍
}

export class clearEffect {
    static readonly operation = 1.0;//每次操作间隔，判断是否突破,大于动画播放时间
    static readonly actionTime = 0.8;//动画播放时间，播放完后，合成再下落
    static readonly biggerTime = 0.5;
    static readonly moveTime = 0.3;
    static readonly colorTime = 0.2;
    static readonly destoryTime = 0.8;//消除可生成最小值花费时间
    static readonly destoryTime2 = 0.5;//砖块被击碎时间
}

export class effectActioin {
    static readonly exchangeTime = 0.3;
    static readonly doubleTime = 0.3;
    static readonly hammerTime = 1.0;
    static readonly addMoneyTime = 1.3;
}

export enum lastInterFace {
    none = 0,
    doubleLayer = 1
}