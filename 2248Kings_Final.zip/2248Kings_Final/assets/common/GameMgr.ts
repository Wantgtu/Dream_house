import { _decorator, Component, Node } from 'cc';
import { GameDataMgr, GetGameDataMgrInstance } from '../scripts/Manager/GameDataMgr';
import { SoundMgr, GetSoundMgrInstance } from '../scripts/Manager/SoundMgr';
import { AdvertisementMgr, GetAdvertisementMgrInstance } from '../scripts/Manager/AdvertisementMgr';
import { GoldMgr, GetGoldMgrInstance } from '../scripts/Manager/GoldMgr';
import { LocalDataMgr, GetLocalDataMgrInstance } from '../scripts/Manager/LocalDataMgr';
import { VibrateMgr, GetVibrateMgrInstance } from '../scripts/Manager/VibrateMgr';

const { ccclass, property } = _decorator;
@ccclass('GameMgr')

class GameMgr {

    g_AdvertisementMgr: AdvertisementMgr;
    g_GameDataMgr: GameDataMgr;
    g_SoundMgr: SoundMgr;
    g_GoldMgr: GoldMgr;
    g_LocalDataMgr: LocalDataMgr;
    g_VibrateMgr: VibrateMgr;

    InitAllMgr() {
        this.g_AdvertisementMgr = GetAdvertisementMgrInstance();
        this.g_GameDataMgr = GetGameDataMgrInstance();
        this.g_GoldMgr = GetGoldMgrInstance();
        this.g_LocalDataMgr = GetLocalDataMgrInstance();
        this.g_SoundMgr = GetSoundMgrInstance();
        this.g_VibrateMgr = GetVibrateMgrInstance();
    }

    GetAdvertisementMgr() {
        return this.g_AdvertisementMgr;
    }

    GetGameDataMgr() {
        return this.g_GameDataMgr;
    }

    GetGoldMgr() {
        return this.g_GoldMgr;
    }

    GetLocalDataMgr() {
        return this.g_LocalDataMgr;
    }

    GetSounMgr() {
        return this.g_SoundMgr;
    }

    GetVibrateMgr() {
        return this.g_VibrateMgr;
    }

}

var g_GameMgr = new GameMgr();
export default g_GameMgr;
window["g_GameMgr"] = g_GameMgr;
