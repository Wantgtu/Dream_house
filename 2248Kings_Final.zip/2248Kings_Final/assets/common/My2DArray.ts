import { _decorator } from 'cc';
export class My2DArray {
    my2dArray: Array<Array<number>> = new Array<Array<any>>();
    rows: number;
    columns: number;
    constructor(rows: number, columns: number, value: any) {
        this.rows = rows;
        this.columns = columns;
        this.initRows(rows);
        this.initColumns(columns,value);
    }
    getValue(rows: number, columns: number): any {
        if (rows < 0 || columns < 0 || rows >= this.rows || columns >= this.columns) {
        return null;
        }
        return this.my2dArray[rows][columns];
    }
    setValue(rows: number, columns: number, value: any) {
        if (rows < 0 || columns < 0 || rows >= this.rows || columns >= this.columns) {
        return null;
        }
        this.my2dArray[rows][columns] = value;
    }
    initRows(rows: number) {
        if (rows < 1) {
        return;
        }
        for (let i = 0; i < rows; i++) {
        this.my2dArray.push(new Array<any>());
        }
    }
    initColumns(columns: number, value: any) {
        if (columns < 1) {
        return;
        }
        for (let i = 0; i < this.my2dArray.length; i++) {
        for (let j = 0; j < columns; j++) {
        this.my2dArray[i].push(value);
        }
        }
    }
    getArray(): Array<Array<any>> {
        return this.my2dArray;
    }
}
