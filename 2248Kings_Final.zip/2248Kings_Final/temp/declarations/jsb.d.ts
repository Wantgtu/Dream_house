/// <reference path="/Applications/CocosCreator/Creator/3.7.3/CocosCreator.app/Contents/Resources/resources/3d/engine/@types/jsb.d.ts"/>
